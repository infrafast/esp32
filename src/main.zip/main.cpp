// debugging https://docs.platformio.org/en/stable/tutorials/espressif32/arduino_debugging_unit_testing.html

#define USE_NETWORK
#include "Interval.h"

#define ADDRESS_CHNAME "/ch/%02d/name"
#define ADDRESS_BUSNAME "/bus/%02d/name"

// COMMON PROPERTIES NAME
#define SELECT_CHANNEL_PROPERTY "channelID"
#define SELECT_BUS_PROPERTY "busID"

#define STRIP_XAIR_GROUP "xair"


class SendReturnStrip : public ThreeSelectStrip{
  public:

    SendReturnStrip(StripSkeleton* s,GUIManager* g,bool debug=false):ThreeSelectStrip(s,g, &sendName, &returnName, debug){
    }

    ~SendReturnStrip(){};

    virtual bool actionCallback(){
      //mute/unmute
      DEBUG_PRINT("\nSendReturnStrip actionCallback");
      chMute = !chMute;
      return true;
    }

    virtual bool increaseCallBack(){}
    virtual bool decreaseCallback(){}
    
    virtual bool refresh(bool force=false){
      refreshed = force;
      return refreshed;
    };    

    virtual void buildWidgets(uint8_t layout){
      switch(layout){
        case LAYOUT_QUATUOR:
        break;
        case LAYOUT_ICON:
        break;
        case LAYOUT_DETAILS: 
        default:
       
          Top2Toggles* topLabels = new Top2Toggles(&gui->screenGUIs, &widgetHandles, &sendName, &returnName, &chMute, &busMute,&frontColor,&backColor );          
          widgetHandles.add(topLabels);               
          gui->add(topLabels);

          // add the SliderWidget here based on value
          // value float

        break;
      }      
    }    

  protected:
    String sendName = "sendName";
    String returnName ="returnName";
    bool chMute = false, busMute = true;
    float value;
    DataSet* ds;
};

class Ch2BusStrip : public SendReturnStrip{
  #define STRIP_CH2BUS "ch2bus"

  public:
    Ch2BusStrip(StripSkeleton* s,GUIManager* g,bool debug=false):SendReturnStrip(s,g,debug){
      select2PropertyName = SELECT_CHANNEL_PROPERTY;
      select3PropertyName = SELECT_BUS_PROPERTY;
    }

    virtual bool refresh(bool force=false){
      SendReturnStrip::refresh(force);


      // this code should only be called if select2ID != oldSelect2ID
      ds = skeleton->getDataSet(ADDRESS_CHNAME);
      if (ds != nullptr) sendName = ds->sValues->get(select2ID);
      ds = skeleton->getDataSet(ADDRESS_BUSNAME);
      if (ds != nullptr) returnName = ds->sValues->get(select3ID);

      // put then the code specific here to treatment, for the value treatment
      return refreshed;
    }
};

class ChGainStrip : public TwoSelectStrip{
  #define STRIP_CHGAIN "chGain"

  public:
    ChGainStrip(StripSkeleton* s,GUIManager* g,bool debug=false):TwoSelectStrip(s,g, &chName,debug){
      select2PropertyName = SELECT_CHANNEL_PROPERTY;
    }

    ~ChGainStrip(){};

    virtual bool actionCallback(){}
    virtual bool increaseCallBack(){}
    virtual bool decreaseCallback(){}
    
    virtual bool refresh(bool force=false){
      refreshed = force;

      DataSet* ds = skeleton->getDataSet(ADDRESS_CHNAME);
      if (ds != nullptr) chName = ds->sValues->get(select2ID);

      frontColor = colorMap[select2ID].fColor;
      backColor = colorMap[select2ID].bColor;

      return refreshed;
    };    

    virtual void buildWidgets(uint8_t layout){
      switch(layout){
        case LAYOUT_QUATUOR:
        break;
        case LAYOUT_ICON:
        break;
        case LAYOUT_DETAILS: 
        default:
       
          Top1Toggle1Label* topLabels = new Top1Toggle1Label(&gui->screenGUIs, &widgetHandles, &chName, &gainString, &chMute,&frontColor,&backColor );          
          widgetHandles.add(topLabels);               
          gui->add(topLabels);

          RingMeter* ringMeter = new RingMeter(&value, -16, 20, 0, &GUI::center,&y, WIDGET_BIG_WIDTH, &dBstring,&frontColor,&GUI::transparentColor,false);
          widgetHandles.add(ringMeter);               
          gui->add(ringMeter);          

        break;
      }      
    }    

  private:
    String chName = "chName";
    String gainString = "gain";
    String dBstring = "dB";
    bool chMute = false;
    float value=0.0;
    int16_t y = TFT_HEIGHT-WIDGET_BIG_WIDTH-OVERLAY_ICON_SIZE*2;
};




StripSkeletonColor* stripCh2BusSkel;
Strip* ch2busStripConstructorCallback(){
  DEBUG_PRINT("\n\tch2busStripConstructorCallback()");
  return new Ch2BusStrip(stripCh2BusSkel,&gui,true);
}

StripSkeletonColor* stripChGainSkel;
Strip* gain2chStripConstructorCallback(){
  DEBUG_PRINT("\n\tgain2chStripConstructorCallback()");
  return new ChGainStrip(stripChGainSkel,&gui,true);
}

DataSet chName={.address = ADDRESS_CHNAME,.object=INPUTSELECT, .sValues=new LinkedList<String>()};
DataSet busName={.address = ADDRESS_BUSNAME,.object=INPUTSELECT, .sValues=new LinkedList<String>()};
//DataSet chColors={.address = ADDRESS_COLORNAME,.type=INPUTSELECT, .iValues= new LinkedList<int>()};

void setup() {
  String config=
    "\"mixerIP\": \"192.168.0.1\","
    "\"mixerPort\": \"10023\""; 
 
  for(uint8_t i=0;i<32;i++){
    chName.sValues->add("CHANNELj"+String(i));
    busName.sValues->add("BUSj"+String(i));    
  }
  colorNames.sValues->add("auto");

  stripCh2BusSkel = new StripSkeletonColor(STRIP_CH2BUS,STRIP_XAIR_GROUP,ch2busStripConstructorCallback);
  stripCh2BusSkel->addDataSet(SELECT_CHANNEL_PROPERTY, &chName);
  stripCh2BusSkel->addDataSet(SELECT_BUS_PROPERTY, &busName);
  

  stripChGainSkel = new StripSkeletonColor(STRIP_CHGAIN,STRIP_XAIR_GROUP,gain2chStripConstructorCallback); 
  stripChGainSkel->addDataSet(SELECT_CHANNEL_PROPERTY, &chName);
  


  app.stripFactory.add(stripTextSkel);
  app.stripFactory.add(stripCh2BusSkel);
  app.stripFactory.add(stripChGainSkel);

  app.init(config);  

  String data;
  app.serialize(&data);
  DEBUG_PRINT("\nskeletons:<%s>",data.c_str());

}


void loop() {
  yield();
  app.refresh();
}