#ifndef HWComponents_h
#define HWComponents_h

#include <Ethernet.h>
#include <EthernetUdp.h>
#include <WiFiGeneric.cpp>   // for tipipinit
#include <ArduinoOTA.h>           // for WIFI program upload 
#include <ESP32Ping.h>
#include <OSCMessage.h>           //https://github.com/CNMAT/OSC  lib 1.3.5
#include <HttpClient.h> // amcewen/HttpClient@^2.2.0 as opposed to the std lib #include <HTTPClient.h> which only handle WiFIclient
#include <WiFiClientSecure.h>
#include "BluetoothSerial.h"   //required for OSC
// https://github.com/andrew-susanto/Arduino-Ethernet-Icmp.git	 => platform IO: works but corrupt the WiFi
//#include <EthernetICMP.h>

class HWComponent: public GenericComponent{
  public:
    uint8_t CSPin;

    HWComponent(uint8_t pin, boolean d=true):GenericComponent(d){
      CSPin = pin;
    }  
};

class HWComponent2State : public HWComponent{
  public: 
    bool state;
    bool previousState;

    HWComponent2State(uint8_t pin, bool s = false, boolean d=true):HWComponent(pin,d){      
      state = s;
      previousState = state;
    }

    bool refresh(bool force=false){
      if (previousState != state || force){
        previousState = state;
        if (debug){
          DEBUG_PRINT("\n%s changed state to: %i",id.c_str(),state);
        }
        refreshed = true;
      }else refreshed = false;
      return refreshed;
    }

};

class DigitalOut : public HWComponent2State{
  public:

    DigitalOut(uint8_t p,bool s = HIGH): HWComponent2State(p,s){
      pinMode(CSPin, OUTPUT);
      id = "DigitalOut~"+String(p);
      refresh(true);  //force the state
    }

    bool refresh(bool force=false){
      HWComponent2State::refresh(force);
      if (refreshed){
        digitalWrite(CSPin, state);
      }
      return refreshed;
    }

    void init(){      
    
    }
};

class AnalogIn : public HWComponent{
  private:
    uint16_t refreshPercentageThreshold = 1;  // if value change of 1% it will be considered as change
  
  public:
    uint16_t value=0;

    AnalogIn(uint8_t p, uint16_t t=0, boolean d=true): HWComponent(p,d){
      refreshPercentageThreshold = t;
      pinMode(CSPin, INPUT);
      id = "AnalogIn~"+String(p);
    }
    
    bool refresh(bool force=false){
      refreshed = force;
      uint16_t v = analogRead(CSPin);

      uint16_t deltaPercentage = 0;
      if (value!=0) deltaPercentage = abs(1.0-((float)v/(float)value))*100;
      else deltaPercentage = abs(1.0-((float)v/1.0))*100; // avoid divide per zero
      
      if (deltaPercentage >= refreshPercentageThreshold || force){
        if (debug){
          DEBUG_PRINT("\n%s (%d->%d)",id.c_str(),value,v);
        }
        value = v;        
        if (debug){
          DEBUG_PRINT("\tchanged to: %u (%d>%d)",value,deltaPercentage,refreshPercentageThreshold);
        }
        refreshed = true;
        
      }
      
      return refreshed;
    }

    virtual void init(){
      HWComponent::init();
      refresh();
    }
};

#define BAT_CRIT 3.2
#define BAT_MIN 3.3
#define BAT_MAX 4.2
class BatteryMonitor : public HWComponent{
  #define numReadings 5
  public:
    float vBat = BAT_MAX;

    BatteryMonitor(uint8_t p, boolean d=true): HWComponent(p,d){
      pinMode(CSPin, INPUT);
      id = "BatteryMonitor~"+String(p);      
    };

    virtual void init(){
      HWComponent::init();
      for (readIndex = 0; readIndex < numReadings-1; readIndex++) read();
      refresh(true);  // force first reading
    }

    void read(){
      readings[readIndex] = analogReadMilliVolts(CSPin);     
      readSum = readSum + readings[readIndex];      
      //if (debug) DEBUG_PRINT("\nreadings[%i]:%i",readIndex,readings[readIndex]);
    }

    bool refresh(bool force=false){
      refreshed = force;
      readSum = readSum - readings[readIndex];
      read();
      readIndex = (readIndex + 1) % numReadings;

      uint32_t averageReading = readSum / numReadings;  

      float val = 2 * averageReading / 1000.0; 

      // rounding to 2 digit after decimal place
      float delta = abs(val-vBat);          
      int c = (int)(delta * 1000 + .5);
      float roundedDelta = c/1000.0;       

      if (roundedDelta>=0.05 || force){    // we only consider change of 0.5mv
        vBat = val;
        if (debug){
          DEBUG_PRINT("\n%s changed to: %.3f readSum:%i averageReading:%i delta:%.3f",id.c_str(),vBat,readSum, averageReading,roundedDelta);          
        }        
        refreshed = true;
      }
      return refreshed;
    }

  private:
    uint32_t readings[numReadings];      // the readings from the analog input
    int readIndex = 0;              // the index of the current reading
    uint32_t readSum = 0;                  // the running readSum
  

};


#define DEBOUCE_TIME 25
#define DCLIC_DETECTION_DELAY_BETWEEN_2CLICS 250  // multiplicateur: 0,1,2, valeurs possibles: 0 200 400 default: 250
#define LONG_PUSH_DELAY 150                       // 150 multiplicateur: 1 2 3 , valeurs possibes: 150 300 450 default: 150
#define HOLD_PUSH_DELAY 400                       // 300 multiplicateur: 1 2 3 , valeurs possibes: 400 800 1200 default: 400

#define DCLIC_DETECTION_PUSHDOWNMAXTIME LONG_PUSH_DELAY-1       // pour detecter un double clic, le premier clic doit etre court   200

typedef void (*ButtonEventCallBack)(uint8_t , unsigned long );

enum{
  SIMPLE_CLIC,
  DOUBLE_CLIC,
  LONG_CLIC,
  HOLD,
  RELEASE_HOLD,
  MAX_CLIC_DEF
};

void default_simpleClicCallBack(uint8_t buttonID, unsigned long time){
  //DEBUG_PRINT("\n%i SIMPLE %u",buttonID,time );
}

void default_doubleClicCallBack(uint8_t buttonID, unsigned long time){
  //DEBUG_PRINT("\n%i DOUBLE %u",buttonID,time );
}

void default_longClicCallBack(uint8_t buttonID, unsigned long time){
  //DEBUG_PRINT("\n%i LONG %u",buttonID,time );
}

void default_holdCallback(uint8_t buttonID, unsigned long time){
  //DEBUG_PRINT("\n%i HOLD %u",buttonID,time );
}

void default_releaseHoldCallback(uint8_t buttonID, unsigned long time){
  //DEBUG_PRINT("\n%i RELEASED %u",buttonID,time );
}

void empty_button_callback(uint8_t buttonID, unsigned long time){
  //DEBUG_PRINT("\n%i RELEASED %u",buttonID,time );
}


class Button : public HWComponent2State{
  public:
    unsigned long pushedTime = 0;
    bool doubleClic = false;

    Button(uint8_t p, uint8_t* push, uint8_t* dClic, int e=LOW, boolean d=true): HWComponent2State(p,!e,d){
       // we set the initial state to the opposite of the state we want to detect so it doesnt trigger the event at startup
      edge = e; //do we want to detect high or low
      setReactivity(push,dClic);
      clicCallBack[SIMPLE_CLIC] = default_simpleClicCallBack;
      clicCallBack[DOUBLE_CLIC] = default_doubleClicCallBack;
      clicCallBack[LONG_CLIC] = default_longClicCallBack;
      clicCallBack[HOLD] = default_holdCallback;
      clicCallBack[RELEASE_HOLD] = default_releaseHoldCallback;
    }

    virtual void init(){
      //DEBUG_PRINT("\n%s.init()",id.c_str());
      HWComponent2State::init();
      refresh();
    }

    bool refresh(bool force=false) {
      refreshed = force;
      if(millis()-startDebouceTime<DEBOUCE_TIME){
        //non blocking debouncer
        //DEBUG_PRINT("."); 
        return refreshed;
      }

      read();

      HWComponent2State::refresh(force);
      if (refreshed){   
      
        startDebouceTime = millis();

        if (state != edge){ //released
          if (pushedTime<DCLIC_DETECTION_PUSHDOWNMAXTIME && !pendingDoubleClicDetection){            
            pendingDoubleClicDetection = true;    
            startTimeBetween2Clics = millis();                                                       
          }else{
            pendingDoubleClicDetection = false;
            if (!doubleClic){
              if (pushedTime>HOLD_PUSH_DELAY * (*push_reactivity)){
                 this->clicCallBack[RELEASE_HOLD](getID(),pushedTime);                                       
              }else if (pushedTime>LONG_PUSH_DELAY * (*push_reactivity)){
                 this->clicCallBack[LONG_CLIC](getID(),pushedTime);
              }else{
                this->clicCallBack[SIMPLE_CLIC](getID(),pushedTime);                
              }                                        
            }
          }

        }else { //pressed
          doubleClic = false;
          startPushTime = millis();
          if (pendingDoubleClicDetection){
            doubleClic = true;
            this->clicCallBack[DOUBLE_CLIC](getID(),millis()-startTimeBetween2Clics);
          }
        }        
      }else{
        if (state == edge){
          pushedTime = millis()-startPushTime;
          if (pushedTime>HOLD_PUSH_DELAY * (*push_reactivity)) this->clicCallBack[HOLD](getID(),pushedTime-HOLD_PUSH_DELAY * (*push_reactivity)); // for the callback, the time duration starts at 0 that why we dededuct HOLD_PUSH_DELAY * (*push_reactivity)
        } 
        else{ 
          pushedTime = 0;
          if (millis()-startTimeBetween2Clics>DCLIC_DETECTION_DELAY_BETWEEN_2CLICS * (*dClic_reactivity) && pendingDoubleClicDetection){
            pendingDoubleClicDetection = false;          
            if (!doubleClic){
              //DEBUG_PRINT("\n\t%s simpleClic: %ums",id.c_str(),millis()-startTimeBetween2Clics);                  
              this->clicCallBack[SIMPLE_CLIC](getID(),pushedTime);
            }         
          }  
        }      
      }
      return refreshed;
    }    
  
    void setCallBack(uint8_t button_event, ButtonEventCallBack button_function ){
      if (button_event>MAX_CLIC_DEF) return;
      clicCallBack[button_event] = button_function;
    }

    void setReactivity(uint8_t* push, uint8_t* dClic){
      if (*push>3) *push = 2; if (*push <= 0) *push = 2;
      if (*dClic>2) *dClic = 1; if (*dClic <=0) *dClic = 1;
      push_reactivity = push;
      dClic_reactivity = dClic;
      if (debug){DEBUG_PRINT("\n %s => setReactivity(%i,%i)",id.c_str(),*push_reactivity,*dClic_reactivity);}
    }

  private:
    uint8_t* push_reactivity, *dClic_reactivity ;
    int edge; 
    bool pendingDoubleClicDetection = false;
    unsigned long startTimeBetween2Clics = 0,startPushTime = 0, startDebouceTime = 0;
    ButtonEventCallBack clicCallBack[MAX_CLIC_DEF];
    virtual void read() = 0;    
    virtual int getID() = 0;    

};

enum{
  CABLE,
  WIFI,
  NONE
};

enum{
  DISCONNECTED,
  CONNECTED
};

class DigitalButton: public Button{
  public:
  
    DigitalButton(uint8_t p, uint8_t* push, uint8_t* dClic, uint8_t mode=INPUT_PULLUP, int e=LOW, boolean d=true):Button(p, push, dClic, e,d){      
      pinMode(p, mode); //
      id = "DigitalButton~"+String(getID());
    }

  private:

    virtual void read(){
      //two consecutive reading to avoid false reading
      boolean input1 = digitalRead(CSPin);
      delay(1);
      boolean input2 = digitalRead(CSPin);
      if (input1 == input2) state = input1;      
    }

    virtual int getID(){
      return CSPin;
    }

};

class LadderButton: public Button{
  public:
    static uint8_t bCount;
    uint8_t virtualID;

    LadderButton(AnalogIn* i, uint8_t* push, uint8_t* dClic, int e=HIGH,boolean d=true):Button(i->CSPin, push, dClic, e,d){      
      input = i;
      pinMode(input->CSPin, INPUT); //analog
      virtualID = bCount;      
      id = "LadderButton~"+String(getID());
      bCount++;
      //input = new AnalogIn(p,d);
    }

  private:        
    AnalogIn* input;

    #define RESOLUTION 4095
    //https://www.ignorantofthings.com/2018/07/the-perfect-multi-button-input-resistor.html
    // https://docs.google.com/spreadsheets/d/1G6wTsAxZDnVvzIDBkg5LrhhY1T7q4p_pDSZ6owvBCMA/edit?usp=sharing
    // for 3 button with 1st resistor 47Kohm, other resistance should be: 24k, 68k


    virtual void read() {

      //if (input->refresh()){
        input->refresh();
        float avg = RESOLUTION / float(bCount);
        if ((input->value > (bCount - 0.5) * avg) ){
          state = LOW;
        }else{
          //DEBUG_PRINT("\n%s val:%i",id.c_str(),input->value);

          int lowLimit = 0;
          int highLimit;

          for (int i = 0; i < bCount; i++) {          
            if (i>0) lowLimit = round(((i-1) + 0.5) * avg);
            highLimit = round((i + 0.5) * avg);
            //DEBUG_PRINT("\t (%i,%i)",lowLimit,highLimit);
            if (input->value >= lowLimit && input->value <highLimit) { 
              if (i == virtualID){
                //DEBUG_PRINT("X");
                state = HIGH;
              } 
            }
          }
        }
      //}
            
    }

    virtual int getID(){
      return virtualID;
    }    

};

uint8_t LadderButton::bCount = 0;

// littleFS : see https://github.com/espressif/arduino-esp32/tree/master/libraries/LittleFS/examples/LITTLEFS_PlatformIO
// ping : see https://github.com/pbecchi/ESP32_ping/tree/master    https://techoverflow.net/2021/06/19/how-to-ping-gateway-in-esp32/
// network : https://github.com/Xinyuan-LilyGO/LilyGo-W5500-Lite   https://mischianti.org/esp32-ethernet-w5500-with-plain-http-and-ssl-https/#google_vignette
// power W5500: https://github.com/pauldeng/arduino-leonardo-eth-w5500-powerdown-example/blob/arduino-default-ether-lib/src/main.cpp
#ifdef USE_HSPI_PORT
  #warning "USE_HSPI_PORT ACTIVATED"
#endif


class Network : public HWComponent2State{

  public:
    UDP* udp = NULL;
    Server* server=NULL;
    uint8_t media = NONE;
    IPAddress IP;
    bool ethEnabled = true;
    bool WiFiEnabled = true;

    Network(uint8_t pin, bool debug):HWComponent2State(pin,DISCONNECTED,debug){
      id = "Network~"+String(pin);
    }

    virtual void setLink(uint8_t linkStatus) = 0;
    virtual uint8_t getLink() = 0;
    virtual void stop() = 0;
    virtual String getConnectedDeviceIP() = 0;
    
    virtual void setWiFi(JsonList* list, String wiFiID){
      wiFiList = list;
      id = wiFiID;
      wiFiIndex = wiFiList->getIndex(id);
    }

    void stopWiFi(){
      if (WiFi.getMode() == WIFI_AP_STA){
        if (debug) DEBUG_PRINT("\nStopping STA");
        WiFi.mode(WIFI_AP);  
      }else if (WiFi.getMode() == WIFI_STA){
        if (debug) DEBUG_PRINT("\nWiFi off");
        WiFi.disconnect();
        WiFi.mode(WIFI_OFF);
      }else{
        // if we are in AP mode, we do nothing
      }
      delay(100);
      //esp_wifi_stop();
    }    
  
  protected:
    JsonList* wiFiList;
    uint8_t wiFiIndex;

  private:
    bool oldAppConnected = false;

};



class WiFiEth : public Network{
  public:
    uint8_t cable = LinkOFF;
    HttpClient* http = NULL;    
    Client* client = NULL;

    WiFiEth(uint8_t pin, bool enableEth = true, bool debug = true):Network(pin, debug){      
      id = "WiFiEth~"+String(pin);
      ethEnabled = enableEth;
      String forgedEthMac = WiFi.macAddress();

      sscanf(forgedEthMac.c_str(), "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx", &ethMac[0], &ethMac[1], &ethMac[2], &ethMac[3], &ethMac[4], &ethMac[5]);      
      /* we forge the eth mac address based on the wifi but we set the last digit to 99 to avoid conflicting eth and wifi mac adress when
      / AP is connected...

      sscanf(forgedEthMac.c_str(), "%hhx:%hhx:%hhx:%hhx:%hhx", &ethMac[0], &ethMac[1], &ethMac[2], &ethMac[3], &ethMac[4]);      
      ethMac[5]=0x99;*/
    }

    void init(){
      if (debug) DEBUG_PRINT("\n%s.init()",id.c_str());
      tcpipInit();  // so ethernet can benefit from getting mac address and other low level funciton even if WiFi is not up      
      // if enabled is true it means wde want to use the ethernet shield, so we try to initialize if
      if (ethEnabled){
        //ESP.eraseConfig(); // https://github.com/esp8266/Arduino/issues/1624
        //WiFi.setAutoConnect(false);
        Ethernet.init(CSPin);   // I've tested to move it in the constructor but it crashes, this has to be called in the setup() 
        // test if ethernet module is present and instantiate class accordingly
        Ethernet.begin(ethMac,100,100);
        if (Ethernet.hardwareStatus() == EthernetNoHardware){
          if (debug) DEBUG_PRINT("\n%s !!! THERE IS NO ETHERNET HW !!!",id.c_str());
          ethEnabled = false;
        }else{
          if (debug) DEBUG_PRINT("\n%s Using WiFi & Ethernet",id.c_str());
        }
      }else{
        if (debug) DEBUG_PRINT("\n%s Using WiFi only",id.c_str());
      }
      if (!ethEnabled){
        // power off the ethernet
        stopEthernet();
      }
    }    

    virtual void setLink(uint8_t linkStatus){
      cable = linkStatus;
    }

    virtual uint8_t getLink(){
      return cable;
    }

    void stopEthernet(){
    
    }

    virtual String getConnectedDeviceIP(){
      return "GW-IP";   
    }

    virtual void stop(){
      stopWiFi();     
      stopEthernet();
    }

    bool refresh(bool force=false) {
      // the loop ensure that we always have one connection at the same time, if wifi is connected, ethernet will not connect and vice versa
      // ethernet has the priority on WiFi
      //cable = Ethernet.linkStatus();      
      //DEBUG_PRINT("\n:cable:%d",cable);
      if (state == DISCONNECTED){        
        // first try to connect eth
        if (cable == LinkON){       // ethernet is enabled   
          if (Ethernet.begin(ethMac,100,100)){
            state = CONNECTED;
            media = CABLE; 
            // save power            
            stopWiFi();
            // we just connected ETH so we do everything related to ETH specialized object instanciation
            IP = Ethernet.localIP();         
            if (debug) DEBUG_PRINT("\nEthernet.begin() => got IP:%s",IP.toString().c_str());  
            if (client == NULL) client = new EthernetClient();
            if (server == NULL) server = new EthernetServer(80);
            if (udp == NULL) udp = new EthernetUDP;              
          }else{
            if (debug) DEBUG_PRINT(".");
              /* manage the case of static IP connection?

              // Set the static IP address to use if the DHCP fails to assign
              #define MYIPADDR 192,168,0,218
              #define MYIPMASK 255,255,255,0
              #define MYDNS 192,168,0,1
              #define MYGW 192,168,0,1            
              */
          }
        }else{
          if (WiFi.status() != WL_CONNECTED){
            if (_newWifiAttempt){
              //WiFi.begin("infrafast","Mf9k8iie2");
              if (WiFiEnabled){                   
                String pass = *wiFiList->getString(id);    // getting the password for the given ssid
                if (debug) DEBUG_PRINT("\nWifi.begin(%s,%s)",id.c_str(),pass.c_str());                
                WiFi.begin(id,pass);  
              }              
              //WiFi.begin("IphoneTch","jt2p9ug1");
              lastWiFiAttempt = millis();
              _newWifiAttempt = false;
            }
            //if (debug) DEBUG_PRINT("~"); // I put that in OnWiFiEvent => SYSTEM_EVENT_STA_DISCONNECTED to avoid flooding the serial out
            if (millis()-lastWiFiAttempt>9000){
              _newWifiAttempt = true;
              //next  credential to attempt
              wiFiIndex = (wiFiIndex + 1) % wiFiList->size();
              id = wiFiList->getName(wiFiIndex);
            }
          }else{
            // we just connected WIFI so we do everything related to WIFI specialized object instanciation
            state = CONNECTED;
            media = WIFI;
            // save power and disconnect ethernet driver
            // TBC 
            _newWifiAttempt = true; // reset flag for next deco.
            IP = WiFi.localIP();
            if (debug) DEBUG_PRINT("\nWifi.begin() => got IP: %s, %idb",IP.toString().c_str(),WiFi.RSSI());
            if (client == NULL) client = new WiFiClient();
            if (server == NULL) server = new WiFiServer(80,1); 
            if (udp == NULL) udp = new WiFiUDP;
          }
        }
      }else if (state == CONNECTED) {
        //ethernet has priority over wifi, hence if we are connected by WiFi but the cable is plugged, we disconnect WiFi
        if (media == WIFI && cable == LinkON){
          stopWiFi();
          state = DISCONNECTED; // cable will try reconnect at next refresh
        }else{
          // we are connected so do whatever is required to refresh common network object here
          ;           
          // while ( (http->connected() || http->available()) && ((millis() - timeoutStart) < 30*1000) ){
          //and monitoring the connexion + do whatever is required to refresh specialized network object here
          if (media == CABLE){
            if (cable == LinkOFF){
              state = DISCONNECTED; 
              media = NONE;
            }else{
              // do whatever is required when we are connected by cable
            }
          }else{
            if (WiFi.status() != WL_CONNECTED){
              state = DISCONNECTED; 
              media = NONE;            
              // TBC CODE THAT RE-ACTIVATE ETHERNET DRIVER HERE 
              // To give a chance to connect via eth if WiFI do not work anymore
            }else{
              // do whatever is required when we are connected by WiFI
              ArduinoOTA.handle();
            }
          }
        }
      }
      
      Network::refresh(force);
      if (refreshed){
        if (debug) DEBUG_PRINT("\n%s changed state => cable:%i, media:%i",id.c_str(),cable,media);
        // common instantiation to both Wifi and Ethernet goes here
        if (state == CONNECTED){
          // client has been instantiated before
          if (http == NULL) http = new HttpClient(*client);
          udp->begin(8888);   //this is to receive packets on port 8888
          if (media == WIFI) server->begin(); // <-- for some reason this begin cause the webserver not work with ethernet if it os called. But required for WiFi
          /*testHttpRequest();
          testOSC();*/
        }else if (state == DISCONNECTED){
          if (udp != NULL){if (debug) DEBUG_PRINT("\nDELETING UDP"); udp->stop(); delete udp; udp = NULL;}           
          if (client != NULL){if (debug) DEBUG_PRINT("\nDELETING CLIENT");client->stop(); delete client; client = NULL;} 
          if (server != NULL){if (debug) DEBUG_PRINT("\nDELETING SERVER");delete server; server  = NULL;} 
          if (http != NULL){if (debug) DEBUG_PRINT("\nDELETING HTTP");http->stop(); delete http; http = NULL;}                    
          DEBUG_PRINT("\nall done");
        }
      }

      return refreshed;
    }

    void testHttpRequest(){

      String srv = "82.65.4.93"; String path="/footswitch.php?check=1.2";
      DEBUG_PRINT("\nhttp.get(%s,%s)",srv.c_str(),path.c_str());
      int err = http->get(srv.c_str(), path.c_str());
      if (err == 0){
        DEBUG_PRINT("\nstartedRequest ok");
        err = http->responseStatusCode();
        if (err >= 0) {
          DEBUG_PRINT("\nGot status code: %i",err);
          // Usually you'd check that the response code is 200 or a similar "success" code (200-299) before carrying on, but we'll print out whatever response we get
          err = http->skipResponseHeaders();
          if (err >= 0){
            int bodyLen = http->contentLength();
            DEBUG_PRINT("\nLength: %i", bodyLen);
            DEBUG_PRINT("\nBody:\n");
            // Now we've got to the body, so we can print it out
            unsigned long timeoutStart = millis();
            char c;
            // Whilst we haven't timed out & haven't reached the end of the body
            while ( (http->connected() || http->available()) && ((millis() - timeoutStart) < 30*1000) ){
                if (http->available()){
                    c = http->read();
                    DEBUG_PRINT("%c",c);
                    bodyLen--;
                    // We read something, reset the timeout counter
                    timeoutStart = millis();
                }else{
                    // We haven't got any data, so let's pause to allow some to arrive
                    delay(1000);
                }
            }
          }else{
            DEBUG_PRINT("\nFailed to skip response headers: %i",err);
          }
        }else{    
          DEBUG_PRINT("\nGetting response failed: %i",err);
        }
      }else{
        DEBUG_PRINT("Connect failed: %i",err);
      }
      http->stop();  
    }

/*    void test(){
      if (client->connect("httpbin.org", 80)) {
        DEBUG_PRINT("\nclient Connected!");
        // Make a HTTP request:
        client->println("GET /get HTTP/1.1");
        client->println("Host: httpbin.org");
        client->println("Connection: close");
        client->println();
      } else {
        // if you didn't get a connection to the server:
        DEBUG_PRINT("\nclient connection failed");
      }      
    }
*/
   
    void scanWifi(){
      Serial.println("Scan start");
  
      // WiFi.scanNetworks will return the number of networks found.
      int n = WiFi.scanNetworks();
      Serial.println("Scan done");
      if (n == 0) {
          Serial.println("no networks found");
      } else {
        Serial.print(n);
        Serial.println(" networks found");
        Serial.println("Nr | SSID                             | RSSI | CH | Encryption");
        for (int i = 0; i < n; ++i) {
            // Print SSID and RSSI for each network found
            Serial.printf("%2d",i + 1);
            Serial.print(" | ");
            Serial.printf("%-32.32s", WiFi.SSID(i).c_str());
            Serial.print(" | ");
            Serial.printf("%4d", WiFi.RSSI(i));
            Serial.print(" | ");
            Serial.printf("%2d", WiFi.channel(i));
            Serial.print(" | ");
            switch (WiFi.encryptionType(i))
            {
            case WIFI_AUTH_OPEN:
                Serial.print("open");
                break;
            case WIFI_AUTH_WEP:
                Serial.print("WEP");
                break;
            case WIFI_AUTH_WPA_PSK:
                Serial.print("WPA");
                break;
            case WIFI_AUTH_WPA2_PSK:
                Serial.print("WPA2");
                break;
            case WIFI_AUTH_WPA_WPA2_PSK:
                Serial.print("WPA+WPA2");
                break;
            case WIFI_AUTH_WPA2_ENTERPRISE:
                Serial.print("WPA2-EAP");
                break;
            case WIFI_AUTH_WPA3_PSK:
                Serial.print("WPA3");
                break;
            case WIFI_AUTH_WPA2_WPA3_PSK:
                Serial.print("WPA2+WPA3");
                break;
            case WIFI_AUTH_WAPI_PSK:
                Serial.print("WAPI");
                break;
            default:
                Serial.print("unknown");
            }
            Serial.println();
            delay(10);
        }
      }
      Serial.println("");
  
      // Delete the scan result to free memory for code below.
      WiFi.scanDelete();
    }

  private:
    byte ethMac[6] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
    bool _newWifiAttempt = true;    // 
    int mixerPort = 10023;
    IPAddress mixerIP={192,168,0,255};
    bool  webAppOn = false;
    unsigned long lastWiFiAttempt;
};

class  NoNetwork: public Network{
    
  public:

    NoNetwork(bool debug):Network(0,debug){ 
      id = "NoNetwork~0";
      ethEnabled = false;
      WiFiEnabled = false;
    }

    bool refresh(bool force=false) {  
      return false;
    }

    virtual void setLink(uint8_t linkStatus){}
    virtual uint8_t getLink(){return LinkOFF;}      // access point has no physicalLink
    virtual void stop(){}    
    virtual String getConnectedDeviceIP(){return "";}
};

/* debug wifi AP:
https://github.com/espressif/esp-idf/issues/6289
https://github.com/espressif/esp-idf/issues/6108
https://stackoverflow.com/questions/56078329/is-there-a-way-to-get-the-ip-address-that-assigned-to-the-new-sta-that-connected
https://community.platformio.org/t/timer-interrupt-and-wifi-events-dont-work-together/12833
https://www.esp32.com/viewtopic.php?t=6292

*/


class AccessPoint : public Network{
  public:

    AccessPoint(const String* ssid, bool debug):Network(0,debug){ 
      id = "AccessPoint";
      media = WIFI;     
      id = *ssid+String(random(99)); // we create a different SSID each time to force the client (laptop) to see it as a new network and avoid asking to renew the DHCP lease, which oculd lead to failing getting an IP address.      
    }

    ~AccessPoint(){
      if(debug) DEBUG_PRINT("\n~AccessPoint()");
      WiFi.mode(WIFI_STA);        
      if (server != NULL){
        DEBUG_PRINT("\nTRACE 22");
        delete server;
        DEBUG_PRINT("\nTRACE 23");
      }
    }

    void init(){
      #define VISIBLE 0
      #define MAX_AP_CONNECTION 1
      #define WIFI_CHANNEL 2
      Network::init();

      stopWiFi();       // cut all previous connection

      #ifdef USE_NETWORK
        WiFi.mode(WIFI_AP_STA);        
        if (debug) DEBUG_PRINT("\n WiFi.mode(WIFI_AP_STA)");        
      #else
        WiFi.mode(WIFI_AP);
        if (debug) DEBUG_PRINT("\n WiFi.mode(WIFI_AP)");
      #endif     
      
      WiFi.softAP(id,"",WIFI_CHANNEL,VISIBLE,MAX_AP_CONNECTION);         
      WiFi.setTxPower(WIFI_POWER_19_5dBm); // maximum power => https://github.com/G6EJD/ESP32-8266-Adjust-WiFi-RF-Power-Output/      
      IP = WiFi.softAPIP();
      if (debug) DEBUG_PRINT("\n WiFi.softAPIP(%s) => %s",id.c_str(),IP.toString().c_str());        
    }

    bool refresh(bool force=false) {      
      // the state is modified by onEvent()
      if (WiFi.softAPgetStationNum()>0){
        state = CONNECTED;        
      }else{
        state = DISCONNECTED;
      }
      Network::refresh(force);
      if (refreshed){
        if (state == CONNECTED){
          if (debug) DEBUG_PRINT("\nCient connected to AP");
          if (server == NULL) server = new WiFiServer(80,1);         
          server->begin();
        }else{
          if (debug) DEBUG_PRINT("\nCient disconnected from AP");
          if (server != NULL){if (debug) DEBUG_PRINT("\nDELETING SERVER");delete server; server  = NULL;} 
        }                
      }
      return refreshed;
    }

    virtual String getConnectedDeviceIP(){    // see https://www.esp32.com/viewtopic.php?t=6292
        wifi_sta_list_t wifi_sta_list;
        tcpip_adapter_sta_list_t adapter_sta_list;
        esp_wifi_ap_get_sta_list(&wifi_sta_list);
        tcpip_adapter_get_sta_list(&wifi_sta_list, &adapter_sta_list);

        tcpip_adapter_sta_info_t station = adapter_sta_list.sta[0];
        //Serial.print((String)"[+] Device " + i + " | MAC : ");
        //Serial.printf("%02X:%02X:%02X:%02X:%02X:%02X", station.mac[0], station.mac[1], station.mac[2], station.mac[3], station.mac[4], station.mac[5]);
        ip4_addr_t ip;
        ip.addr = station.ip.addr;
        return ip4addr_ntoa(&ip);
    }

    virtual void setLink(uint8_t linkStatus){}
    virtual uint8_t getLink(){return LinkOFF;}      // access point has no physicalLink

    virtual void stop(){
      // do stuff to stop AP
      WiFi.setTxPower(WIFI_POWER_MINUS_1dBm); // maximum power => https://github.com/G6EJD/ESP32-8266-Adjust-WiFi-RF-Power-Output/
    }

  private:

};

#endif