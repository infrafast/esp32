#include <LinkedList.h>
#include <spi.h>
#include <TFT_eSPI.h>             // Graphics and font library for ST7735 driver chip  lib 2.3.61
#include <LittleFS.h>

#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include <lwip/netdb.h>
#include "lwip/api.h"
//#include "ping/ping_sock.h"
//#include <ArduinoMDNS.h>

//#include <usb_dev.h>

//#define ICMPPING_ASYNCH_ENABLE 1

//#include <EthernetICMP.h>
//#include <ESP32Ping.h>

#include <EthernetUdp.h>

#include "HWComponents.h"

enum{
  LEFTB,
  RIGHTB,
  MIDDLEB,
  MAXB  
};

#define LEFTB_ID    0
#define MIDDLEB_ID  1
#define RIGHTB_ID   2

enum{
  OFF,
  ON
};

//////////////////////////////////////////////
/*#define POWERRAIL_PIN   D4
#define BATLEVEL_PIN    D1
#define ANALOGB_PIN     D0*/

#ifdef C3
  #define ONOFF_PIN       D2      
  #define ETH_PIN         D7
  #define POWERRAIL_PIN   D4
  #define BATLEVEL_PIN    D1
  #define ANALOGB_PIN     D0  
#else
  #define ONOFF_PIN       GPIO_NUM_3      
  #define ETH_PIN         GPIO_NUM_44  
  #define POWERRAIL_PIN   GPIO_NUM_5
  #define BATLEVEL_PIN    GPIO_NUM_2
  #define ANALOGB_PIN     GPIO_NUM_1
#endif



volatile unsigned long DebounceTimer;
volatile unsigned int delayTime = 200;
volatile unsigned int delayRepeatTime = 500;
unsigned long lastInterrupt;

void OnWiFiEvent(WiFiEvent_t event);

class HardwareManager : public GenericComponent {
public:
    TFT_eSPI tft = TFT_eSPI();  // Invoke library, pins defined in User_Setup.h

    LadderButton *buttons[3];
    //DigitalButton *buttons[3];
    DigitalButton *onOff;
    DigitalOut powerRail = DigitalOut(POWERRAIL_PIN,OFF);
    BatteryMonitor battery = BatteryMonitor(BATLEVEL_PIN,false);
    AnalogIn analogButtonIn = AnalogIn(ANALOGB_PIN,20,false); //20% threshold
    AccessPoint* ap;

    Network *network = nullptr;
    Network *configMedia = nullptr;    

    String configIP;

    HardwareManager(bool debug=false):GenericComponent(debug){
      id="HardwareManager";

      #ifdef DEBUG
        Serial.begin(115200);
      #endif
      
      if (!LittleFS.begin()){
        DEBUG_PRINT("\nFS BEGIN ISSUE");
      }      

      buttons[LEFTB] = new LadderButton(&analogButtonIn, &default_button_pushDelay,&default_button_dClicdelay,HIGH,false);       // virtual ID 20
      buttons[MIDDLEB] = new LadderButton(&analogButtonIn, &default_button_pushDelay,&default_button_dClicdelay,HIGH,false);     // virtual ID 21
      buttons[RIGHTB] = new LadderButton(&analogButtonIn, &default_button_pushDelay,&default_button_dClicdelay,HIGH,false);      // virtual ID 22
      
      for (uint8_t i=0;i<3;i++) hwComponents.add(buttons[i]);

      WiFi.onEvent(OnWiFiEvent);        

      #ifdef USE_NETWORK
        network = new WiFiEth(ETH_PIN,true,true);
        configMedia = network;
        //configIP = configMedia->IP.toString();  // this is done in refresh
      #else
        network = new NoNetwork(true);
        configMedia = network;
      #endif
      hwComponents.add(network);


      onOff = new DigitalButton(ONOFF_PIN,&onOff_button_pushDelay,&default_button_dClicdelay,INPUT_PULLDOWN,HIGH,false);
      hwComponents.add(onOff);
      
      hwComponents.add(&battery);
      

    }
    
    /*
    virtual ~HardwareManager(){
        delete button
        delete network
        but who cares?    
    }
    */
    virtual void init() {      
      GenericComponent::init();
           
      for(int i = 0; i < hwComponents.size(); i++) hwComponents.get(i)->init();

      #ifdef C3
        esp_deep_sleep_enable_gpio_wakeup(BIT(ONOFF_PIN), ESP_GPIO_WAKEUP_GPIO_HIGH); //c3
      #else   // S3
        esp_sleep_enable_ext0_wakeup(ONOFF_PIN,1); //1 = High, 0 = Low  s3
      #endif
     
      bool longPress = false;
      if (onOff->state == HIGH && !isSystemON){
        delay(DEBOUCE_TIME);        

        while(onOff->state == HIGH && !longPress) {
          onOff->refresh();
          if (onOff->pushedTime>500){ //5000 for test 500 for PROD
            longPress = true;
            if (debug) DEBUG_PRINT("\nlong push");
          }
        }
        delay(500);
        setPowerRail(ON);
        if(longPress){
          //wait to release the button
          while(!onOff->refresh());
          isSystemON = true;
        }
      }else{
        if (debug) DEBUG_PRINT("\nbutton not pressed at boot");        
        // Enter deep sleep mode to save power
        goDeepSleep();
      }

      tft.init(true);
            //tft.invertDisplay(1);
      tft.setRotation(1); 

      xTaskCreatePinnedToCore(xTaskBackground, "backgroundTask", 4096, NULL, 1, taskHandle, 0);
      //xTaskCreatePinnedToCore(xTaskEth, "ethtask", 4096, NULL, 0, NULL, 0);
      
      attachInterrupt(digitalPinToInterrupt(ONOFF_PIN), [] {
        if (millis() - DebounceTimer >= delayTime ) {
          DebounceTimer = millis();
          if (millis() - lastInterrupt > delayRepeatTime){
            onOffPsuhedStartTime = millis();
            lastInterrupt = millis();
            ets_printf("\n\n\t\tPressed");
          }
        }
      }, RISING);      

      //debugTFTSetup();
    }

    void startAP(const String* apName){
      network->WiFiEnabled = false ; // we shutdown STA
      if (ap == nullptr){
        ap = new AccessPoint(apName, true); 
        hwComponents.add(ap);
        //if (debug) DEBUG_PRINT("\n setting the configMedia to ap");
      }
      ap->init();
      configMedia = ap;
      configIP = configMedia->IP.toString();
    }

    bool refresh(bool force=false) {  
      refreshed = force;
      // refresh components            
      for(int i = 0; i < hwComponents.size(); i++) refreshed |= hwComponents.get(i)->refresh(force);
 
      return refreshed;
    }

    TFT_eSPI* getDisplay(){
      return &tft;
    }

    void setPowerRail(bool state){
    /* One thing to keep in mind is that when you disable the power to the sensor by turning off the transistor you would also want to be sure 
    to set the pins used for SCL and SDA as INPUT's (high-z state) so that the sensor doesn't try to draw power through some odd 
    internal wiring that might find either of those lines > 0V.      
    */
      if (state == OFF){
        isSystemON = false;          
        network->stop();         
        tft.fillScreen(TFT_BLACK);
        // set SCL / SDA as input
      }  
      powerRail.state = state;
      powerRail.refresh();      
    }

    void setWiFi(JsonList* wiFiList, String ssid) {      
      if (network != nullptr) network->setWiFi(wiFiList,ssid);
    }

    void setButtonReactivity(uint8_t push, uint8_t dClic){
      default_button_pushDelay = push;
      default_button_dClicdelay = dClic;
      for (uint8_t b=0;b<MAXB;b++) buttons[b]->setReactivity(&default_button_pushDelay,&default_button_dClicdelay);
    }

    #ifdef DEBUG
    int8_t getPinName(int8_t pin)
    {
      // For ESP32 and RP2040 pin labels on boards use the GPIO number
      if (user.esp == 0x32 || user.esp == 0x2040) return pin;

      if (user.esp == 0x8266) {
        // For ESP8266 the pin labels are not the same as the GPIO number
        // These are for the NodeMCU pin definitions:
        //        GPIO       Dxx
        if (pin == 16) return 0;
        if (pin ==  5) return 1;
        if (pin ==  4) return 2;
        if (pin ==  0) return 3;
        if (pin ==  2) return 4;
        if (pin == 14) return 5;
        if (pin == 12) return 6;
        if (pin == 13) return 7;
        if (pin == 15) return 8;
        if (pin ==  3) return 9;
        if (pin ==  1) return 10;
        if (pin ==  9) return 11;
        if (pin == 10) return 12;
      }

      if (user.esp == 0x32F) return pin;

      return -1; // Invalid pin
    }
    #endif
  
    void debugTFTSetup(){
    #ifdef DEBUG
      tft.getSetup(user); //

      Serial.print("\n[code]\n");

      Serial.print ("TFT_eSPI ver = "); Serial.println(user.version);
      #if defined (ESP32) || defined (ESP8266)
        if (user.esp < 0x32F000 || user.esp > 0x32FFFF) { Serial.print("Frequency    = "); Serial.print(ESP.getCpuFreqMHz());Serial.println("MHz"); }
      #endif
      #ifdef ESP8266
        Serial.print("Voltage      = "); Serial.print(ESP.getVcc() / 918.0); Serial.println("V"); // 918 empirically determined
      #endif
      Serial.print("Transactions = "); Serial.println((user.trans  ==  1) ? "Yes" : "No");
      Serial.print("Interface    = "); Serial.println((user.serial ==  1) ? "SPI" : "Parallel");
      #ifdef ESP8266
      if (user.serial ==  1){ Serial.print("SPI overlap  = "); Serial.println((user.overlap == 1) ? "Yes\n" : "No\n"); }
      #endif
      if (user.tft_driver != 0xE9D) // For ePaper displays the size is defined in the sketch
      {
        Serial.print("Display driver = "); Serial.println(user.tft_driver, HEX); // Hexadecimal code
        Serial.print("Display width  = "); Serial.println(user.tft_width);  // Rotation 0 width and height
        Serial.print("Display height = "); Serial.println(user.tft_height);
        Serial.println();
      }
      else if (user.tft_driver == 0xE9D) Serial.println("Display driver = ePaper\n");

      if (user.r0_x_offset  != 0)  { Serial.print("R0 x offset = "); Serial.println(user.r0_x_offset); } // Offsets, not all used yet
      if (user.r0_y_offset  != 0)  { Serial.print("R0 y offset = "); Serial.println(user.r0_y_offset); }
      if (user.r1_x_offset  != 0)  { Serial.print("R1 x offset = "); Serial.println(user.r1_x_offset); }
      if (user.r1_y_offset  != 0)  { Serial.print("R1 y offset = "); Serial.println(user.r1_y_offset); }
      if (user.r2_x_offset  != 0)  { Serial.print("R2 x offset = "); Serial.println(user.r2_x_offset); }
      if (user.r2_y_offset  != 0)  { Serial.print("R2 y offset = "); Serial.println(user.r2_y_offset); }
      if (user.r3_x_offset  != 0)  { Serial.print("R3 x offset = "); Serial.println(user.r3_x_offset); }
      if (user.r3_y_offset  != 0)  { Serial.print("R3 y offset = "); Serial.println(user.r3_y_offset); }

      if (user.pin_tft_mosi != -1) { Serial.print("MOSI    = "); Serial.print("GPIO "); Serial.println(getPinName(user.pin_tft_mosi)); }
      if (user.pin_tft_miso != -1) { Serial.print("MISO    = "); Serial.print("GPIO "); Serial.println(getPinName(user.pin_tft_miso)); }
      if (user.pin_tft_clk  != -1) { Serial.print("SCK     = "); Serial.print("GPIO "); Serial.println(getPinName(user.pin_tft_clk)); }

      #ifdef ESP8266
      if (user.overlap == true)
      {
        Serial.println("Overlap selected, following pins MUST be used:");

                                  Serial.println("MOSI     = SD1 (GPIO 8)");
                                  Serial.println("MISO     = SD0 (GPIO 7)");
                                  Serial.println("SCK      = CLK (GPIO 6)");
                                  Serial.println("TFT_CS   = D3  (GPIO 0)\n");

        Serial.println("TFT_DC and TFT_RST pins can be user defined");
      }
      #endif
      String pinNameRef = "GPIO ";
      #ifdef ESP8266
        pinNameRef = "PIN_D";
      #endif

      if (user.esp == 0x32F) {
        Serial.println("\n>>>>> Note: STM32 pin references above D15 may not reflect board markings <<<<<");
        pinNameRef = "D";
      }
      if (user.pin_tft_cs != -1) { Serial.print("TFT_CS   = " + pinNameRef); Serial.println(getPinName(user.pin_tft_cs)); }
      if (user.pin_tft_dc != -1) { Serial.print("TFT_DC   = " + pinNameRef); Serial.println(getPinName(user.pin_tft_dc)); }
      if (user.pin_tft_rst!= -1) { Serial.print("TFT_RST  = " + pinNameRef); Serial.println(getPinName(user.pin_tft_rst)); }

      if (user.pin_tch_cs != -1) { Serial.print("TOUCH_CS = " + pinNameRef); Serial.println(getPinName(user.pin_tch_cs)); }

      if (user.pin_tft_wr != -1) { Serial.print("TFT_WR   = " + pinNameRef); Serial.println(getPinName(user.pin_tft_wr)); }
      if (user.pin_tft_rd != -1) { Serial.print("TFT_RD   = " + pinNameRef); Serial.println(getPinName(user.pin_tft_rd)); }

      if (user.pin_tft_d0 != -1) { Serial.print("\nTFT_D0   = " + pinNameRef); Serial.println(getPinName(user.pin_tft_d0)); }
      if (user.pin_tft_d1 != -1) { Serial.print("TFT_D1   = " + pinNameRef); Serial.println(getPinName(user.pin_tft_d1)); }
      if (user.pin_tft_d2 != -1) { Serial.print("TFT_D2   = " + pinNameRef); Serial.println(getPinName(user.pin_tft_d2)); }
      if (user.pin_tft_d3 != -1) { Serial.print("TFT_D3   = " + pinNameRef); Serial.println(getPinName(user.pin_tft_d3)); }
      if (user.pin_tft_d4 != -1) { Serial.print("TFT_D4   = " + pinNameRef); Serial.println(getPinName(user.pin_tft_d4)); }
      if (user.pin_tft_d5 != -1) { Serial.print("TFT_D5   = " + pinNameRef); Serial.println(getPinName(user.pin_tft_d5)); }
      if (user.pin_tft_d6 != -1) { Serial.print("TFT_D6   = " + pinNameRef); Serial.println(getPinName(user.pin_tft_d6)); }
      if (user.pin_tft_d7 != -1) { Serial.print("TFT_D7   = " + pinNameRef); Serial.println(getPinName(user.pin_tft_d7)); }

      #if defined (TFT_BL)
        Serial.print("\nTFT_BL           = " + pinNameRef); Serial.println(getPinName(user.pin_tft_led));
        #if defined (TFT_BACKLIGHT_ON)
          Serial.print("TFT_BACKLIGHT_ON = "); Serial.println(user.pin_tft_led_on == HIGH ? "HIGH" : "LOW");
        #endif
      #endif

      Serial.println();

      uint16_t fonts = tft.fontsLoaded();
      if (fonts & (1 << 1))        Serial.print("Font GLCD   loaded\n");
      if (fonts & (1 << 2))        Serial.print("Font 2      loaded\n");
      if (fonts & (1 << 4))        Serial.print("Font 4      loaded\n");
      if (fonts & (1 << 6))        Serial.print("Font 6      loaded\n");
      if (fonts & (1 << 7))        Serial.print("Font 7      loaded\n");
      if (fonts & (1 << 9))        Serial.print("Font 8N     loaded\n");
      else
      if (fonts & (1 << 8))        Serial.print("Font 8      loaded\n");
      if (fonts & (1 << 15))       Serial.print("Smooth font enabled\n");
      Serial.print("\n");

      if (user.serial==1)        { Serial.print("Display SPI frequency = "); Serial.println(user.tft_spi_freq/10.0); }
      if (user.pin_tch_cs != -1) { Serial.print("Touch SPI frequency   = "); Serial.println(user.tch_spi_freq/10.0); }

      Serial.println("[/code]");    
    #endif
    }
 
  private:
    #ifdef DEBUG
      setup_t user;
    #endif

    LinkedList<HWComponent*> hwComponents = LinkedList<HWComponent*>();     
    uint8_t default_button_pushDelay = 2;  // 1 to 3
    uint8_t onOff_button_pushDelay = 3;
    uint8_t default_button_dClicdelay = 1; // 0 to 2
};


