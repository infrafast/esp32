#ifndef Interval_h
#define Interval_h


#include <Arduino.h>
#include <LinkedList.h>
#include <ArduinoJson.h>
#include <vector>


#ifdef DEBUG
  #define DEBUG_PRINT(...) Serial.printf(__VA_ARGS__); Serial.flush() //ets_printf
#else
  #define DEBUG_PRINT(...)
#endif

#ifdef C3
  #warning "COMPILING FOR C3"  
#else
  #ifdef S3
    #warning "COMPILING FOR S3"
    //#define USE_DMA
  #else
    #error ONLY seeed_xiao_esp32c3 or seeed_xiao_esp32s3 
  #endif
#endif

#ifdef USE_NETWORK
  #warning "USE NETWORK"
#else
  #warning "AP ONLY"
#endif

#define DEFAULT_STORAGE_TYPE_ESP32 STORAGE_LITTLEFS

union ScreenUnion{
  int16_t value;
  struct {
    uint8_t id ;
    uint8_t state ;
  };
} ;
ScreenUnion screen;

//typedef void (BaseManager::*GUIScreenBuilderCallBack)(uint8_t);

class GenericComponent{
  protected:
    bool debug = true;    
    
 
  public:
    String id="GenericComponent";
    bool refreshed = false; 

    GenericComponent(bool d=false){
      debug=d;    
    }

    virtual ~GenericComponent(){
      if (debug){
        DEBUG_PRINT("\n~%s()",id.c_str());
      }
    }

    virtual bool refresh(bool force=false) = 0;  
    virtual void init(){
      if (debug){
        DEBUG_PRINT("\n%s.init()",id.c_str());
      }
    };

};

// general purpose utility functions
uint8_t countChar(String s, char c){
    uint8_t res = 0;
    for (int i=0;i<s.length();i++) if (s.charAt(i) == c) res++;
    return res;
}

uint8_t countWord(String str, String sub) {
    uint8_t count = 0;
    int index = 0;
    
    // Iterate through the string
    while ((index = str.indexOf(sub, index)) != -1) {
        // Increment count and move the index past this occurrence
        count++;
        index += sub.length();
    }
    
    return count;
}

float truncateToOneDecimal(float num) {
    return ((int)(num * 10.0)) / 10.0;
}

float roundHalf(float nombre) {
    return round(nombre * 2) / 2.0;
}

void removeJsonQuote(String* buffer){
  buffer->replace("\"{","{");   
  buffer->replace(":\"{",":{");  
  buffer->replace("}\"}","}}");      
  buffer->replace("}\"","}");   
  buffer->replace("\\","");
}

int32_t getMaxAlloc(){
  uint32_t freeHeap = ESP.getMaxAllocHeap();
  int32_t maxDocMemAlloc = freeHeap-20000;
  if (maxDocMemAlloc<0) maxDocMemAlloc = 5000;  
  return maxDocMemAlloc;
}

typedef struct  {
  String key;
  String value;
} KeyValue;
#define KV_UNIT_SIZE 32 // according to arduinojson assistant its 32

class JsonList{

  public:

    JsonList(){}

    int size(){
      return keyValues.size();
    }

    void serialize(String* buffer){
      int32_t docSize = KV_UNIT_SIZE * keyValues.size();
      DynamicJsonDocument doc(docSize);
      for (uint8_t i=0;i<keyValues.size();i++){
        KeyValue* kv = keyValues.get(i);        
        doc[kv->key] = kv->value;
      }
      serializeJson(doc, *buffer);
      //DEBUG_PRINT("\n\nBEFORE\t\t%s",buffer->c_str());
      removeJsonQuote(buffer);
      //DEBUG_PRINT("\n\nAFTER\t\t%s",buffer->c_str());
    }

    void deserialize(String kvPair){
      // estimate the number of key:value by counting the number of :
      uint8_t keyValueCount = countChar(kvPair,':');
      //DEBUG_PRINT("\ndeserialize <%s>: count: %i",kvPair.c_str(),keyValueCount);
      int32_t docSize = KV_UNIT_SIZE * keyValueCount;
      DynamicJsonDocument doc(docSize);
      DeserializationError error;
      error = deserializeJson(doc,kvPair );
      if (!error) jsonToKeyValues(&doc);
      else{
        DEBUG_PRINT("\t => %s",error.c_str());
      }  
    }

    virtual const String* getString(const String name, const String defaultValue="") {
      int8_t index;
      index = getIndex(name);
      if (index < 0) {
        noToken = defaultValue;
        return &noToken;
      } else {
        KeyValue* kv = keyValues.get(index);
        return &kv->value;
      }
    };

    bool setValue(String name, String value) {
      bool ret = false;
      int8_t index;
      index = getIndex(name);
      if (index>-1){
        DEBUG_PRINT("\nsetValue=>");
        ret = updateValue(index,value);
      }
      return ret;
    };

    bool addValue(String name, String value) {
        bool ret = false;
        int8_t index = getIndex(name);
        if (index == -1){  // if not existing
          KeyValue* kv = new KeyValue;
          kv->key = name;
          kv->value = value;
          if (keyValues.add(kv)){
            ret = true;
            /*DEBUG_PRINT("\n\taddValue(<%s>,",name.c_str());
            DEBUG_PRINT("<%s>)",value.c_str());*/
          }
        }else{  // value exists, we update it
          ret = updateValue(index,value);
        }
        return ret;
    };
    
    bool deleteValue(String name){
      int8_t index = getIndex(name);
      //DEBUG_PRINT("\nsize before delete: %i",keyValues.size());
      if (index >= 0) {  
        delete(keyValues.remove(index));
        /*DEBUG_PRINT("\n\t{deleteValue(%s)}",name.c_str());
        DEBUG_PRINT("\nsize after delete: %i",keyValues.size());*/
        return true;
      }else return false;
    }

    int16_t getIndex(String name) {
      int16_t i = 0;
        for(; i < keyValues.size(); i++){
          KeyValue* kv = keyValues.get(i);
          if (kv->key == name) return i;
        }
      return -1;
    }    

    String getName(uint8_t index){
      if (index>keyValues.size()) return "";
      else{
        KeyValue* kv = keyValues.get(index);
        return kv->key;
      }
    }    
    
  protected:  
    LinkedList<KeyValue*> keyValues = LinkedList<KeyValue*>(); 

    bool updateValue(uint8_t index, String value){
      KeyValue* kv = keyValues.get(index);
      kv->value = value;
      //DEBUG_PRINT("\n\t{updateValue[%i](%s,%s)}",index,getName(index).c_str(),value.c_str());
      return true;
    }

    void jsonToKeyValues(DynamicJsonDocument* doc){
      JsonObject root = doc->as<JsonObject>();
      for (JsonPair kv : root){
        addValue(kv.key().c_str(),kv.value().as<String>());
      }
    }        
  
  private:
    String noToken = "";    
};



TaskHandle_t *taskHandle;
unsigned long onOffPsuhedStartTime = 0;
RTC_DATA_ATTR bool isSystemON = false;
bool pushBuffer = false, clearBuffer = false;

void goDeepSleep();

void xTaskBackground(void *pvParameters);
//void xTaskEth(void *pvParameters);

#include "HWManager.h"
#include "GUIManager.h"
#include "APPManager.h"

HardwareManager hwm;
TFT_eSPI* GUI::tft = &hwm.tft;
GUIManager gui(false);
OpenFontRender* Label::ofr = &gui.labelOfr;
OpenFontRender* Icon::ofr = &gui.iconOfr;
ApplicationManager app(&hwm,&gui);
DataRepository* StripSkeleton::dataRepo = &app.dataRepository;

void goDeepSleep(){
    // SHUTDOWN
  // One thing to keep in mind is that when you disable the power to the sensor by turning off the transistor 
  // you would also want to be sure to set the pins used for SCL and SDA as INPUT's (high-z state)
  // so that the sensor doesn't try to draw power through some odd internal wiring that might find either of those lines > 0V.     
  // Watch out for floating inputs, they consume power.
  // high side switch
  // High Side transistor switch (PNP BJT or P-Channel MOSFET)    
  // best one : https://forum.arduino.cc/t/mosfet-as-a-power-switch-for-low-power-consumption/882239/6
  // and https://arduino.stackexchange.com/questions/43986/is-there-a-way-to-power-off-external-devices-during-deep-sleep
  // open question: reset the devices ? when back, it will take time to power them on again, how to sync it with the class creation, etc... ?
  DEBUG_PRINT("\n SHUTTING DOWN");
  hwm.setPowerRail(OFF);    
  #ifdef DEBUG
    while(1);
  #endif
  esp_deep_sleep_start();  

}

/*void xTaskEth(void *pvParameters){
  while (1) hwm.network->cable = Ethernet.linkStatus();
}*/


void xTaskBackground(void *pvParameters){
  static unsigned long checkEthCableTime = 0;
  while (true){
  
    vTaskDelay(1);  //added for S3 to avoid trigerring the wathcdog

    if (millis()-checkEthCableTime > 1000 && hwm.network->ethEnabled){   // only if we use the full network stack and not only AP mode
      hwm.network->setLink(Ethernet.linkStatus());
      checkEthCableTime = millis();
    }
    
    // watch the switch off button only if it was pushed

    if (onOffPsuhedStartTime !=0 && digitalRead(ONOFF_PIN)==HIGH){
      long push = millis()-onOffPsuhedStartTime;
      //ets_printf("\n\t\t%u",push);
      if (abs(push)>1900){
        ets_printf("\nthresold");
        screen.id = SCREEN_BYE; 
        screen.state = STATE_BYE_SAY_GOODBYE;
        // It's ok, if the program is stuck it won't black screen but at least it 
        // wait the switch to change state, the loop program continues normally
        ets_printf("\n\t\ton/off pushed for %u ms",push);
        while (digitalRead(ONOFF_PIN)==HIGH){
          ets_printf(".");
        }
        goDeepSleep();
      }
    }else{
      onOffPsuhedStartTime = millis();
    }

    if (pushBuffer){
      //For some reason DMA requires that a MISO pin is defined. If you do not have a spare then you can allocate it to be the same as the TFT_CS line and it will work, e.g. in your case add the following to the setup file:
      //#define TFT_MISO 17
      //https://github.com/Bodmer/TFT_eSPI/discussions/2233
      //ets_printf("\npushBuffer");
      gui.screenBuffer.pushSprite(0,0);    
      pushBuffer = false;
    }else if (clearBuffer){
      //ets_printf("\nclearBuffer");
      gui.screenBuffer.fillSprite(TFT_BGCOLOR);        
      clearBuffer = false;
    }              
  }
}

void webAppCallbackWrapper(Request &req, Response &res) {
  app.fileServer(req,res);
}

void OnWiFiEvent(WiFiEvent_t event){
  switch (event) {
    case ARDUINO_EVENT_WIFI_READY:
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_WIFI_READY");
    break;
    case ARDUINO_EVENT_WIFI_STA_START:
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_WIFI_STA_START");
    break;    
    case ARDUINO_EVENT_WIFI_STA_STOP:
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_WIFI_STA_STOP");
    break;
    case ARDUINO_EVENT_WIFI_STA_CONNECTED:
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_WIFI_STA_CONNECTED");
    break;
    case ARDUINO_EVENT_WIFI_STA_GOT_IP:
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_WIFI_STA_GOT_IP");
    break;
    case ARDUINO_EVENT_WIFI_AP_STOP: //SYSTEM_EVENT_STA_STOP:
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_WIFI_AP_STOP");
    break;
    case ARDUINO_EVENT_WIFI_STA_DISCONNECTED: //SYSTEM_EVENT_STA_DISCONNECTED:
      DEBUG_PRINT("~");
    break;
    case ARDUINO_EVENT_WIFI_AP_START: //SYSTEM_EVENT_AP_START:
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_WIFI_AP_START");
      break;
    case ARDUINO_EVENT_WIFI_AP_STACONNECTED: //SYSTEM_EVENT_AP_STACONNECTED:
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_WIFI_AP_STACONNECTED");
      break;
    case ARDUINO_EVENT_WIFI_AP_STADISCONNECTED: //SYSTEM_EVENT_AP_STADISCONNECTED:
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_WIFI_AP_STADISCONNECTED");
      //hwm.ap->state = DISCONNECTED;
      break;
    case ARDUINO_EVENT_WIFI_AP_STAIPASSIGNED: //SYSTEM_EVENT_AP_STAIPASSIGNED:
      //hwm.ap->state = CONNECTED;
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_WIFI_AP_STAIPASSIGNED");
    break;
    case ARDUINO_EVENT_ETH_START:
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_ETH_START");
    break;
    case ARDUINO_EVENT_ETH_STOP:
      DEBUG_PRINT("\nEVENT-WIFI: ARDUINO_EVENT_ETH_STOP");
    break;
    case ARDUINO_EVENT_WIFI_STA_LOST_IP:
      DEBUG_PRINT("\nEVENT-WIFI: ARDUINO_EVENT_WIFI_STA_LOST_IP");
    break;
    case ARDUINO_EVENT_ETH_CONNECTED:
      DEBUG_PRINT("\nEVENT-WIFI: ARDUINO_EVENT_ETH_CONNECTED");
    break;
    case ARDUINO_EVENT_ETH_DISCONNECTED:
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_ETH_DISCONNECTED");
    break;
    case ARDUINO_EVENT_ETH_GOT_IP:
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: ARDUINO_EVENT_ETH_GOT_IP");
    break;
    default: 
      DEBUG_PRINT("\n\t\t\tEVENT-WIFI: %i",event);
    break;
  }
}

/*
String minSec,testString="jtestSTRING-123g",connectionState="",vBat="",milli3,milli4;
String longText="The Game of Life, also known simply as Life, is a cellular automaton devised by the British mathematician John Horton Connway in 1970.";
int16_t midVertical = 120, belowTop = 35, topScreen = 10, leftScreen = 10, bottomScreen = 220, x1=40, x2=100, x3=130, x4=200;
int16_t m2 = belowTop + 32;
int16_t m3 = belowTop + 64;
bool onOff = true;

int16_t xa = 20, xb=90, xc=220;
float negative = -5.5, positive = 5; 
String db="dB",ms="ms";*/

//////////////////////////////////////////////////////////////
////                BUTTONS CALLBACKS UTILITIES        ///////
//////////////////////////////////////////////////////////////
void handleSwitchScreen(uint8_t buttonID){
  if (buttonID == MIDDLEB_ID){
    app.moduleMenu->select();
    app.setMenuSwitchModuleItems();
  }else{
    if (buttonID == LEFTB_ID) app.moduleMenu->next(true);
    else app.moduleMenu->prev(true);
    app.menuSwitchModuleFullRefresh();
  }   
}

void handleMenuButton(uint8_t buttonID){
  if (buttonID == MIDDLEB_ID){
    app.ms.select();
    app.setMenuSystemItems();
  }else{
    if (buttonID == LEFTB_ID) app.ms.next(true);
    else app.ms.prev(true);
    app.menuSystemFullRefresh();
  }      
}

void moduleSimpleClic(uint8_t buttonID){
  // perform the behaviour defined in the config file
  // at the moment, this is hard coded
  if (buttonID == MIDDLEB_ID){
    if (!app.stripAction()){
      DEBUG_PRINT("\nAction failed!!!");
      // code if execution fails: example: popup a message with the error
    }
  }
  else app.stripScroll(buttonID);
}


void moduleHoldClic(uint8_t buttonID, unsigned long time){
  // perform the behaviour defined in the config file
  // at the moment, this is hard coded
  if (!app.stripChangeValue(buttonID, time)){
    DEBUG_PRINT("\nAction failed!!!");
    // code if execution fails: example: popup a message with the error
  }    
}

void moduleLongClic(uint8_t buttonID){
  if (buttonID == MIDDLEB_ID){
    // if we have one module or two we shift directly
    if (app.modules.size()<=2) screen.state = (screen.state + 1) % app.modules.size(); // <=2
    // otherwise we call the menu
    else screen.id = SCREEN_MODULE_SWITCH;
  }else app.testOSC();
}

//////////////////////////////////////////////////////////////
////                BUTTONS CALLBACKS                  ///////
//////////////////////////////////////////////////////////////
void menuSwitchCallback(uint8_t buttonID, unsigned long time=0){
  if (screen.id == SCREEN_MENU){   //set GUI
    app.restoreScreen();
  }else{
    app.restoreMenu();
  } 
}

void simpleClicCallBack(uint8_t buttonID, unsigned long time){
  switch(screen.id){
    case SCREEN_STARTUP:

    break;
    case SCREEN_CONNECTION_WIZARD:
      
    break;
    case SCREEN_MENU:
      handleMenuButton(buttonID);   
    break;
    case SCREEN_MODULE_SWITCH:
      handleSwitchScreen(buttonID);
    break;
    case SCREEN_PROMPT:

    break;
    case SCREEN_UTILS:
      switch(screen.state){
        case STATE_UTILS_SEARCHING_CONNECTION:

        break;
        case STATE_UTILS_INFO:
          app.restoreMenu();  // any button calls the method
        break;
        case STATE_UTILS_WEBAPPCONNECTED:
          app.restoreScreen();
        break;
      }
    break;
    case SCREEN_MODULE:
      DEBUG_PRINT("\nsimpleClicCallBack: %i",buttonID);
      moduleSimpleClic(buttonID);      
    break;
  }
}

void longClicCallBack(uint8_t buttonID, unsigned long time){
  switch(screen.id){
    case SCREEN_STARTUP:

    break;
    case SCREEN_CONNECTION_WIZARD:

    break;
    case SCREEN_MENU:
      handleMenuButton(buttonID);
    break;
    case SCREEN_PROMPT:

    break;
    case SCREEN_UTILS:
      switch(screen.state){
        case STATE_UTILS_SEARCHING_CONNECTION:

        break;
        case STATE_UTILS_INFO:
          app.restoreMenu();  // any button calls the method
        break;
        case STATE_UTILS_WEBAPPCONNECTED:
          app.restoreScreen();
        break;
      }
    break;
    case SCREEN_MODULE:
      moduleLongClic(buttonID);
      DEBUG_PRINT("\nlongClicCallBack: %i",buttonID);
    break;
  }  
}

void doubleClicCallBack(uint8_t buttonID, unsigned long time){
  switch(screen.id){
    case SCREEN_STARTUP:

    break;
    case SCREEN_CONNECTION_WIZARD:

    break;
    case SCREEN_MENU:
    
    break;
    case SCREEN_PROMPT:

    break;
    case SCREEN_UTILS:
      switch(screen.state){
        case STATE_UTILS_SEARCHING_CONNECTION:

        break;
        case STATE_UTILS_INFO:

        break;
      }
    break;
    case SCREEN_MODULE:
      DEBUG_PRINT("\ndoubleClicCallBack: %i",buttonID);
      app.broadCast("{\"mixerIP\":\"192.168.199.199\"}");
    break;
  }  
}

void releaseHoldCallback(uint8_t buttonID, unsigned long time){
  switch(screen.id){
    case SCREEN_STARTUP:

    break;
    case SCREEN_CONNECTION_WIZARD:

    break;
    case SCREEN_MENU:
      handleMenuButton(buttonID);
    break;
    case SCREEN_PROMPT:

    break;
    case SCREEN_UTILS:
      switch(screen.state){
        case STATE_UTILS_SEARCHING_CONNECTION:

        break;
        case STATE_UTILS_INFO:
          app.restoreMenu();  // any button calls the method
        break;
        case STATE_UTILS_WEBAPPCONNECTED:
          app.restoreScreen();
        break;
      }
    break;
    case SCREEN_MODULE:
      DEBUG_PRINT("\nreleaseHoldCallback: %i",buttonID);
    break;
  }  
}

void holdCallback(uint8_t buttonID, unsigned long time){
  switch(screen.id){
    case SCREEN_STARTUP:

    break;
    case SCREEN_CONNECTION_WIZARD:

    break;
    case SCREEN_MENU:
    
    break;
    case SCREEN_PROMPT:

    break;
    case SCREEN_UTILS:
      switch(screen.state){
        case STATE_UTILS_SEARCHING_CONNECTION:

        break;
        case STATE_UTILS_INFO:

        break;
      }
    break;
    case SCREEN_MODULE:
      moduleHoldClic(buttonID, time);  
    break;
  }  
}

//////////////////////////////////////////////////////////////
////                MENU ACTION ITEM CALLBACKS         ///////
//////////////////////////////////////////////////////////////

void back_menu_item_selected(MenuComponent* p_menu_component) {
  DEBUG_PRINT("\nback_menu_item_selected: ");
  if (!app.ms.back()) app.restoreScreen();    
  else app.menuSystemFullRefresh();
}

void save_profile_item_selected(MenuComponent* p_menu_component) {
  DEBUG_PRINT("\nsave_profile_item_selected ");
}


void info_item_selected(MenuComponent* p_menu_component) {  
  DEBUG_PRINT("\ninfo item selected: id:%i",p_menu_component->get_name());
  screen.id = SCREEN_UTILS;
  screen.state = STATE_UTILS_INFO;
}

void handleConfigConnection(){
  DEBUG_PRINT("\nhandleConfigConnection");
  // socket is opened between footswitch and browser, hence we indicate the connection is made
  if (app.webAppConnected){
      screen.id = SCREEN_UTILS;
      screen.state = STATE_UTILS_WEBAPPCONNECTED;    
  }else{
  // socket is not connected so we launch the webapp
    if (app.startWebApp()){
      screen.id = SCREEN_UTILS;
      screen.state = STATE_UTILS_CONNECTWEBAPP;    
      /*app.widgets[MENU_ICON_MIDDLE].widget->setFcolor(&GUI::green);
      app.topLabelItem = *app.lang.getString("Open browser http://")+hwm.network->mainIP.toString();
      app.widgets[CONFIG_TEXTAREA_MESSAGE].widget->setText(&app.topLabelItem);*/
    }else{
      // There is no valid connection, so we launch AP mode    
      screen.id = SCREEN_UTILS;
      screen.state = STATE_UTILS_CONNECTCONFIGMEDIA;
      hwm.startAP(app.system.getString(S_AP_NAME));
      app.setAPandNetIcons();
      //https://deepbluembedded.com/esp32-wifi-library-examples-tutorial-arduino/#esp32-wifi-modes
      /*app.widgets[MENU_ICON_MIDDLE].widget->setFcolor(&GUI::red);
      app.widgets[CONFIG_TEXTAREA_MESSAGE].widget->setText(app.lang.getString("Error"));*/
    }  
  }
}

void config_menu_item_selected(MenuComponent* p_menu_component){  
  handleConfigConnection();
}

void loadLang_item_selected(MenuComponent* p_menu_component){
  const char* menuString = p_menu_component->get_name();
  String langName = app.getNameFromString(menuString);
  // load should return a boolean which indicate if the lanugage file has been loaded correctly to 
  // process the semantic return and update the menu title accordingly if it was loaded or not
  if (app.lang.load("/"+langName+".lang")){
    app.system.setValue(S_LANG,langName);
    app.menuActiveIconColor = TFT_GREEN;
    app.glowingGoldColor.value = &GUI::unUsedColor;
    app.system.save();
    //app.widgets[MENU_ICON_MIDDLE].widget->setFcolor(&GUI::green);
  }else{
    //app.widgets[MENU_ICON_MIDDLE].widget->setFcolor(&GUI::red);
    app.menuActiveIconColor = TFT_RED;
    app.glowingGoldColor.value = &GUI::unUsedColor;
    app.widgets[CONFIG_TEXTAREA_MESSAGE]->setText(app.lang.getString("File Error"));
  }

}

void switchToModule_item_selected(MenuComponent* p_menu_component){
  DEBUG_PRINT("\n%s",p_menu_component->get_name());
  screen.id = SCREEN_MODULE;
  screen.state = 0;
  for (; screen.state < app.modules.size(); screen.state++){
    if (app.modules.get(screen.state)->name == p_menu_component->get_name()) break;
  }
}

void menu_selected(MenuComponent* p_menu_component){
  DEBUG_PRINT("\n\t\t ====> MENU %s SELECTED %s<====",p_menu_component->get_name());
  
  if (strcmp(p_menu_component->get_name(),app.langMenuString) == 0){
    // this doesn't work as the app.ms selected scrool the item above LANG and not LANG itself since the menuSelected action is not complete yet (we are inside)
    /*for (int i = 0; i < app.langMenu->get_num_components(); ++i) {
      MenuComponent const* cp_m_comp = app.langMenu->get_menu_component(i);
      String country = String(cp_m_comp->get_name()).substring(2,String(cp_m_comp->get_name()).length());
      DEBUG_PRINT("\n%s <-> %s",cp_m_comp->get_name(),app.system.getString(S_LANG)->c_str());              
      if (strcmp(country.c_str(),app.system.getString(S_LANG)->c_str()) == 0) break;
      DEBUG_PRINT("\t[%s]",app.langMenu->get_current_component()->get_name());              
      app.ms.next(true);
      DEBUG_PRINT("\t[%s]",app.langMenu->get_current_component()->get_name());              
    } */  
  }
}


//////////////////////////////////////////////////////////////
////                SCREENBUILDERS CALLBACKS           ///////
//////////////////////////////////////////////////////////////

void voidOverlay(uint8_t id){DEBUG_PRINT("\nvoidOverlay()");}

void overLayBuilder(uint8_t id){
  /*GUI::tft->fillRect(0,app.overlayIconY,TFT_WIDTH,OVERLAY_ICON_SIZE,GUI::overlayIconBackgroundColor);
  GUI::tft->drawFastHLine(0,app.overlayIconY-1,TFT_WIDTH,TFT_SILVER);*/
  gui.add(new Icon(&app.networkIcon,Align::Left,&GUI::zero, &app.overlayIconY,OVERLAY_ICON_SIZE,&app.networkIconColor,&GUI::defaultBcolor,false));                
  gui.add(new Icon(&app.apIcon,Align::Left,&app.apIconPosX, &app.overlayIconY,OVERLAY_ICON_SIZE,&app.apIconColor,&GUI::defaultBcolor,false));                  
  gui.add(new Icon(&app.batIcon,Align::Left,&app.batIconPosX, &app.overlayIconY,OVERLAY_ICON_SIZE,&app.batIconColor,&GUI::defaultBcolor,false));                  
}

void moduleScreenBuilder(uint8_t subScreen){
  GUI::defaultBcolor = TFT_BGCOLOR;
  GUI::defaultFcolor = TFT_FCOLOR;
  GUI::cls();
  
  Module* module = app.modules.get(subScreen);
  uint8_t layout = module->currentLayout;

  switch(layout){
    case LAYOUT_QUATUOR:
    break;
    case LAYOUT_ICON:
    break;
    case LAYOUT_DETAILS: 
    default:
      DEBUG_PRINT("\nADDING MODULE SingleLayoutModule");
      SingleLayoutModule* mrs = new SingleLayoutModule(module,&gui.screenGUIs,false);
      gui.add(mrs);     
    break;
  }

  //testWidget();
}

void addTopandBottomTextLabel(){
  app.widgets[MENU_LABEL_TITLE] = new Label(&app.bottomLabelTitle, Align::Center,&app.midScreenHoriz, &app.menuTitleY,MENU_TITLE_SIZE,&GUI::defaultFcolor,&GUI::defaultBcolor,false);
  gui.add(app.widgets[MENU_LABEL_TITLE]);  
  app.widgets[CONFIG_TEXTAREA_MESSAGE] = new TextArea(&app.topLabelItem, TFT_WIDTH*0.90,Align::Center,Align::Center,&app.midScreenHoriz,&app.belowTop,CONFIG_TEXTAREA_MESSAGE_SIZE,&GUI::defaultFcolor,&GUI::defaultBcolor,false);
  gui.add(app.widgets[CONFIG_TEXTAREA_MESSAGE]);
}

void addMenuIcons(){
  GUI::cls();
  addTopandBottomTextLabel();
  app.widgets[MENU_ICON_MIDDLE] = new Icon(&app.menuItemIcon[1], Align::Center,&app.midScreenHoriz, &app.menuIconYpos,MENU_ICON_SIZE,&app.menuActiveIconColor,&GUI::defaultBcolor,false);
  gui.add(app.widgets[MENU_ICON_MIDDLE]);
  gui.add(new Icon(&app.menuItemIcon[0], Align::Center,&app.leftMenuIconXpos, &app.menuIconYpos,MENU_ICON_SIZE,&GUI::menuInactiveIconColor,&GUI::defaultBcolor,false));  
  gui.add(new Icon(&app.menuItemIcon[2], Align::Center,&app.rightMenuIconXpos, &app.menuIconYpos,MENU_ICON_SIZE,&GUI::menuInactiveIconColor,&GUI::defaultBcolor,false));    
}


void menuScreenBuilder(uint8_t subScreen){
  DEBUG_PRINT("\nmenuScreenBuilder()");  
  GUI::defaultBcolor = GUI::menuBackGroundColor;
  GUI::defaultFcolor = GUI::menuActiveIconColor;
  addMenuIcons();
}

void moduleSwitchScreenBuilder(uint8_t id){
  DEBUG_PRINT("\nmoduleSwitchScreenBuilder()");  
  GUI::defaultBcolor = TFT_BLACK;
  GUI::defaultFcolor = GUI::gold;
  addMenuIcons();
}

void byeScreenBuilder(uint8_t subScreen){
  GUI::cls();
  switch(subScreen){
    case STATE_BYE_BATTERY_AND_SLEEP:   
      addTopandBottomTextLabel();
      gui.add(new Icon(&app.batIcon,Align::Center,&app.midScreenHoriz, &app.bigWidgetMidY,WIDGET_BIG_WIDTH,&app.batIconColor,&GUI::defaultBcolor,false));                     
    break;
    case STATE_BYE_SAY_GOODBYE:
      gui.add(new Label(app.lang.getString("Bye"),Align::Center, &app.midScreenHoriz,&app.menuIconYpos, 80));
    break;
    case STATE_BYE_ERROR_AND_SLEEP:
      addTopandBottomTextLabel();
      gui.add(new Icon(&app.forbidIcon,Align::Center,&app.midScreenHoriz, &app.bigWidgetMidY,WIDGET_BIG_WIDTH,&GUI::red,&GUI::defaultBcolor,false));                     
    break;
  }    
}

void startupScreenBuilder(uint8_t id){
  gui.drawJpg(0,0,"/webapp/logo.jpg");
}

void connectionWizardScreenBuilder(uint8_t id){}

void promptScreenBuiler(uint8_t id){}


void addUtility1(){
    GUI::tft->fillScreen(GUI::menuBackGroundColor);    
    gui.add(new Icon(&app.utils1Icon1, Align::Right,&app.quarter2xPos,&app.menuIconYpos,MENU_ICON_SIZE,&app.utils1Icon1Color,&GUI::menuBackGroundColor,false));
    gui.add(new Icon(&app.utils1Icon2, Align::Left,&app.quarter3xPos,&app.menuIconYpos,MENU_ICON_SIZE,&GUI::menuActiveIconColor,&GUI::menuBackGroundColor,false));
    addTopandBottomTextLabel();    
}

void addConnectAP(){
  app.widgets[CONFIG_TEXTAREA_MESSAGE]->setText(app.lang.getString("connect WiFi")); // get AP name from config
  app.utils1Icon1 = ICON_AP;
}

void utilsScreenBuilder(uint8_t state){
  switch (state) {
    case STATE_UTILS_SEARCHING_CONNECTION:{

    }break;
    ////////////////////////////////////////////////////////////////////////////////
    case STATE_UTILS_INFO:
      DEBUG_PRINT("\n\nCPU freq:%i",getCpuFrequencyMhz());
      GUI::tft->fillScreen(GUI::menuBackGroundColor);
      app.topLabelItem = *app.lang.getString("Info item");
      gui.add(new Label(&app.topLabelItem, Align::Center,&app.midScreenHoriz, &GUI::zero,CONFIG_TEXTAREA_MESSAGE_SIZE,&GUI::menuActiveIconColor,&GUI::menuBackGroundColor,true));
      gui.add(new Label(&app.vBatLabel, Align::Center,&app.midScreenHoriz, &app.midScreenHoriz,CONFIG_TEXTAREA_MESSAGE_SIZE,&GUI::menuActiveIconColor,&GUI::menuBackGroundColor,false));      
    break;
    ////////////////////////////////////////////////////////////////////////////////
    case STATE_UTILS_CONNECTCONFIGMEDIA:
      app.configIconGlowingRedColor.value = &app.utils1Icon1Color;

      addUtility1();
      gui.add(new AnimatedIcon(app.iconCycle,2,Align::Center,&app.midScreenHoriz, &app.midScreenVertical,TFT_WIDTH/8,ANIMATE_PING_PONG,250,&GUI::widgetSubLabelColor,&GUI::menuBackGroundColor,false));              
      #ifdef USE_NETWORK
        if (!hwm.network->ethEnabled){
          //if ethernet module is absent, we only offer to connect the AP
          addConnectAP();
        }else{
          app.widgets[CONFIG_TEXTAREA_MESSAGE]->setText(app.lang.getString("Connect"));
          app.utils1Icon1 = ICON_MIXETHWIFI;
        }
      #else
        addConnectAP();
      #endif
      app.widgets[MENU_LABEL_TITLE]->setText(&hwm.configMedia->id);
      app.utils1Icon2 = ICON_LAPTOP;
      DEBUG_PRINT("\nSTATE_UTILS_CONNECTCONFIGMEDIA: %s",app.topLabelItem.c_str());
    break;
    case STATE_UTILS_CONNECTWEBAPP:
      app.configIconGlowingRedColor.value = &GUI::unUsedColor;
      app.utils1Icon1Color = GUI::menuActiveIconColor;

      addUtility1();            
      app.webAppLoadPending[0] = app.iconLink[0]; // set icon to waiting link
      app.webAppLoadPending[1] = app.iconLink[1];
      gui.add(new AnimatedIcon(app.webAppLoadPending,2,Align::Center,&app.midScreenHoriz, &app.midScreenVertical,TFT_WIDTH/8,ANIMATE_PING_PONG,250,&GUI::widgetSubLabelColor,&GUI::menuBackGroundColor,false));                    
      app.widgets[CONFIG_TEXTAREA_MESSAGE]->setText(app.lang.getString("Open browser"));
      app.widgets[MENU_LABEL_TITLE]->setText(&hwm.configIP);
      app.utils1Icon1 = ICON_LAPTOP;
      app.utils1Icon2 = ICON_FOOTSWITCH;
      DEBUG_PRINT("\nSTATE_UTILS_CONNECTWEBAPP: %s",app.topLabelItem.c_str());
    break;
    case STATE_UTILS_WEBAPPCONNECTED:   
      addUtility1();
      //gui.add(new Label(&app.configClientIP, Align::Left,&app.quarter1xPos, &app.belowMenuIcon,CONFIG_TEXTAREA_MESSAGE_SIZE,&GUI::menuActiveIconColor,&GUI::menuBackGroundColor,false));
      //gui.add(new Label(&hwm.configIP, Align::Right,&app.quarter4xPos, &app.belowMenuIcon,CONFIG_TEXTAREA_MESSAGE_SIZE,&GUI::menuActiveIconColor,&GUI::menuBackGroundColor,false));      
      gui.add(new AnimatedIcon(app.iconDot,4,Align::Center,&app.midScreenHoriz, &app.midScreenVertical,TFT_WIDTH/8,ANIMATE_PING_PONG,250,&GUI::widgetSubLabelColor,&GUI::menuBackGroundColor,false));                    
      app.widgets[MENU_LABEL_TITLE]->setText(app.lang.getString("Press button"));
      app.widgets[CONFIG_TEXTAREA_MESSAGE]->setText(app.lang.getString("Connected"));
      app.utils1Icon1 = ICON_LAPTOP;
      app.utils1Icon2 = ICON_FOOTSWITCH;
      DEBUG_PRINT("\nSTATE_UTILS_WEBAPPCONNECTED: %s",app.topLabelItem.c_str());      
    break;
    ////////////////////////////////////////////////////////////////////////////////
  }
}

//////////////////////////////////////////////////////////////
////                SOCKET CALLBACKS                   ///////
//////////////////////////////////////////////////////////////

void socketMessageCallback(IWebSocket &ws, const WebSocketDataType dataType, const char *message, uint16_t length){
  String response;
  switch (dataType) {
    case net::WebSocketDataType::TEXT:
      response = app.parseJsonInput(message);
    break;
    case net::WebSocketDataType::BINARY:
      DEBUG_PRINT("\nReceived binary");
    break;
  }
  ws.send(dataType, response.c_str(), response.length());
}

void socketCloseCallback(IWebSocket &ws, WebSocketCloseCode code, const char *reason, uint16_t length) {
  DEBUG_PRINT("\nSocket Disconnected");
  app.webAppConnected = false;
  hwm.configMedia->refreshed = true;    // this is to trigger app manager to refresh the screen showing how to connect.
}


void socketConnectionCallback(IWebSocket &ws) {

  app.webAppConnected = true;

  const auto protocol = ws.getProtocol();
  if (protocol) {
    DEBUG_PRINT("\nProtocol: %i",protocol);
  }

  ws.onMessage(socketMessageCallback);
  ws.onClose(socketCloseCallback);

  app.configClientIP = ws.getRemoteIP().toString();
  DEBUG_PRINT("\nNew websocket client IP: %s",app.configClientIP.c_str());

  // any message to be send straigth after connexion was established would be put here.
  // in our case we don't send the full config, as this one will be send by a post query to be able
  // to simulate the demo

  String fullConfig = app.parseJsonInput("{\"command\":\"retrieve\",\"param\":\"fullConfig\"}"); 
  ws.send(WebSocketDataType::TEXT, fullConfig.c_str(), fullConfig.length());

}

//////////////////////////////////////////////////////////////
////                DEFAULT STRIPS CONSTRUCTOR         ///////
//////////////////////////////////////////////////////////////
Strip* textStripConstructorCallback(){
  DEBUG_PRINT("\n\ttextStripConstructorCallback()"/*,values.c_str()*/);
  return new TextStrip(stripTextSkel,&gui, true);
}

#endif