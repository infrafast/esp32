#ifndef APPManager_h
#define APPManager_h

#include <Preferences.h>
#include "nvs_flash.h" 
#include <LinkedList.h>
#include <ArduinoJson.h>
#include <Preferences.h>

#include <aWOT.h>       // awOT lasselukkari/aWOT@^3.5.0 wifi+eth server
                         // apply patch https://github.com/arduino-libraries/Ethernet/pull/107/files
#include <MenuSystem.h>           // https://github.com/jonblack/arduino-menusystem                         _FADERSPEED
#include <LittleFS.h>
#include <WebSocketServer.hpp>
using namespace net;
using WiFiWebSocketServer = WebSocketServer<WiFiServer, WiFiClient, 1>;
using EthernetWebSocketServer = WebSocketServer<EthernetServer, EthernetClient, 1>;
void socketConnectionCallback(IWebSocket &ws);

///////////////////// WIDGET LOCATION & SIZE ////////////////////////
#define OVERLAY_ICON_SIZE TFT_WIDTH/20

///////////////////// SYSTEM PARAMETERS ////////////////////////
#define S_PUSHDELAY         "pushDelay"
#define S_DCLICREACTIVITY   "dClicReactivity"
#define S_FADERSPEED        "faderSpeed"
#define S_AP_NAME           "apName"
#define S_LANG              "lang"
#define S_CONFIG_FILE       "profile"
#define S_SSID              "ssid"
#define S_LAST_USED_SSID    "lastSSID"

///////////////////// CONFIG PARAMETERS ////////////////////////

#define C_CURRENTLAYOUT     "currentLayout"
#define C_POSSIBLELAYOUT    "possibleLayout"
#define C_ACTIVEMODULE      "active"
#define C_MODULES           "modules"
  #define C_STRIPS          "strips"
    #define C_PROPERTIES    "properties"
    #define C_ID            "id"
    #define C_INDEX         "index"
#define C_ICON              "icon"
void webAppCallbackWrapper(Request &req, Response &res);  // function wrapper

///////////////////// SCREEN APPLICATION MANAGEMENT ////////////////////////

//main screen (id)
enum{
  SCREEN_STARTUP,
  SCREEN_CONNECTION_WIZARD,
  SCREEN_MENU,
  SCREEN_MODULE_SWITCH,
  SCREEN_PROMPT,
  SCREEN_UTILS,
  SCREEN_BYE,
  SCREEN_MODULE,
  SCREEN_MAX
};

//sub screen (state) 
enum{
  STATE_PROMPT_SEQUENCE_X,
  STATE_PROMPT_SEQUENCE_Y,
  STATE_PROMPT_SEQUENCE_Z,
  STATE_CONNECTION_WIZARD_STEP1,
  STATE_CONNECTION_WIZARD_STEP2,
  STATE_CONNECTION_WIZARD_STEP3,
  STATE_UTILS_SEARCHING_CONNECTION,
  STATE_UTILS_INFO,
  STATE_UTILS_CONNECTCONFIGMEDIA,
  STATE_UTILS_CONNECTWEBAPP,
  STATE_UTILS_WEBAPPCONNECTED,
  STATE_BYE_BATTERY_AND_SLEEP,
  STATE_BYE_ERROR_AND_SLEEP,
  STATE_BYE_SAY_GOODBYE
};


void startupScreenBuilder(uint8_t id);
void connectionWizardScreenBuilder(uint8_t id);
void menuScreenBuilder(uint8_t id);
void moduleSwitchScreenBuilder(uint8_t id);
void promptScreenBuiler(uint8_t id);
void utilsScreenBuilder(uint8_t id);
void byeScreenBuilder(uint8_t id);
void moduleScreenBuilder(uint8_t id);
void voidOverlay(uint8_t id);

void overLayBuilder(uint8_t id);

screenBuilder screens[SCREEN_MAX]={
  {SCREEN_STARTUP,startupScreenBuilder,overLayBuilder},
  {SCREEN_CONNECTION_WIZARD,connectionWizardScreenBuilder,overLayBuilder},
  {SCREEN_MENU,menuScreenBuilder,overLayBuilder},
  {SCREEN_MODULE_SWITCH,moduleSwitchScreenBuilder,overLayBuilder},
  {SCREEN_PROMPT,promptScreenBuiler,overLayBuilder},
  {SCREEN_UTILS,utilsScreenBuilder,overLayBuilder},  
  {SCREEN_BYE,byeScreenBuilder,voidOverlay},
  {SCREEN_MODULE,moduleScreenBuilder,overLayBuilder},
};

///////////////////// BUTTONS CALLBACKS ////////////////////////
void simpleClicCallBack(uint8_t buttonID, unsigned long time);
void longClicCallBack(uint8_t buttonID, unsigned long time);
void doubleClicCallBack(uint8_t buttonID, unsigned long time);
void releaseHoldCallback(uint8_t buttonID, unsigned long time);
void holdCallback(uint8_t buttonID, unsigned long time);

void menuSwitchCallback(uint8_t buttonID, unsigned long time);


void info_item_selected(MenuComponent* p_menu_component);
void config_menu_item_selected(MenuComponent* p_menu_component);
void back_menu_item_selected(MenuComponent* p_menu_component);
void save_profile_item_selected(MenuComponent* p_menu_component);
void loadLang_item_selected(MenuComponent* p_menu_component);
void switchToModule_item_selected(MenuComponent* p_menu_component);

void menu_selected(MenuComponent* p_menu_component);

void handleConfigConnection();  // 


///////////////////// DATA MANAGEMENT ////////////////////////
class DataSet{
  public:
    #define JSON_ARRAYITEM_STRING_SIZE 90
    String address;
    String object;
    LinkedList<String> values;

    String serialize(){
      DynamicJsonDocument doc(JSON_ARRAYITEM_STRING_SIZE*values.size());
      JsonArray jsonValues = doc.createNestedArray(address);
      for (uint8_t i=0; i< values.size(); i++) jsonValues.add(values.get(i));
      String data;
      serializeJson(doc,data);
      return data;
    }
};

class DataRepository{
  public:
    DataRepository(){}

    DataSet* getDataSet(String address){
      for (uint8_t i=0;i<dataSets.size();i++){
        DataSet* ds = dataSets.get(i);        
        if (address == ds->address){          
          return ds;
        } 
      }
      return nullptr;
    }

    bool addDataSet(DataSet* ds){
      dataSets.add(ds);
      /*String object = ds->object;
      String address = ds->address;      */
      return true;
    }

    void serialize(DynamicJsonDocument* doc){
      JsonArray jsonDataSets = doc->createNestedArray("datasets");
      for (uint8_t i=0;i<dataSets.size();i++){
        DataSet* ds = dataSets.get(i);
        jsonDataSets.add(ds->serialize());
      }
    }



  private:
    LinkedList<DataSet*> dataSets = LinkedList<DataSet*>();
};


class StripSkeleton;
///////////////////// STRIP MANAGEMENT ////////////////////////
#define NUMBER_OF_STRIP_TEMPLATES 3  
#define INPUTSELECT "dropdown"
#define INPUTTEXT   "freetext"
#define COLORSELECT "colorselect"

#define LAYOUT_DETAILS  0b00000001
#define LAYOUT_ICON     0b00000100
#define LAYOUT_QUATUOR  0b00010000

class Strip : public GenericComponent{  
  #define JSON_STRIP_PROPERTY_SIZE 100
  #define JSON_STRIP_TEMPLATE_SIZE 150
  public:
    TFT_eSprite* sprite = nullptr;
    uint8_t index;

    GUIManager* gui;

    Strip(StripSkeleton* s, GUIManager* g, bool debug=false):GenericComponent(debug){
      skeleton = s;
      gui = g;
      value = (valueMax-valueMin)/2;
      //id = skeleton->stripID;
    }    

    void deserialize(String values){
      DEBUG_PRINT("\t deserialize stRip(%s)",values.c_str());
      uint8_t n = getNumberOfProperties();
      DEBUG_PRINT("\t getNumberOfProperties():%i",n);      
      DynamicJsonDocument jsonStrip(JSON_STRIP_PROPERTY_SIZE*n);          
      DeserializationError error = deserializeJson(jsonStrip, values);
      if (error){
        DEBUG_PRINT("\nStrip <%s> deserialization error:%s",id.c_str(),error.f_str());
      }else{      
        id = jsonStrip[C_ID].as<String>();
        DEBUG_PRINT("\t<%s> properties:",id.c_str());
        // set index; 
        index = jsonStrip[C_INDEX].as<int>();
        DEBUG_PRINT("\tindex=%i",index);
        properties = jsonStrip[C_PROPERTIES];
        for (uint8_t i = 0; i< properties.size(); i++){
          deserializeProperty(properties[i].as<String>());
        }

        // each derived strip then deserialiuze its own other values
        
      }
    };

    String serialize(){
      //DEBUG_PRINT("\nserialize %s=>",id.c_str());
      DynamicJsonDocument doc(JSON_STRIP_PROPERTY_SIZE*1);   
      doc[C_ID] = id;
      doc[C_INDEX] = index;
      properties = doc.createNestedArray(C_PROPERTIES);                 
      serializeProperties();
      String data;
      serializeJson(doc, data);
      //DEBUG_PRINT("%s",data.c_str());
      return data;
    }

    virtual void wipeWidgets(){
      //DEBUG_PRINT("\nwipe %s, number of widgets:%i",id.c_str(),widgetHandles.size());
      int16_t xMin=TFT_WIDTH, xMax=0, yMin=TFT_HEIGHT, yMax=0;

      while (widgetHandles.size()>0){          
          
          Widget* widget = widgetHandles.shift();
          
          if (widget->getX()<xMin) xMin = widget->getX();
          if (widget->getX()+widget->width > xMax) xMax = widget->getX()+widget->width;
          if (widget->getY()<yMin) yMin = widget->getY();
          if (widget->getY()+widget->height > yMax) yMax = widget->getY()+widget->height;      

          //DEBUG_PRINT("\tcls %s  (%i,%i,h:%i,w:%i)  minMax=>(%i,%i,w:%i,h:%i)",widget->id.c_str(),widget->getX(),widget->getY(),widget->width,widget->height,xMin,xMax-xMin,yMin,yMax-yMin);

          GUI::tft->fillRect(xMin,yMin,xMax-xMin,yMax-yMin,GUI::defaultBcolor);

          //DEBUG_PRINT("\nremove gui->remove(%s) before:%i",widget->id.c_str(),gui->screenGUIs.size());
          gui->remove(widget);          
          delete(widget);       
          //DEBUG_PRINT("\tafter:%i",gui->screenGUIs.size());        

      }
    }

    virtual bool progressiveDelay(unsigned long time){
      uint16_t TIME_MAX_PROGRESSIVITY = 3000;
      if (valueMax-valueMin<=20) TIME_MAX_PROGRESSIVITY = 5000;
      else if (valueMax-valueMin>500) TIME_MAX_PROGRESSIVITY = 1000;

      //we start counting the time between two calls when we have called the first time, means during debounce duration
      if (time<DEBOUCE_TIME){
        lastCall = 0;      
        // first call we start timer

      }
      if (time>=TIME_MAX_PROGRESSIVITY) time = TIME_MAX_PROGRESSIVITY;

      unsigned long waitBetween2update = (TIME_MAX_PROGRESSIVITY-time)/5;
      unsigned long delaySoFar = millis() - lastCall;

      DEBUG_PRINT("\nprogressiveDelay(%d) - %u/%u -",time, delaySoFar, waitBetween2update);          

      if (delaySoFar < waitBetween2update) return false;  
      lastCall = millis();
 
      return true;    
    }

    virtual bool increaseCallBack(unsigned long time) = 0;
    virtual bool decreaseCallback(unsigned long time) = 0;
    virtual float getIncrement(unsigned long time)=0;
    virtual uint8_t getNumberOfProperties()=0;
    virtual bool actionCallback()=0;
    virtual void serializeProperties()=0;
    virtual void deserializeProperty(String s)=0;    
    virtual void buildWidgets(uint8_t layout)=0;
    

    JsonArray properties;
    StripSkeleton* skeleton;
    LinkedList<Widget*> widgetHandles = LinkedList<Widget*>();
    float value = 0.0, valueMin = 0, valueMax = 1;
    unsigned long lastCall;    
};

typedef Strip* (*StripBuilderCallback)(/*String values*/);

#define MAXNUMBER_OF_SKELETON 20

class StripSkeleton{
  #define STRIP_DEFAULT_GROUP "utils"
  #define MAXNUMBER_OF_SKELPROPERTY 10
  #define STRIP_SKELETON_PROPERTIES "properties"

  #define JSON_SKELETON_SIZE 30*MAXNUMBER_OF_SKELPROPERTY
  public:
    String stripID;
    String icon;
    String group;
    StripBuilderCallback constructor;
    //JsonObject variable;
    LinkedList<String> dataSetAddresses = LinkedList<String>();
    static DataRepository* dataRepo;

    uint8_t numberOfProperties = 0;  

    StripSkeleton(String id, String g, StripBuilderCallback b, String i="A"){
      stripID = id;
      group = g;
      icon = i;
      constructor = b;
    }

    String getValue(String address, uint8_t index){
      DataSet* ds = dataRepo->getDataSet(address);
      if (ds != nullptr) return ds->values.get(index);
      else return "null";
    }

    bool registerDataSetAddress(String address){
      //Serial.printf("\nadding %s to StripSkeleton %s",label.c_str(),stripID.c_str());
      dataSetAddresses.add(address); 
      numberOfProperties++;
      if (numberOfProperties>MAXNUMBER_OF_SKELPROPERTY) return false;  
      return true;
    }

    String serialize(){
      DynamicJsonDocument jsonDocStripSkeleton = DynamicJsonDocument(JSON_SKELETON_SIZE);
      JsonArray properties;
      jsonDocStripSkeleton[stripID] = group;
      jsonDocStripSkeleton[C_ICON] = icon;
      properties = jsonDocStripSkeleton.createNestedArray(STRIP_SKELETON_PROPERTIES);      
      for (uint8_t i = 0; i < numberOfProperties; i++){
        DataSet* ds = dataRepo->getDataSet(dataSetAddresses.get(i));
        if (ds != nullptr){
          JsonObject kv = properties.createNestedObject();
          kv[ds->address] = ds->object;
        }         
      }
      String data;
      serializeJson(jsonDocStripSkeleton, data);
      return data;
    }

};

// default skeleton
StripSkeleton* stripTextSkel;
Strip* textStripConstructorCallback();

class TextStrip : public Strip{
  
  #define STRIP_TEXT "text"
  //#define STRIP_TEXT_PROPERTY_VALUE "value"
  
  public:  
        
    TextStrip(StripSkeleton* s,GUIManager* g,bool debug=false):Strip(s,g,debug){
    }

    ~TextStrip(){
    }

    virtual bool actionCallback(){return true;}

    virtual void buildWidgets(uint8_t layout){
      switch(layout){
        case LAYOUT_QUATUOR:
        break;
        case LAYOUT_ICON:
        break;
        case LAYOUT_DETAILS: 
        default:
          if (debug) DEBUG_PRINT("\n%s:buildWidgets Label(%s)",id.c_str(),value.c_str());
          Label* label = new Label(&value, Align::Center,&x,&y,50,&GUI::defaultFcolor,&GUI::defaultBcolor,false);
          widgetHandles.add(label);          
          gui->add(label);
        break;
      }
    }

    virtual void deserializeProperty(String property)  {      
      value = property;
      if (debug){DEBUG_PRINT("\tvalue=%s",value.c_str());}
    }

    void serializeProperties(){
      properties.add(value);    
    }

    virtual bool refresh(bool force=false){
      // refresh widget and strip data value;
      return false;
    };

    virtual uint8_t getNumberOfProperties(){
      return skeleton->numberOfProperties;      
    }

    virtual bool increaseCallBack(unsigned long time){return true;}
    virtual bool decreaseCallback(unsigned long time){return true;}
    virtual float getIncrement(unsigned long time){return 0.0;}

    private:
      String value="";
      int16_t x=GUI::width()/2, y=GUI::height()/2;       
};

class ColorSelectStrip : public Strip{

  public: 
    ColorSelectStrip(StripSkeleton* s,GUIManager* g, bool debug=false):Strip(s,g,debug){
    }

    void serializeProperties(){
      char* buf = (char*)malloc(String(colorPropertyAddress).length()*sizeof(char*));
      sprintf(buf,colorPropertyAddress.c_str(),colorID);
      properties.add(String(buf));
      delete buf;
    }

    void deserializeProperty(String property){
      if (sscanf(property.c_str(), colorPropertyAddress.c_str(), &colorID)){
        DEBUG_PRINT("\t%s=%i",colorPropertyAddress.c_str(), colorID);      
      }
    }  

    virtual uint8_t getNumberOfProperties(){
      return skeleton->numberOfProperties;      
    }

    virtual bool refresh(bool force=false){
      /*ds = skeleton->getDataSet(ADDRESS_COLORID);
      if (ds != nullptr) colorNames = ds->sValues->get(colorID);*/
      frontColor = colorMap[colorID].fColor;
      backColor = colorMap[colorID].bColor;
      return refreshed; 
    }

    virtual float getIncrement(unsigned long time){
      float increment;
      //value = roundHalf(value);
      if (time<2000){
        increment = 0.1;
      }else{
        float diff = valueMax - value;
        float percentageToTarget = map(diff,0,valueMax-valueMin,100,1)/2000.0;  // 3000 seems to be a good compromise between delay and precision, 2000 react quicker but skip some decimal
        increment = diff*percentageToTarget;          
        DEBUG_PRINT("\t => diff: %.3f, percentageToTarget: %.3f",diff, percentageToTarget);        
      }
      DEBUG_PRINT("\t value: %.3f, increment: %.4f, ",value,increment);
      return increment;
    }    

    virtual bool increaseCallBack(unsigned long time){            
      if (!Strip::progressiveDelay(time)) return true;
      value += getIncrement(time);

      if (value > valueMax) value = valueMax;
      //value = truncateToOneDecimal(value);
      
      DEBUG_PRINT("new value: %.2f",value);

      return true;      
    }

    virtual bool decreaseCallback(unsigned long time){
      if (!Strip::progressiveDelay(time)) return true;      
      value -= getIncrement(time);
      

      if (value < valueMin) value = valueMin;

      //value = truncateToOneDecimal(value);

      DEBUG_PRINT("new value: %.2f",value);

      return true;      
    }



  protected:
    uint8_t colorID=0; 
    String colorPropertyAddress;
    uint16_t frontColor, backColor;    
};



class TwoSelectStrip : public ColorSelectStrip{

  public: 
    TwoSelectStrip(StripSkeleton* s,GUIManager* g,String *select2String, bool debug=false):ColorSelectStrip(s,g,debug){
      select2Content = select2String;
    }

    void serializeProperties(){
      ColorSelectStrip::serializeProperties();

      char* buf = (char*)malloc(select2PropertyAddress.length()*sizeof(char*));
      sprintf(buf,select2PropertyAddress.c_str(),select2ID);
      properties.add(String(buf));
      delete buf;

    }

    void deserializeProperty(String property){
      ColorSelectStrip::deserializeProperty(property);
      if (sscanf(property.c_str(), select2PropertyAddress.c_str(), &select2ID)){
        DEBUG_PRINT("\t%s=%i",select2PropertyAddress.c_str(), select2ID);      
      }    
    }  

    virtual uint8_t getNumberOfProperties(){
      return skeleton->numberOfProperties;      
    }
 
  protected:
    uint8_t select2ID=0; 
    String *select2Content;
    String select2PropertyAddress;
};


class ThreeSelectStrip: public TwoSelectStrip{
  public:
    ThreeSelectStrip(StripSkeleton* s,GUIManager* g, String *select2String, String *select3String, bool debug=false):TwoSelectStrip(s,g,select2String,debug){
      select3Content = select3String;
    }
  
    void serializeProperties(){
      TwoSelectStrip::serializeProperties();

      char* buf = (char*)malloc(select3PropertyAddress.length()*sizeof(char*));
      sprintf(buf,select3PropertyAddress.c_str(),select3ID);
      properties.add(String(buf));
      delete buf;

    }

    void deserializeProperty(String property){
      TwoSelectStrip::deserializeProperty(property);
      if (sscanf(property.c_str(), select3PropertyAddress.c_str(), &select3ID)){
        DEBUG_PRINT("\t%s=%i",select3PropertyAddress.c_str(), select3ID);      
      }  

    }  

    virtual uint8_t getNumberOfProperties(){
      return skeleton->numberOfProperties;      
    }

  protected:
    uint8_t select3ID=0; 
    String *select3Content;
    String select3PropertyAddress;

};



class StripFactory{
  public:
    LinkedList <StripSkeleton*> stripSkeletonRepo = LinkedList<StripSkeleton*>();
    //std::vector<StripSkeleton*> stripSkeletonRepo;
    //StaticJsonDocument<10000> stripsDefinitions;

    bool add(StripSkeleton* ss){
      if (stripSkeletonRepo.size()>=MAXNUMBER_OF_SKELETON) return false;
      stripSkeletonRepo.add(ss);
      return true;
    }

    Strip* build(String stripID/*, String values*/){
      DEBUG_PRINT("\nbuild(%s)",stripID.c_str()/*,values.c_str()*/);
      Strip* strip = nullptr;
      StripSkeleton* skel = getStripSkeleton(stripID);
      if (skel != nullptr) strip = skel->constructor(/*values*/);
      return strip;
    }

    String getDefinition(String stripID){
      String stringDef = "{\"null\":0}";
      StripSkeleton* skel = getStripSkeleton(stripID);
      if(skel != nullptr) stringDef = skel->serialize();
      return stringDef;
    }

    void serialize(DynamicJsonDocument* doc){
      uint8_t n = stripSkeletonRepo.size();
      JsonArray jsonSkeletons = doc->createNestedArray("skeletons");
      for (uint8_t i=0;i<n;i++){
        StripSkeleton* skeleton = stripSkeletonRepo.get(i);
        String stripName = skeleton->stripID;
        jsonSkeletons.add(skeleton->serialize());
      }
    }

  private:
    StripSkeleton* getStripSkeleton(String stripID){
      //DEBUG_PRINT("\ngetStripSkeleton(%s)",stripID.c_str());
      for (uint8_t i=0;i<stripSkeletonRepo.size();i++){
        StripSkeleton* s = stripSkeletonRepo.get(i);        
        //DEBUG_PRINT("==%s?",s->stripID.c_str());
        if (stripID == s->stripID){
          //DEBUG_PRINT(": MATCH!");
          return s;
        } 
      }
      return nullptr;
    }
};

///////////////////// MODULES MANAGEMENT ////////////////////////

class Module{  
  #define MOD_MAXWINDOW 3
  #define STRIP_PER_WINDOW 4
  #define MODULE_MAX_STRIPS MOD_MAXWINDOW*STRIP_PER_WINDOW
  #define JSON_MODULE_SIZE JSON_STRIP_TEMPLATE_SIZE*MODULE_MAX_STRIPS

  public:
    uint8_t window = 0;
    uint8_t selector = 0;
    uint8_t stripIndex = 0;
    //uint8_t maxWindow = 0;

    String name;
    String icon;
    Strip* strips[MODULE_MAX_STRIPS] ={nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr} ;

    uint8_t possibleLayout;
    uint8_t currentLayout;
    bool active;

    Module(String n, String value, StripFactory* sf){      
      name = n;
      stripFactory = sf;
      deserialize(value);
      init();
    }

    void init(){
      //set stripIndex to the first busy strip
      for (stripIndex=0; stripIndex<MODULE_MAX_STRIPS; stripIndex++){
        if (strips[stripIndex] != nullptr ) break;
      }
      DEBUG_PRINT("\n%s stripIndex:%i",name.c_str(),stripIndex);
      selector = stripIndex % STRIP_PER_WINDOW;
    }

    uint8_t getMaxWindow(){
      //determine how many strips are in use ... means if there are free strip,in between (value nullptr) we skip but as soon as we found one not 0 we set it to the current index
      uint8_t numberOfBusyStrip = 0;
      //DEBUG_PRINT("\n%s numberOfBusySlot=",name.c_str());
      for (uint8_t i = 0; i < MODULE_MAX_STRIPS; i++) {
        if (strips[i] != nullptr) {
          numberOfBusyStrip = i;
          //DEBUG_PRINT(" %i",numberOfBusyStrip);
        }
      }
      uint8_t newMaxWindow = numberOfBusyStrip / STRIP_PER_WINDOW + 1;
      return newMaxWindow;
    }

    void deserialize(String value){
      DynamicJsonDocument doc(JSON_MODULE_SIZE);
      DeserializationError error = deserializeJson(doc, value);
      if (error){
        DEBUG_PRINT("\nModule <%s> deserialization error:%s",name.c_str(), error.f_str());
      }      
      DEBUG_PRINT("\n\nmodule <%s>:<%s>",name.c_str(),value.c_str());

      //we receive an array with only one element which is the module content,
      //hence we treat it as such
      JsonArray jsonMod = doc.as<JsonArray>();
      JsonObject mod = jsonMod[0];

      possibleLayout = mod[C_POSSIBLELAYOUT];
      currentLayout = mod[C_CURRENTLAYOUT];
      active = mod[C_ACTIVEMODULE];
      icon = mod[C_ICON].as<String>();
      
      DEBUG_PRINT(" :possible layout:%i, currentLayout:%i, active:%i",possibleLayout,currentLayout, active);
      JsonArray stripArray = mod[C_STRIPS];
      for (int i=0; i<stripArray.size() && i<MODULE_MAX_STRIPS; i++){        
        JsonObject jsonStrip = stripArray[i];
        String jsonStripString = stripArray[i].as<String>();
        String stripID = jsonStrip[C_ID];
        uint8_t index = jsonStrip[C_INDEX];
        if (index<MODULE_MAX_STRIPS){
          Strip* strip = stripFactory->build(stripID);  // build the strip by passing values to deserialize
          if (strip != nullptr){            
            strip->deserialize(jsonStripString);
            strips[index] = strip;
          }
        }
      }
    }

    String serialize(){
      DynamicJsonDocument doc(JSON_STRIP_TEMPLATE_SIZE*MODULE_MAX_STRIPS);   
      //DEBUG_PRINT("\nserialize %s=>",name.c_str());

      doc[C_POSSIBLELAYOUT] = possibleLayout;
      doc[C_CURRENTLAYOUT] = currentLayout;
      doc[C_ACTIVEMODULE] = active;
      doc[C_ICON] = icon;

      JsonArray jsonStrips = doc.createNestedArray(C_STRIPS);            
      for (uint8_t i = 0; i<MODULE_MAX_STRIPS; i++){
        if (strips[i] != nullptr){
          jsonStrips.add(strips[i]->serialize());
        }
      }
      String data;
      serializeJson(doc, data);
      removeJsonQuote(&data);
      //DEBUG_PRINT("\t<%s>",data.c_str());
      return data;
    }

  private:
    StripFactory* stripFactory;

};

class ModuleRenderer: public Widget{
  //#define MODULE_NAME_SIZE TFT_WIDTH/15
  public:
    Strip* selectedStrip = nullptr;
    Strip* previousStrip = nullptr;    

    ModuleRenderer(Module* mod, LinkedList<Widget*>* w, bool debug):Widget(&xPos, &yPos, &fC, &bC, debug){      
      module = mod;
      widgetList = w;
      oldIndex = module->stripIndex - 1; //this is to force first refresh
      width = TFT_WIDTH/2; height = OVERLAY_ICON_SIZE;
    }

    virtual bool refresh(bool force=false){
      Widget::refresh(force);

      String navigator="";

      if (module->stripIndex != oldIndex){
        selectedStrip = module->strips[module->stripIndex];
        if (previousStrip == nullptr) previousStrip = selectedStrip;

        //if (debug) DEBUG_PRINT("\n\t module <%s> changed index: <%i> => new stripIndex:<%i=>%s>",id.c_str(),module->stripIndex, selectedStrip->index,selectedStrip->id.c_str());        
        refreshed = true;
        oldIndex = module->stripIndex;
        // we update the new strip by removing the current one and adding the new one
        //module->strips[module->stripIndex]->refresh(force);       

        //refresh the navigator bar
        for (uint8_t i = 0; i<MODULE_MAX_STRIPS; i++){
          if (module->strips[i] !=nullptr){
            if (i == module->stripIndex) navigator += "+";
            else navigator += "-";
          }
        }
        navigator += " "; // separator
      }

      if (id != module->name){
        refreshed = true;
        id = module->name;
      } 

      if (refreshed){
        // strip navigator
        Icon* icons = new Icon(&navigator,Align::Center,&GUI::zero,&GUI::zero,OVERLAY_ICON_SIZE,&GUI::gold,&bC,debug);
        icons->refresh(true);
        width = icons->width;        

        //module name
        Label* label = new Label(&module->name,Align::Center,&GUI::zero,&GUI::zero,OVERLAY_ICON_SIZE*2,&fC,&bC,debug);
        label->refresh(true);

        width += label->width;
        height = max(label->height,icons->height);
        
        createSprite();  

        icons->sprite->pushToSprite(sprite,0,0);
        delete icons;
        label->sprite->pushToSprite(sprite,icons->width,-OVERLAY_ICON_SIZE/3);    
        delete label;           

      }

      return refreshed;
    }
    
    virtual void setText(const String* text){

    }  

    virtual int16_t getX(){
      return xPos-(width/2);
    }

  protected:
    Module* module;
    LinkedList<Widget*>* widgetList;
    uint8_t oldIndex;    

    int16_t xPos = TFT_WIDTH/2, yPos = TFT_HEIGHT-OVERLAY_ICON_SIZE;
    uint16_t fC = GUI::defaultFcolor, bC = GUI::defaultBcolor;

};

class SingleLayoutModule: public ModuleRenderer{
  public:
    
    SingleLayoutModule(Module* mod,LinkedList<Widget*>* w, bool debug=false) : ModuleRenderer(mod,w, debug){
      id="SingleLayoutModule";
    }

    virtual bool refresh(bool force=false){
      ModuleRenderer::refresh(force);     
      // check if we changed the strip
      if (refreshed){
        if (previousStrip != nullptr) previousStrip->wipeWidgets();
        selectedStrip->buildWidgets(LAYOUT_DETAILS);
        previousStrip = selectedStrip;
      }
      selectedStrip->refresh();
      return refreshed;
    }

    ~SingleLayoutModule(){
      selectedStrip->wipeWidgets();
    }

  private:
    
};

///////////////////// JSON AND SERIALIZATION  ////////////////////////

class JsonListFile : public JsonList{
  public:
      String filename;

      JsonListFile():JsonList(){};

      bool load(String f,String defaultValues=""){
        DEBUG_PRINT("\nload(%s,<%s>) ",f.c_str(),defaultValues.c_str());
        // We first clean up existing values
        /*while (keyValues.size()>0){
          //DEBUG_PRINT("\nremaining to unstack: %i",gui->screenGUIs.size());
          KeyValue* kv = keyValues.shift();
          //DEBUG_PRINT("\nobject: %s ",widget->id.c_str());
          delete(kv);
        }*/
        bool success = false;

        deserialize(defaultValues);

        filename = f;
        // we try to allocate maximum memory and keep 20K free for security
        DynamicJsonDocument doc(getMaxAlloc());

        if (!LittleFS.exists(filename)){
          DEBUG_PRINT("\nfile: %s invalid, skipping by using default parameters",filename.c_str());          
        }else{
          File file = LittleFS.open(filename);
          DeserializationError error = deserializeJson(doc, file);      
          if (!error){
            jsonToKeyValues(&doc);
            success = true;
          }else{
            DEBUG_PRINT("\nJson error %s:%s",error.c_str(),filename.c_str());
          }
          doc.shrinkToFit();   
          //DEBUG_PRINT("\nloaded %s", filename.c_str());     
        }
        return success;      
      }

      bool save(String f=""){
        bool success = true;
        if (f !="") filename = f;
        String s;
        serialize(&s);

        File file = LittleFS.open(filename, FILE_WRITE);
        if(!file){
            DEBUG_PRINT("\nfailed to open %s for writing",filename.c_str());
            success = false;
        }
        if(!file.print(s)){
            DEBUG_PRINT("\n %s write fail",filename.c_str());
            success = false;
        }else{
          DEBUG_PRINT("\n saved: %s",s.c_str());
        }
        file.close();  
        return success;
      }
};

class Config : public JsonListFile{
  public:
    Config():JsonListFile(){}  

    const int getInt(String name) {
      return getString(name)->toInt();
    };
    const float getFloat(String name) {
      return getString(name)->toFloat();
    };
    const boolean getBool(String name) {
      return (*getString(name) != "0");
    };

};

class I18n : public JsonListFile{
  public:
    I18n():JsonListFile(){}

    virtual const String* getString(const String name, const String defaultValue="") {
      int8_t index;
      index = getIndex(String(name));
      if (index < 0) {
        //DEBUG_PRINT("\ntoken: %s do not exist, creating it.",name.c_str());
        addValue(name,name);  // if it doesnt exist we create it in the list
        return getString(name);
      } else {
        
        KeyValue* kv = keyValues.get(index);  
        //DEBUG_PRINT("\ntoken: %s = %s",name.c_str(),kv->value.c_str());      
        return &kv->value;
      }
    };
};

///////////////////// MAIN APPLICATION CLASS ////////////////////////

enum{
  MENU_ICON_MIDDLE,
  MENU_LABEL_TITLE,
  CONFIG_TEXTAREA_MESSAGE,
  MODULE_SINGLEWIDGET,
  CONFIG_CONNECTWEBAPP,
  NUMBER_OF_WIDGETS
};

// persistants keyValues ID
#define PERSISTANT_SCREEN_ID "screenID"
#define PERSISTANT_SCREEN_STATE "stateModule"

class ApplicationManager : public GenericComponent,MenuComponentRenderer{
  public:    
    ///////////////////// STRIPS & MODULES CONTAINERS AND DEFINITION ////////////////////////
    LinkedList<Module*> modules = LinkedList<Module*>(); 
    StripFactory stripFactory;
    DataRepository dataRepository;
    
    #define ADDRESS_SIMPLETEXT "simpleText"
    DataSet simpleText={.address = ADDRESS_SIMPLETEXT,.object=INPUTTEXT,.values = LinkedList<String>()};
    
    ///////////////////// OVERLAY ICONS ////////////////////////
    String networkIcon, apIcon;
    uint16_t networkIconColor = TFT_RED, apIconColor = TFT_RED, batIconColor = TFT_GREEN, utils1Icon1Color = GUI::menuActiveIconColor;   
    #define BAT_MAX_ICON 4
    String batteries[BAT_MAX_ICON]={"6","7","8","9"};
    String batIcon = batteries[BAT_MAX_ICON-1];
    String forbidIcon = "m";

    AlteredColor networkIconGlowingRedColor = AlteredColor{.baseColor = GUI::red, .value =  &GUI::unUsedColor};
    AlteredColor apIconGlowingRedColor = AlteredColor{.baseColor = GUI::red, .value =  &GUI::unUsedColor};
    AlteredColor configIconGlowingRedColor = AlteredColor{.baseColor = GUI::red, .value =  &GUI::unUsedColor};

    
    int16_t overlayIconY = TFT_HEIGHT-OVERLAY_ICON_SIZE, apIconPosX = TFT_WIDTH-OVERLAY_ICON_SIZE*2;
    int16_t batIconPosX = TFT_WIDTH-OVERLAY_ICON_SIZE;

    ///////////////////// WIDGETS & ATTRIBUTES ////////////////////////
    #define WIDGET_SMALL_WIDTH TFT_WIDTH/8-5
    #define WIDGET_BIG_WIDTH TFT_WIDTH/5

    int16_t belowTop = 10, midScreenHoriz = TFT_WIDTH/2, rightScreen = TFT_WIDTH, midScreenVertical = TFT_HEIGHT/2, bigWidgetMidY = midScreenVertical-WIDGET_BIG_WIDTH/2;

    AlteredColor glowingGoldColor = AlteredColor{.baseColor = GUI::gold, .value = &GUI::gold};

    uint16_t rainbowC;
    AlteredColor rainbowColor = AlteredColor{.baseColor = TFT_WHITE, .value = &rainbowC};
    Widget* widgets[NUMBER_OF_WIDGETS]; 

    #define TFT_QUARTER TFT_WIDTH/4
    int16_t quarter1xPos = TFT_QUARTER-TFT_QUARTER/2;
    int16_t quarter2xPos = TFT_QUARTER*2-TFT_QUARTER/2;
    int16_t quarter3xPos = TFT_QUARTER*3-TFT_QUARTER/2;
    int16_t quarter4xPos = TFT_QUARTER*4-TFT_QUARTER/2;

    #define TFT_THIRD TFT_WIDTH/3
    int16_t third3xPos = TFT_THIRD*2+TFT_QUARTER/2;

    String utils1Icon1,utils1Icon2;

    ///////////////////// MENU SYSTEM ATTRIBUTES AND MESSAGE ////////////////////////
    #define MENU_ICON_SIZE TFT_WIDTH/3
    #define MENU_TITLE_SIZE MENU_ICON_SIZE/2
    #define CONFIG_TEXTAREA_MESSAGE_SIZE MENU_TITLE_SIZE/1.8

    MenuSystem ms = MenuSystem(*this);
    MenuSystem* moduleMenu = nullptr;

    Menu* langMenu = nullptr;
    Menu* confMenu = nullptr;  
    String topLabelItem=" ", vBatLabel; //menuTitle
    String menuItemIcon[3]={String(""),String(""),String("")}; // left, mid, right
    String bottomLabelTitle=" ";

    uint16_t menuActiveIconColor;

    int16_t menuIconYpos = TFT_HEIGHT/2-MENU_ICON_SIZE/2.2, leftMenuIconXpos = midScreenHoriz-MENU_ICON_SIZE*1.4,rightMenuIconXpos = midScreenHoriz+MENU_ICON_SIZE*1.4;
    int16_t menuTitleY = TFT_HEIGHT-MENU_TITLE_SIZE, belowMenuIcon = menuIconYpos+MENU_ICON_SIZE;

    String iconDot[4]={"QP","RP","PQ","PR"};
    String webAppLoadPending[2];
    const String iconCycle[2]={ICON_ROLLING1,ICON_ROLLING2};
    const String iconLink[2]={ICON_LINK," "};
    /*const String* iconPointers1[4] = {iconSet1, iconSet1 + 1, iconSet1 + 2, iconSet1 + 3};
    const String** pendingIndicatorsAnimatedIconString = iconPointers1;*/


    const char* quitMenuString ={"o:QUIT"};
    const char* infoMenuString ={"l:INFO"};
    const char* configMenuString ={"y:CONFIGURATION"};
    const char* profileMenuString ={"c:PROFILE"};
    const char* saveMenuString ={"j:SAVE"};
    const char* langMenuString ={"k:LANGUAGE"};
    

    ///////////////////// UTILITIES ATTRIBUTES ////////////////////////
    I18n lang = I18n();
    Config config = Config();
    Config system = Config();
    Preferences persistants;

    bool webAppConnected;

    String configClientIP; // ip of the client connect to the AP during configuration    

    ApplicationManager(HardwareManager* h, GUIManager* g, bool debug=true):GenericComponent(debug){
      hwm = h;
      gui = g;
      id = "ApplicationManager";

      stripTextSkel = new StripSkeleton(STRIP_TEXT,STRIP_DEFAULT_GROUP,textStripConstructorCallback);
      dataRepository.addDataSet(&simpleText);
      stripTextSkel->registerDataSetAddress(ADDRESS_SIMPLETEXT);
    }

    void setBatIcon(){
      uint8_t vBatIconIndex = map(hwm->battery.vBat,BAT_MIN,BAT_MAX,0,BAT_MAX_ICON-1);
      batIcon = batteries[vBatIconIndex];
      //if (debug) DEBUG_PRINT("\nIcon index: %i icon:%s",vBatIconIndex,batIcon.c_str());
      if (vBatIconIndex == 0) batIconColor = TFT_RED; 
      else batIconColor = TFT_GREEN;
      vBatLabel = *lang.getString("Battery: ")+String(hwm->battery.vBat)+"v";
    }

    void setAPandNetIcons(){
      setAPIcon();
      setNetworkIcon();
    }

    void setAPIcon(){
      if (hwm->ap == nullptr){
        apIcon = emptyString;
      }else{
        apIcon = ICON_AP;
        if (hwm->ap->state == CONNECTED){
          apIconGlowingRedColor.value = &GUI::unUsedColor;
          apIconColor = GUI::green;
        }else{
          apIconGlowingRedColor.value = &apIconColor;
        }
      }
    }

    void setNetworkIcon(){

      #ifdef USE_NETWORK
              
        if (hwm->network->state == CONNECTED){
          if (hwm->network->media == WIFI) refreshWiFiSignalIcon();
          else networkIcon = ICON_ETH;
          networkIconGlowingRedColor.value = &GUI::unUsedColor;
          networkIconColor = GUI::green;
        }else{
          networkIconGlowingRedColor.value = &networkIconColor;
          //DEBUG_PRINT("\n setNetworkIcon ********************************");
          if (hwm->network->ethEnabled && hwm->network->WiFiEnabled) networkIcon = ICON_MIXETHWIFI;
          else if (hwm->network->ethEnabled && !hwm->network->WiFiEnabled) networkIcon = ICON_ETH; 
          else if (!hwm->network->ethEnabled && hwm->network->WiFiEnabled) networkIcon = ICON_WIFI_STRENGTH_3; 
          else networkIcon = emptyString;  // when it is only wifi and ap is launched.
        }

      #else
        networkIcon = emptyString;
      #endif

    }

    void init(String param="\"void\": 0"){
      GenericComponent::init();

      persistants.begin("interval", false);

      system.load("/settings.sys",defaultSysConf);  

      String profileFile = "/"+*system.getString(S_CONFIG_FILE,"default.conf");
      param="{"+defaultUserConf+","+param+"}";
      config.load(profileFile,param);  

      String langFile = "/"+*system.getString(S_LANG,"ENGLISH")+".lang";
      lang.load(langFile);

      if (debug){
        String s;
        system.serialize(&s);
        //DEBUG_PRINT("\n\n serialization of system:\n%s",s.c_str());
        config.serialize(&s);
        //DEBUG_PRINT("\n\n serialization of config:\n%s",s.c_str());
        lang.serialize(&s);
        //DEBUG_PRINT("\n\n serialization of langfile:\n%s",s.c_str());        
        //DEBUG_PRINT("\nexample of langfile token: Connect:%s",lang.getString("Connect")->c_str());        
      }

      wiFiList.deserialize(*system.getString(S_SSID));

      hwm->init();
      hwm->setWiFi(&wiFiList,*system.getString(S_LAST_USED_SSID));
      hwm->setButtonReactivity(config.getInt(S_PUSHDELAY),config.getInt(S_DCLICREACTIVITY));     

      gui->init();         

      for (uint8_t i=0;i<SCREEN_MAX;i++) screenBuilders.add(&screens[i]);
            
      for (uint8_t i=0;i<MAXB;i++){
        hwm->buttons[i]->setCallBack(SIMPLE_CLIC,simpleClicCallBack);
        hwm->buttons[i]->setCallBack(LONG_CLIC,longClicCallBack);
        hwm->buttons[i]->setCallBack(DOUBLE_CLIC,doubleClicCallBack);
        hwm->buttons[i]->setCallBack(RELEASE_HOLD,releaseHoldCallback);
        hwm->buttons[i]->setCallBack(HOLD,holdCallback);
      }

      hwm->onOff->setCallBack(LONG_CLIC,menuSwitchCallback);

      back_menu_item = new MenuItem(quitMenuString, &back_menu_item_selected);
      info_menu_item = new MenuItem(infoMenuString, &info_item_selected);
      config_menu_item = new MenuItem(configMenuString,&config_menu_item_selected);
      profile_menu_item = new Menu(profileMenuString,&menu_selected);
      save_profile_menu_item = new MenuItem(saveMenuString,&save_profile_item_selected);

      ms.get_root_menu().add_item(back_menu_item);
      ms.get_root_menu().add_item(info_menu_item);
      ms.get_root_menu().add_item(config_menu_item);       
      ms.get_root_menu().add_menu(profile_menu_item);
      profile_menu_item->add_item(back_menu_item);
      profile_menu_item->add_item(save_profile_menu_item);
      
      hookLangToMenu();
      
      //quarter1xPos = 

      // glowing colors declarations
      //gui->glowingColors.add(&glowingGoldColor);
      glowingGoldColor.value = &menuActiveIconColor;
      gui->alphaColors.add(&glowingGoldColor);      
            
      gui->alphaColors.add(&networkIconGlowingRedColor);
      gui->alphaColors.add(&apIconGlowingRedColor);
      gui->alphaColors.add(&configIconGlowingRedColor);

      gui->rainbowColors.add(&rainbowColor);
      gui->alphaColors.add(&rainbowColor);

      minHeapSize = maxHeapSize = ESP.getFreeHeap();

      setAPandNetIcons();
      setBatIcon();
      
      // build the modules      
      // count number of modules by counting the property "strips"
      
      screen.state = STATE_BYE_BATTERY_AND_SLEEP;

      uint8_t numberOfModules = countWord(*config.getString(C_MODULES),C_STRIPS);
      if (numberOfModules>0){
        
        int memAlloc = JSON_MODULE_SIZE * numberOfModules;
        //DEBUG_PRINT("\nCreating modules from: <%s>, [%d] modules, memalloc: %i",config.getString(C_MODULES)->c_str(),numberOfModules,memAlloc);
        DynamicJsonDocument jsonModules(memAlloc);          
        
        DeserializationError error = deserializeJson(jsonModules, *config.getString(C_MODULES));
        if (error){
          DEBUG_PRINT("\nModule deserialization error:%s",error.f_str());
        }              
        JsonObject root = jsonModules.as<JsonObject>();      
        for (JsonPair kv : root) {
          //DEBUG_PRINT("\n%s = %s",kv.key().c_str(),kv.value().as<String>().c_str());          
          modules.add(new Module(kv.key().c_str(),kv.value().as<String>(),&stripFactory));
        }
        hookModuleToMenu();

      }else{
        isSystemON = false;
        topLabelItem = *lang.getString("Fatal error");
        bottomLabelTitle = *lang.getString("0 Module");
        screen.state = STATE_BYE_ERROR_AND_SLEEP;
      }

      if (isSystemON){
        screen.id = persistants.getUChar(PERSISTANT_SCREEN_ID,SCREEN_MODULE); //screen.id = SCREEN_MODULE;        
        screen.state = persistants.putUChar(PERSISTANT_SCREEN_STATE,0);
        //screen state is module ID;
        if (screen.state > modules.size()-1) screen.state = 0; // if we saved a module which is not existing anymore
        oldScreen.value = screen.value - 1;
      }else{
        screen.id = SCREEN_BYE;
        shutDownTimeOut = millis();   
      }      

    }

    void refreshWiFiSignalIcon(){
      int8_t signalStrength = abs(WiFi.RSSI());
      if (signalStrength >=90) networkIcon = ICON_WIFI_STRENGTH_0;
      else if (signalStrength >=75) networkIcon = ICON_WIFI_STRENGTH_1;
      else if (signalStrength >=45) networkIcon = ICON_WIFI_STRENGTH_2;
      else networkIcon = ICON_WIFI_STRENGTH_3;      
      //DEBUG_PRINT("\nrssi: %d",signalStrength);
    }

    void serialize(String* data){

      //modules
      DynamicJsonDocument modDoc(JSON_MODULE_SIZE*modules.size()); 
      for (uint8_t i=0; i<modules.size(); i++){
        DynamicJsonDocument jsonModule(JSON_MODULE_SIZE); 
        Module* mod = modules.get(i);
        String stringModule = mod->serialize();
        DeserializationError error = deserializeJson(jsonModule, stringModule);
        if (error){
          DEBUG_PRINT("\nModule <%s> deserialization error:%s",mod->name.c_str(),error.f_str());
        }else{
          modDoc[mod->name] = jsonModule;
        }       
      }
      config.setValue(C_MODULES,modDoc.as<String>());

      DynamicJsonDocument doc(getMaxAlloc());
      
      system.serialize(data);  
      doc["system"]=*data;
      config.serialize(data);
      doc["config"]=*data;
      doc["source"]="esp";
      
      stripFactory.serialize(&doc);      
      dataRepository.serialize(&doc);      
      
      serializeJson(doc, *data);  
      removeJsonQuote(data);
    }

    void restoreScreen(){
      screen.id = persistants.getUChar(PERSISTANT_SCREEN_ID,SCREEN_MODULE);
      screen.state = persistants.getUChar(PERSISTANT_SCREEN_STATE,0);    
    }

    void restoreMenu(){
      screen.id = SCREEN_MENU;
    }

    String getIconFromString(const char* item){
      return String((char)item[0]);
    }

    String getNameFromString(const char* item){
      return String(item).substring(2);
    }

    void hookLangToMenu(){
      if (langMenu != nullptr) delete langMenu;
       
      populateFileList("lang",&countryList,String(ICON_LANG)+"-",false);     // this populate the list of countries with the icon (prefix = k-) and without extension

      langMenu = new Menu(langMenuString,menu_selected); 
      // populate the menu with all language found
      
      for(int i = 0; i < countryList.size(); i++){
        const char* countryIconAndName = countryList.get(i)->c_str();
        langMenu->add_item(new MenuItem(countryIconAndName, &loadLang_item_selected));                
        if (debug){
          //DEBUG_PRINT("\nadded menu entry: %s",countryList.get(i)->c_str());           
        }
      }

      langMenu->add_item(back_menu_item);
      ms.get_root_menu().add_menu(langMenu);              
      // we go one level up, as we are on top means we open the last item we created = lang menu
      /*ms.prev(true);
      ms.select();
      for (int i = 0; i < langMenu->get_num_components(); ++i) {
        MenuComponent const* cp_m_comp = langMenu->get_menu_component(i);
        String country = String(cp_m_comp->get_name()).substring(2,String(cp_m_comp->get_name()).length());
        DEBUG_PRINT("\n%s <> %s",cp_m_comp->get_name(),system.getString(S_LANG)->c_str());              
        if (strcmp(country.c_str(),system.getString(S_LANG)->c_str()) == 0) break;
        ms.next(true);
      } */ 



      /*ms.reset();             
      // we go one level up, as we are on top means we open the last item we created = lang menu
      ms.prev(true);
      ms.select();
      // now we set the focus on the item that correspond to the langpreviously selected            
      for (int i = 0; i < langMenu->get_num_components(); ++i) {
        MenuComponent const* cp_m_comp = langMenu->get_menu_component(i);
        //DEBUG_PRINT("\n%s <> %s",cp_m_comp->get_name(),conf.getString(MODCONFLANG).c_str());              
        if (strcmp(cp_m_comp->get_name(),conf.getString(MODCONFLANG).c_str()) == 0) break;
        ms.next();
      } */
    }
    

    bool refresh(bool force=false){
      refreshed = force;
      //------------------
      //
      // MANAGE NETWORK
      //
      //------------------     
      hwm->refresh();      

      if (hwm->network->refreshed){ // network changed its status
        
        setNetworkIcon();

        if (hwm->network->state == CONNECTED){         
          // network has refreshed so we shift to appropriate configMedia
          if (hwm->network->media == WIFI){
            //we set last used Wifi SSID (id) and save config, hence keep WIFI credential
            system.setValue(S_LAST_USED_SSID,hwm->network->id);
            system.save(); 
          }
          if (!webAppConnected){
            // there is no connection to any application, therefore, we prefer to use the network as the one to configure the application
            if (debug) DEBUG_PRINT("\n\tsetting the configMedia to WiFiEth");
            hwm->configMedia = hwm->network;    // since the normal network gets reconnected,

          }else{
            // we have a connected application so we keep the confignetwork  as it is
            if (debug) DEBUG_PRINT("\n\tconfignetwork is connected to application so we do nothing");
          }
        }
      }

      if (hwm->ap != nullptr){
        if (hwm->ap->refreshed) setAPandNetIcons();
      }

      // real time signal strength display
      if (hwm->network->state == CONNECTED && hwm->network->media == WIFI) refreshWiFiSignalIcon();

      //------------------
      //
      // MANAGE WEB APPLICATION
      //
      //------------------  

      if (hwm->configMedia->state == CONNECTED){    
        if(webAppOn){          

          if (hwm->configMedia->refreshed) setWSServer();   // the network has refreshed (could be media, IP...) hence we rebuild the WSS
          wss->listen();  //sockets       
          
          if (hwm->configMedia->media == CABLE){
            EthernetClient newEthClient = ((EthernetServer*)hwm->configMedia->server)->available();
            if (newEthClient.connected()) {
              if (debug) DEBUG_PRINT("\nWebapp connected eth");
              webServer->process(&newEthClient);
              newEthClient.stop();
            }
          }else{
            WiFiClient newWiFiClient = ((WiFiServer *)hwm->configMedia->server)->available();
            if (newWiFiClient.connected()) {
              if (debug) DEBUG_PRINT("\nWebapp connected wifi");
              webServer->process(&newWiFiClient);
              newWiFiClient.stop();
            }   
          }
        }
      }else{
        //if (hwm->configMedia->refreshed) 
        webAppConnected = false;
      }
      
      // BATTERY LEVEL CHECK
      if (hwm->battery.refreshed){        
        setBatIcon();
        if (hwm->battery.vBat<BAT_CRIT){
          screen.id = SCREEN_BYE;
          screen.state = STATE_BYE_BATTERY_AND_SLEEP;
          shutDownTimeOut = millis();  //start count down
        }         
      }
   

      //------------------
      //
      // MANAGE GUI OBJECT
      //
      //------------------
      if (screen.value != oldScreen.value){
        refreshed = true;
        // we changed the screen, therefore we rebuild the screen
        // first we acknowledge the update so it is not done te next round
        if (debug) DEBUG_PRINT("\n%s changed from screen.id:%i,screen state:%i to screen.id:%i,screen.state:%i",id.c_str(),oldScreen.id,oldScreen.state,screen.id,screen.state);        
        // first clean up all component of the screen
        //for(int i = 0; i < gui->screenGUIs.size()-1; i++) delete(gui->screenGUIs.shift());
        while (gui->screenGUIs.size()>0){
          //DEBUG_PRINT("\nremaining to unstack: %i",gui->screenGUIs.size());
          Widget* widget = gui->screenGUIs.shift();
          //DEBUG_PRINT("\nobject: %s ",widget->id.c_str());
          delete(widget);
          widget = nullptr;
        }
        //gui->screenGUIs.clear();

        // then retrive the screen builder and its overlay by ID           
        for(int i = 0; i < screenBuilders.size(); i++){
          screenBuilder* builder = screenBuilders.get(i);
          if (builder->id == screen.id){
            builder->screenCallback(screen.state);
            builder->overlayCallback(screen.state);
            break;
          }
        }
        #ifdef DEBUG
          // DEBUG INDICATORS OVERLAY
          gui->add(new Label(&gui->framePerSec,Align::Right, &rightScreen, &GUI::zero,TFT_WIDTH/16,&GUI::defaultFcolor,&GUI::defaultBcolor,false));    
          gui->add(new Label(&heapSize,Align::Left,&GUI::zero,&GUI::zero,TFT_WIDTH/16,&GUI::defaultFcolor,&GUI::defaultBcolor,false));              
        #endif
        //DEBUG_PRINT("\nnew screen widget size: %i",gui->screenGUIs.size());
        if (gui->transparency) gui->clearScreenBuffer();
        oldScreen.value = screen.value;      
        // these are the only screens that can be recall after startup
        if (screen.id == SCREEN_MODULE || screen.id == SCREEN_CONNECTION_WIZARD){
          persistants.putUChar(PERSISTANT_SCREEN_ID,screen.id);
          persistants.putUChar(PERSISTANT_SCREEN_STATE,screen.state);
          if (debug) DEBUG_PRINT("\nsaving screen persistants");
        }
        //do some clean up and 
        menuItemIcon[0] = " "; // clean up menu icon
        menuItemIcon[1] = " "; 
        menuItemIcon[2] = " "; 
      }
      gui->refresh(force);
      
      //------------------
      //
      // MANAGE APPLICATION FLOW
      //
      //------------------

      switch(screen.id){
        case SCREEN_UTILS:
          switch(screen.state){
            case STATE_UTILS_CONNECTCONFIGMEDIA:                            
              if (hwm->configMedia->refreshed){
                handleConfigConnection();                 
              } 
            break;
            case STATE_UTILS_CONNECTWEBAPP:              
              if (hwm->configMedia->refreshed){
                handleConfigConnection();
              }
              if (webAppConnected == true){ // when web app connect we go back to normal screen
                DEBUG_PRINT("\n\t\t\t\t\t\t\t\t\t\tTRACE1 **********************");
                hwm->network->WiFiEnabled = true ; // WiFi STA authorized to go, in case it was stopped by configMedia (AP) move it into the if below, this code should be moved to the webapp setup wifi callback
                setAPandNetIcons();
                restoreScreen();
              }
            break;
            case STATE_UTILS_WEBAPPCONNECTED:
              if (hwm->configMedia->refreshed){
                handleConfigConnection();
              }              
            break;
          }
        break;
        case SCREEN_MENU:          
          if (refreshed) menuSystemFullRefresh(); 
        break;
        case SCREEN_MODULE_SWITCH:          
          if (refreshed) menuSwitchModuleFullRefresh(); 
        break;
        case SCREEN_BYE:
          switch(screen.state){ 
            case STATE_BYE_BATTERY_AND_SLEEP:
            //case STATE_BYE_ERROR_AND_SLEEP: // we do not shutdown, we leave it on so we can go to the men for instance to perform some action like update or ftp ...
              if (millis()-shutDownTimeOut>5000) goDeepSleep();
            break;
          }
        break;
      }


      //------------------
      //
      // MANAGE DEBUGGING 
      //
      //------------------
      uint32_t mem = ESP.getFreeHeap();
      if (mem>maxHeapSize) maxHeapSize = mem;
      if (mem<minHeapSize) minHeapSize = mem;
      heapSize = String(minHeapSize)+"/"+String(mem)+"/"+String(maxHeapSize);

      return refreshed;
    }

    void broadCast(String msg){
        if (webAppOn && hwm->configMedia->state == CONNECTED) wss->broadcast(WebSocketDataType::TEXT, msg.c_str(), msg.length());  
    }

    void reset(){      
      nvs_flash_erase(); // erase the NVS partition and...
      nvs_flash_init(); // initialize the NVS partition.        
      // next: delete conf file   
    }

    void setWSServer(){
      
      //if (hwm->configMedia->state != CONNECTED) return;  // optionnal

      if (wss != nullptr){ delete wss; if (debug) DEBUG_PRINT("\nDELETE WSS");}
      //start socket services
      if (debug) DEBUG_PRINT("\nINSTANTIATING WSS");
      
      if (hwm->configMedia->media == CABLE) wss = new EthernetWebSocketServer{};
      else wss = new WiFiWebSocketServer{};

      wss->onConnection(socketConnectionCallback);    
      wss->begin();

    }

    bool startWebApp(){
      webAppOn = false;
      if (hwm->configMedia != nullptr){
        if (!webAppOn && hwm->configMedia->state == CONNECTED){          
          //start webserver
          if (webServer != nullptr) delete webServer;
          webServer = new Application();
          webServer->use(webAppCallbackWrapper);
          setWSServer();
          webAppOn = true;
          hwm->configIP = hwm->configMedia->IP.toString();
          /* Initialize mDNS => doesnt work for ethernet so we give up and keep IP address
          if (debug) DEBUG_PRINT("\nstarting mdns: %s",config.getString(S_AP_NAME)->c_str());
          if (!MDNS.begin(*config.getString(S_AP_NAME))) {   // Set the hostname to "esp32.local"
            if (debug) DEBUG_PRINT("Error setting up MDNS responder!");
          } */           
        }
      }
      return webAppOn;
    }

    void fileServer(Request &req, Response &res){
      
      //if (req.method() != Request::GET) return;
      const char * path = req.path();
      if(strcmp(path, "/post") == 0){  // if a client call the url get then, we process the request
        httpPost(req,res);
      }else{
        //if(strcmp(path, "/") == 0) path = "/index.html.gz";
        if(strcmp(path, "/") == 0) path = "/indexnozip.html";

        String filenameRealExtension = path;
        if (filenameRealExtension.endsWith(".gz")){
          filenameRealExtension.replace(".gz","");
          res.set("Content-Encoding", "gzip");
        }

        String fullPath = "/webapp"+String(path);   
        if (!LittleFS.exists(fullPath)){
          //request->send(404, "text/plain", "Not found");    
          //res.setstatus(404)    ??
          return;
        }
        File file = LittleFS.open(fullPath);
        if (file.isDirectory()) return;
        #define MIME_TYPES_MAX 14
        String mimeTypes[MIME_TYPES_MAX][2] ={
                                {"html",  "text/html"},
                                {"js",    "application/javascript"},
                                {"json",  "application/json"},
                                {"jpeg",  "image/jpeg"},
                                {"jpg",   "image/jpeg"},
                                {"gif",   "image/gif"},
                                {"png",   "image/png"},  
                                {"txt",   "text/plain"},  
                                {"htm",   "text/html"},
                                {"xml",   "application/xml"},  
                                {"css",   "text/css"},  
                                {"gz",    "application/gzip"},  
                                {"zip",   "application/zip"},
                                {"ttf",   "font/ttf"}
                              };
        String mimeType = mimeTypes[0][1];
        for (uint8_t i=0;i<MIME_TYPES_MAX;i++){
          if (filenameRealExtension.endsWith(mimeTypes[i][0])) mimeType = mimeTypes[i][1];
        }

        if (debug) DEBUG_PRINT("\n REAL EXTENSION: %s MIME:%s",filenameRealExtension.c_str(),mimeType.c_str());
        res.set("Content-Type", mimeType.c_str());
        webAppLoadPending[0] = iconCycle[0]; // set icon to indicate pending transfer
        webAppLoadPending[1] = iconCycle[1];
        while (file.available()) res.write(file.read());
      }
      res.end();
    }

    void render(Menu const& menu) const {}
    void render_menu_item(MenuItem const& menu_item) const {}
    void render_back_menu_item(BackMenuItem const& menu_item) const {}
    void render_numeric_menu_item(NumericMenuItem const& menu_item) const {}
    void render_menu(Menu const& menu) const {}  

    void menuSystemFullRefresh(){  
      //DEBUG_PRINT("\nmenuSystemFullRefresh");
      setMenuSystemItems();
      //widgets[MENU_ICON_MIDDLE].widget->setFcolor(glowingGoldColor.value); // restore color
      glowingGoldColor.value = &menuActiveIconColor;
      widgets[CONFIG_TEXTAREA_MESSAGE]->setText(lang.getString(" ")); // empty message
    }

    void setMenuSystemItems(){
      //ms.get_current_menu()->get_current_component(
      Menu const* menu = ms.get_current_menu();
      uint8_t numItem = menu->get_num_components();  

      MenuComponent const* cp_m_comp;
      uint8_t selection = 0;

      cp_m_comp = menu->get_current_component();
      const char* menuString = cp_m_comp->get_name();
      menuItemIcon[1] = getIconFromString(menuString);
      selection = menu->get_current_component_num();    

      widgets[MENU_LABEL_TITLE]->setText(lang.getString(getNameFromString(menuString))); // restore title  

      if (debug) DEBUG_PRINT("\nsetMenuSystemItems name:%s numItem:%i currentCOmponantName: %s",menu->get_name(),numItem,menuString);

      if (numItem == 2){
        if (selection == numItem-1){ 
          // left = right = first item
          menuItemIcon[0] = getIconFromString(menu->get_menu_component(0)->get_name());
          menuItemIcon[2] = getIconFromString(menu->get_menu_component(0)->get_name());
        }else{
          // left = right = second ite,
          menuItemIcon[0] = getIconFromString(menu->get_menu_component(1)->get_name());
          menuItemIcon[2] = getIconFromString(menu->get_menu_component(1)->get_name());
          
        }
      }else if (numItem > 2){
        if (selection == numItem-1){ // last item
          // left icon = -1, right icon = first item
          menuItemIcon[0] = getIconFromString(menu->get_menu_component(selection-1)->get_name());
          menuItemIcon[2] = getIconFromString(menu->get_menu_component(0)->get_name());
        }else if (selection == 0){ // first item
          // left icon = last item, right icon = +1
          menuItemIcon[0] = getIconFromString(menu->get_menu_component(numItem-1)->get_name());
          menuItemIcon[2] = getIconFromString(menu->get_menu_component(selection+1)->get_name());
        }else{ // any item in between
          // normal case, we take the -1 and +1 item
          menuItemIcon[0] = getIconFromString(menu->get_menu_component(selection-1)->get_name());
          menuItemIcon[2] = getIconFromString(menu->get_menu_component(selection+1)->get_name());
        }  
      }
    }

    void setMenuSwitchModuleItems(){
      //ms.get_current_menu()->get_current_component(
      Menu const* menu = moduleMenu->get_current_menu();
      uint8_t numItem = menu->get_num_components();  

      MenuComponent const* cp_m_comp;
      cp_m_comp = menu->get_current_component();
      const char* menuString = cp_m_comp->get_name();
    
      uint8_t selection = menu->get_current_component_num();    
      Module* module = modules.get(selection);      
      widgets[MENU_LABEL_TITLE]->setText(&module->name); // restore title  
      menuItemIcon[1] = module->icon;

      if (selection == numItem-1){ // last item
        // left icon = -1, right icon = first item
        menuItemIcon[0] = modules.get(selection-1)->icon;
        menuItemIcon[2] = modules.get(0)->icon;
      }else if (selection == 0){ // first item
        // left icon = last item, right icon = +1
        menuItemIcon[0] = modules.get(numItem-1)->icon;
        menuItemIcon[2] = modules.get(selection+1)->icon;
      }else{ // any item in between
        // normal case, we take the -1 and +1 item
        menuItemIcon[0] = modules.get(selection-1)->icon;
        menuItemIcon[2] = modules.get(selection+1)->icon;
      }  

    }

    void menuSwitchModuleFullRefresh(){  
      //DEBUG_PRINT("\nmenuSystemFullRefresh");
      setMenuSwitchModuleItems();
      //widgets[MENU_ICON_MIDDLE].widget->setFcolor(glowingGoldColor.value); // restore color
      glowingGoldColor.value = &menuActiveIconColor;
      widgets[CONFIG_TEXTAREA_MESSAGE]->setText(lang.getString(" ")); // empty message
    }


    void testOSC(){
      if (hwm->network->state == CONNECTED){
        SendCmd2OSC(hwm->network->udp, "/xinfo");
        delay(20);
        OSCReadIn(hwm->network->udp);      
      }else{
        DEBUG_PRINT("\nNO OSC Connection");
      }
    }

    void SendCmd2OSC(UDP* udp, const char* address)       // Send OSC command (buffer), no value (status request)
    {
      DEBUG_PRINT("\n>>(10023):%s",address);
      OSCMessage msg(address);
      udp->beginPacket("192.168.0.1", 10023);
      msg.send(*udp);
      udp->endPacket();
      msg.empty();
    }


    boolean OSCReadIn(UDP* udp) {
      DEBUG_PRINT("\n<<:");
      char PacketBuffer[24];
      int size = udp->parsePacket();
      if (size < 1) return false;
      OSCMessage msg;
      while (size--) msg.fill(udp->read());
      if (msg.hasError()) {
        return false;
      }
      msg.getAddress(PacketBuffer, 0);                // get message path
      String CommandStr = String(PacketBuffer);              // assign to CommandStr
      char TypeStr = msg.getType(0);                       // get data type
      char sValue[50];
      if (msg.isString(0)) {
        msg.getString(0, sValue);  // string
      }
      msg.empty();
      DEBUG_PRINT("%s",sValue);
      return true;
    }

    ///////////////////////////////////////////////////////////////////////

    //  APPLICATION & WORKFLOW MANAGEMENT METHODS

    ///////////////////////////////////////////////////////////////////////
    bool stripScroll(uint8_t direction) {
      
      bool changedWindow = false; bool forceChangedWindow = false;
      Module* module = modules.get(screen.state);

      // check that there is at least one slot available min this module otherwise, we will have an infinite recursive call
      uint8_t nEmpty = 0;
      for (; nEmpty < MODULE_MAX_STRIPS; nEmpty++) if (module->strips[nEmpty] != nullptr) break;
      if (nEmpty < MODULE_MAX_STRIPS) {

        if (direction == RIGHTB_ID) {
          module->selector++;
          if (module->selector == STRIP_PER_WINDOW) {
            module->selector = 0;
            module->window++;
            if (module->window == module->getMaxWindow()) module->window = 0;
            changedWindow = true;
          }
        } else if (direction == LEFTB_ID){
          if (module->selector == 0) {
            if (module->window == 0) module->window = module->getMaxWindow() - 1; 
            else module->window--;
            module->selector = STRIP_PER_WINDOW-1;
            changedWindow = true;
          } else module->selector--;
        }else return false;

        forceChangedWindow = changedWindow;
        //we now check if slot is empty so we skip it
        module->stripIndex = (module->window * STRIP_PER_WINDOW) + module->selector;
        if (module->strips[module->stripIndex] == nullptr) {
          int8_t before = module->window;
          //manage the case when an empty slot is the first or last of a window... it means we have to force the refresh as it will change the winodow
          changedWindow = stripScroll(direction);
          int8_t after = module->window;
          if (before != after) changedWindow = true;
        }
      }
      if (forceChangedWindow) changedWindow=true;

      // final check: if we only have one windows, any flag set above to change windows becomes invalid...
      if (module->getMaxWindow() == 1) changedWindow = false;

      //DEBUG_PRINT("\nmodule->stripIndex:%i changedwindow:%i",module->stripIndex, changedWindow);
      return changedWindow;
    }

    bool stripAction() {    
      Module* module = modules.get(screen.state);    
      return module->strips[module->stripIndex]->actionCallback();
    }

    bool stripChangeValue(uint8_t direction, unsigned long time){
      bool success = false;
      
      Module* module = modules.get(screen.state);    

      if (direction == RIGHTB_ID){ success = module->strips[module->stripIndex]->increaseCallBack(time);}      
      else if (direction == LEFTB_ID){ success = module->strips[module->stripIndex]->decreaseCallback(time);}      

      return success;
    }


    /////////////////////////////////////////////////////////////////////////////////////
    String parseJsonInput(String input){
      DynamicJsonDocument jsonInput = DynamicJsonDocument(input.length()*10);
      deserializeJson(jsonInput, input);
      String command = jsonInput["command"];

      String answer = "{";

      if (command == "echo"){                    
        answer += "\""+jsonInput["message"].as<String>()+"\"";
      }else if (command == "retrieve"){
        answer += "\""+jsonInput["param"].as<String>()+"\":";        
        if(jsonInput["param"] == "fullConfig"){
          String fullConfig;
          serialize(&fullConfig);
          answer += fullConfig;
        }else if (jsonInput["param"] == C_MODULES){
          //modules;
        }else if (jsonInput["param"] == "module"){
          String moduleName = jsonInput["name"];            
          // getModule(moduleName)->serialize()
        }
      }else if (command == "set"){
        answer+="\"setSaveButton\":";          // when we receive a "set" command, we process it and reply with a "save" token as callback function, with a  parameter to indicate true if user should save or 0 if not
        String section = jsonInput["section"];
        String id = jsonInput["id"];
        String value = jsonInput["value"];
        DEBUG_PRINT("\t => section:%s id:%s value:%s",section.c_str(),id.c_str(),value.c_str());
        if (section == "system"){          
          answer+=String(system.setValue(id,value));
        }else if (section == "config"){

        }else{

        }
      }else if (command == "save"){        

      }else{
        answer += "\"undefinedCallBack\":\"\"";
      }
      answer += "}";

      if (debug){
        DEBUG_PRINT("\n\t\t parseJsonInput answer=><%s>",answer.c_str());                 
      } 

      return answer;
    }    

  private:
    HardwareManager* hwm;
    GUIManager* gui;
    LinkedList<screenBuilder*> screenBuilders = LinkedList<screenBuilder*>();    
    

    unsigned long shutDownTimeOut;

    JsonList wiFiList;
         
    String defaultSysConf = "{"
    //"\""+String(S_CONFIGNAMES)+"\":[\"anto\",\"thomas\",\"laurent\"]\","
      "\""+String(S_PUSHDELAY)+"\":\"2\","
      "\""+String(S_DCLICREACTIVITY)+"\":\"1\","
      "\""+String(S_CONFIG_FILE)+"\":\"default.conf\"," 
      "\""+String(S_AP_NAME)+"\":\"footswitch\","
      "\""+String(S_LAST_USED_SSID)+"\":\"intervalmix\","
      "\""+String(S_LANG)+"\":\"ENGLISH\","
      "\""+String(S_FADERSPEED)+"\":\"3\","
      "\""+String(S_SSID)+"\":{\"intervalmix\":\"intervalpop74\",\"infrafast\":\"Mf9k8iie2\",\"ssid3\":\"pass3\"}"
    "}";

    String defaultUserConf = 
      "\""+String(C_MODULES)+"\":{"
        "\"MODULE j1\":[{\"icon\":\"b\",\"possibleLayout\":3,\"currentLayout\":0,\"active\":false,\"strips\":[{\"id\":\"text\",\"index\":1,\"properties\":[\"change\"]},{\"id\":\"text\",\"index\":3,\"properties\":[\"me\"]}]}],"
        "\"MODULE j2\":[{\"icon\":\"g\",\"possibleLayout\":4,\"currentLayout\":1,\"active\":1,\"strips\":[{\"id\":\"ch2bus\",\"index\":0,\"properties\":[\"/ch/02/name\",\"/bus/07/name\",\"/ch/04/color\"]},{\"id\":\"chGain\",\"index\":2,\"properties\":[\"/ch/11/name\",\"/ch/03/color\"]},{\"id\":\"text\",\"index\":4,\"properties\":[\"helloWorld\"]}]}],"
        "\"MODULE j3\":[{\"icon\":\"h\",\"possibleLayout\":2,\"currentLayout\":2,\"active\":true,\"strips\":[{\"id\":\"text\",\"index\":0,\"properties\":[\"another\"]},{\"id\":\"text\",\"index\":1,\"properties\":[\"one\"]}]}]"        
      "}";

    Application* webServer = nullptr;
    ScreenUnion oldScreen;    

    LinkedList<String*> countryList = LinkedList<String*>();   

    bool webAppOn = false;
    IWebSocketServer *wss{ nullptr };        

    uint32_t minHeapSize,maxHeapSize;
    String heapSize;

    ///////////////////////////////////////////////////////////////////////

    void httpPost(Request &req, Response &res){
      #define COMMAND_SIZE 500
      #define OPTION_SIZE 64
      char name[COMMAND_SIZE];
      char options[OPTION_SIZE];    //options is not used (the fetch from client puts everything in the name as a json)
      res.set("Content-Type", "application/json");
      while (req.left()) {        
        req.form(name, COMMAND_SIZE, options, OPTION_SIZE);        
        
        if (debug){
          DEBUG_PRINT("\n\t httpPost <%s>:<%s>",name,options);
        } 
        String answer = parseJsonInput(name);
        if (debug){
          DEBUG_PRINT("\n\t httpres:<%s>",answer.c_str());
        }
        res.print(answer);
      }  
    }  

    void populateFileList(String extension, LinkedList<String*> *list, String prefix="", bool withExtension=true) {
      //we first clean all items from the list

      while (list->size()>0){
        String* s = list->shift();
        delete(s);
      }

      File root = LittleFS.open("/");
      //DEBUG_PRINT("\nListing: .%s",extension.c_str());
      File file = root.openNextFile();
      while (file){
        if (!file.isDirectory()){
          String fullFileName = file.name();
          if (fullFileName.endsWith(extension)) {
            String* filename=new String(prefix);
            // if we don't want the extension, we remmove it          
            if (!withExtension) *filename += fullFileName.substring(0, fullFileName.lastIndexOf('.'));
            else *filename += fullFileName; // k is the icon ID
            list->add(filename);
            //if (debug) DEBUG_PRINT("\n\t %s",filename->c_str());          
          }
        }
        file = root.openNextFile();
      }
    }

    MenuItem* back_menu_item;
    MenuItem* info_menu_item;
    MenuItem* config_menu_item;
    Menu* profile_menu_item;
    MenuItem* save_profile_menu_item;

    void hookModuleToMenu(){
      if (modules.size()>1){
        if (moduleMenu != nullptr) delete moduleMenu;
        
        moduleMenu = new MenuSystem(*this); 
        // populate the menu with all modules
        
        for(int i = 0; i < modules.size(); i++){
          const char* moduleName = modules.get(i)->name.c_str();
          moduleMenu->get_root_menu().add_item(new MenuItem(moduleName, &switchToModule_item_selected));                
          if (debug){
            DEBUG_PRINT("\nadded menu entry: %s",countryList.get(i)->c_str());           
          }
        }
      }
    }    

};

#endif

