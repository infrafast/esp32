#ifndef APPManager_h
#define APPManager_h

#include <Preferences.h>
#include "nvs_flash.h" 
#include <LinkedList.h>
#include <ArduinoJson.h>
#include <Preferences.h>
//#include <esp32FOTA.hpp>

#include <aWOT.h>                 // awOT lasselukkari/aWOT@^3.5.0 wifi+eth server
                                  // apply patch https://github.com/arduino-libraries/Ethernet/pull/107/files
#include <MenuSystem.h>           // https://github.com/jonblack/arduino-menusystem                        
#include <LittleFS.h>
#include <WebSocketServer.hpp>    // https://github.com/skaarj1989/mWebSockets#meta
using namespace net;
using WiFiWebSocketServer = WebSocketServer<WiFiServer, WiFiClient, 1>;
using EthernetWebSocketServer = WebSocketServer<EthernetServer, EthernetClient, 1>;
void socketConnectionCallback(IWebSocket &ws);

///////////////////// WIDGET LOCATION & SIZE ////////////////////////
#define OVERLAY_ICON_SIZE TFT_WIDTH/20

///////////////////// SYSTEM PARAMETERS ////////////////////////
#define S_PUSHDELAY         "pushDelay"
#define S_DCLICREACTIVITY   "dClicReactivity"
#define S_FADERSPEED        "faderSpeed"
#define S_AP_NAME           "apName"
#define S_LANG              "lang"
#define S_CONFIG_FILE       "profile"
#define S_SSID              "ssid"
#define S_LAST_USED_SSID    "lastSSID"

///////////////////// CONFIG PARAMETERS ////////////////////////

#define C_CURRENTLAYOUT     "currentLayout"
#define C_POSSIBLELAYOUT    "possibleLayout"
#define C_BANKS             "banks"
  #define C_STRIPS          "strips"
    #define C_PROPERTIES    "properties"
    #define C_STRIPTYPE      "type"
    #define C_INDEX         "index"
    #define C_X             "x"
    #define C_Y             "y"
    #define C_SIZE          "size"
#define C_ICON              "icon"
#define C_COLOR             "color"

///////////////////// VOLATILE PARAMETERS ///////////////////////
#define V_USE_NETWORK       "myNetworkIP"

// C to C++ class function wrapper

void commonFileServerWrapper(Request &req, Response &res);  
void gzFileServer(Request &req, Response &res);
void scanNetworksTaskWrapper(void * parameter);
void defaultWizardStepFlow();

#define VOID_JSON_ITEM "\"void\": 0"

///////////////////// SCREEN APPLICATION MANAGEMENT ////////////////////////

//main screen (id)
enum{
  SCREEN_STARTUP,
  SCREEN_WIZARD,
  SCREEN_MENU,
  SCREEN_BANK_SWITCH,
  SCREEN_PROMPT,
  SCREEN_UTILS,
  SCREEN_BYE,
  SCREEN_BANK,
  SCREEN_MAX
};

//sub screen (state) 
enum{
  STATE_PROMPT_SEQUENCE_X,
  STATE_PROMPT_SEQUENCE_Y,
  STATE_PROMPT_SEQUENCE_Z,
  STATE_WIZARD_LANG_STEP1,
  STATE_WIZARD_CONNECT_CONFIG_STEP2,
  STATE_WIZARD_USER_STEP3,
  STATE_WIZARD_END_STEP4,
  STATE_UTILS_SEARCHING_CONNECTION,
  STATE_UTILS_INFO,
  STATE_UTILS_CONNECTCONFIGMEDIA,
  STATE_UTILS_CONNECTWEBAPP,
  STATE_UTILS_WEBAPPCONNECTED,
  STATE_BYE_GOSLEEP_MESSAGE,
  STATE_BYE_MODAL_MESSAGE,
};


void startupScreenBuilder(uint8_t id);
void wizardScreenBuilder(uint8_t id);
void menuScreenBuilder(uint8_t id);
void bankSwitchScreenBuilder(uint8_t id);
void promptScreenBuiler(uint8_t id);
void utilsScreenBuilder(uint8_t id);
void byeScreenBuilder(uint8_t id);
void bankScreenBuilder(uint8_t id);
void voidOverlay(uint8_t id);

void baseOverLayBuilder(uint8_t id);
void bankOverlayBuilder(uint8_t id);

screenBuilder screens[SCREEN_MAX]={
  {SCREEN_STARTUP,startupScreenBuilder,baseOverLayBuilder},
  {SCREEN_WIZARD,wizardScreenBuilder,baseOverLayBuilder},
  {SCREEN_MENU,menuScreenBuilder,baseOverLayBuilder},
  {SCREEN_BANK_SWITCH,bankSwitchScreenBuilder,baseOverLayBuilder},
  {SCREEN_PROMPT,promptScreenBuiler,baseOverLayBuilder},
  {SCREEN_UTILS,utilsScreenBuilder,baseOverLayBuilder},  
  {SCREEN_BYE,byeScreenBuilder,voidOverlay},
  {SCREEN_BANK,bankScreenBuilder,bankOverlayBuilder},
};

typedef bool (*ParseJsonInputCallback)(JsonDocument,String*);
typedef void (*NetworkChangeStateCallback)(bool state);
typedef void (*WizardScreenBuilderCallback)();
typedef void (*WizardSstepFlowCallback)();

bool defaultParseJsonInputCallback(JsonDocument jsonDoc,String* answer){
  String jsonInputString;
  serializeJson(jsonDoc, jsonInputString);
  DEBUG_PRINT("\ndefaultParseJsonInputCallback(%s)",jsonInputString.c_str());
  return false;
}

void defaultWizardScreenBuilder();

void defaultNetworkChangeStateCallback(bool state){
  DEBUG_PRINT("\ndefaultNetworkChangeStateCallback(%i)",state);  
}

///////////////////// BUTTONS CALLBACKS ////////////////////////
void simpleClicCallBack(uint8_t buttonID, unsigned long time);
void longClicCallBack(uint8_t buttonID, unsigned long time);
void doubleClicCallBack(uint8_t buttonID, unsigned long time);
void releaseHoldCallback(uint8_t buttonID, unsigned long time);
void holdCallback(uint8_t buttonID, unsigned long time);

void menuSwitchCallback(uint8_t buttonID, unsigned long time);


void info_item_selected(MenuComponent* p_menu_component);
void config_menu_item_selected(MenuComponent* p_menu_component);
void back_menu_item_selected(MenuComponent* p_menu_component);
void save_profile_item_selected(MenuComponent* p_menu_component);
void loadLangFromMenu_item_selected(MenuComponent* p_menu_component);
void switchToBank_item_selected(MenuComponent* p_menu_component);
void tft_rotation_item_selected(MenuComponent* p_menu_component);
void reset_item_selected(MenuComponent* p_menu_component);
void shutdown_menu_item_selected(MenuComponent* p_menu_component);
void menu_selected(MenuComponent* p_menu_component);

void handleConfigConnection();  // 


///////////////////// DATA MANAGEMENT ////////////////////////
#include <vector>

class DataSet1{
  public:
    #define JSON_ARRAYITEM_STRING_SIZE 90
    String address;
    String object;
    LinkedList<String> values;

    String serialize(){
      //DynamicJsonDocument doc(JSON_ARRAYITEM_STRING_SIZE*values.size());
      JsonDocument doc;
      JsonArray jsonValues = doc[address].to<JsonArray>(); //doc.createNestedArray(address);
      for (uint8_t i=0; i< values.size(); i++) jsonValues.add(values.get(i));
      String data;
      serializeJson(doc,data);
      //DEBUG_PRINT("\n\n\tdataset->serialize: %s\n\n", data.c_str());
      return data;
    }
};

class DataSet{
  public:
    #define JSON_ARRAYITEM_STRING_SIZE 90
    String address;
    String object;
    std::vector<String> values;

    String serialize(){
      //DynamicJsonDocument doc(JSON_ARRAYITEM_STRING_SIZE*values.size());
      JsonDocument doc;
      //JsonArray jsonValues = doc.createNestedArray(address);
      JsonArray jsonValues = doc[address].to<JsonArray>();
      for (uint8_t i=0; i< values.size(); i++) jsonValues.add(values[i]);
      String data;
      serializeJson(doc,data);
      //DEBUG_PRINT("\n\n\tdataset->serialize: %s\n\n", data.c_str());
      return data;
    }
};



class DataRepository{
  public:
    DataRepository(){}

    DataSet* getDataSet(String address){
      for (uint8_t i=0;i<dataSets.size();i++){
        DataSet* ds = dataSets.get(i);        
        if (address == ds->address){          
          return ds;
        } 
      }
      return nullptr;
    }

    bool addDataSet(DataSet* ds){
      dataSets.add(ds);
      /*String object = ds->object;
      String address = ds->address;      */
      return true;
    }

    void serialize(JsonArray* jsonDataSets){
      for (uint8_t i=0;i<dataSets.size();i++){
        DataSet* ds = dataSets.get(i);
        jsonDataSets->add(ds->serialize());
      }
    }



  private:
    LinkedList<DataSet*> dataSets = LinkedList<DataSet*>();
};


class StripSkeleton;
///////////////////// STRIP MANAGEMENT ////////////////////////
#define INPUTSELECT "dropdown"
#define INPUTTEXT   "freetext"

#define LAYOUT_DETAILS  0b00000001
#define LAYOUT_ICON     0b00000100
#define LAYOUT_QUATUOR  0b00010000

class Strip : public GenericComponent{  
  #define JSON_STRIP_PROPERTY_SIZE 100
  #define  JSON_STRIP_TEMPLATE_SIZE 300
  public:
    TFT_eSprite* sprite = nullptr;
    uint8_t index;
    uint8_t x, y;
    String size;
    unsigned char icon = 0x21;

    GUIManager* gui;

    Strip(StripSkeleton* s, GUIManager* g, bool debug=false):GenericComponent(debug){
      skeleton = s;
      gui = g;
      value = (valueMax-valueMin)/2;
      //id = skeleton->stripID;
    }    

    ~Strip(){
      DEBUG_PRINT("\n~Strip(): %s",id.c_str());
    }

    virtual bool refresh(bool force=false){
      frontColor = colorMap[colorID].fColor;
      backColor = colorMap[colorID].bColor;      
      return refreshed;
    }

    bool deserialize(String values){
      bool ret = false;
      DEBUG_PRINT("\n\t deserialize STRIP(%s)",values.c_str());
      uint8_t n = getNumberOfProperties();
      DEBUG_PRINT("\t getNumberOfProperties():%i",n);      
      //DynamicJsonDocument jsonStrip(350+JSON_STRIP_PROPERTY_SIZE*n);          
      JsonDocument jsonStrip;
      DeserializationError error = deserializeJson(jsonStrip, values);
      if (error){
        DEBUG_PRINT("\n\tStrip <%s> deserialization error:%s",id.c_str(),error.f_str());
      }else{      
        id = jsonStrip[C_STRIPTYPE].as<String>();
        DEBUG_PRINT("\t<%s> properties:",id.c_str());   /////////////////// CONTINUE DEBUG
        // set index; 
        index = jsonStrip[C_INDEX];//.as<int>();
        x = jsonStrip[C_X].as<int>();
        y = jsonStrip[C_Y].as<int>();
        size = jsonStrip[C_SIZE].as<String>();
        colorID = jsonStrip[C_COLOR];//.as<int>();
        icon = jsonStrip[C_ICON];//.as<unsigned char>();
        DEBUG_PRINT("\tindex=%i, colorID=%i, icon=%c",index,colorID,icon);
        properties = jsonStrip[C_PROPERTIES];
        for (uint8_t i = 0; i< properties.size(); i++){
          deserializeProperty(properties[i].as<String>());
        }
        ret = true;
        // each derived strip then deserialiuze its own other values
        
      }
      return ret;
    };

    String serialize(){
      //DEBUG_PRINT("\nserialize %s=>",id.c_str());
      //DynamicJsonDocument doc(JSON_STRIP_TEMPLATE_SIZE+JSON_STRIP_PROPERTY_SIZE*getNumberOfProperties());   
      JsonDocument doc;
      doc[C_STRIPTYPE] = id;  // this is a text
      doc[C_INDEX] = index;
      doc[C_COLOR] = colorID;
      doc[C_ICON] = icon;
      doc[C_X] = x;
      doc[C_Y] = y;
      doc[C_SIZE] = size;
      //properties = doc.createNestedArray(C_PROPERTIES);   
      properties = doc[C_PROPERTIES].to<JsonArray>();
      serializeProperties();
      String data;
      serializeJson(doc, data);
      //DEBUG_PRINT("%s",data.c_str());
      return data;
    }

    /*virtual void wipeWidgets(){
      DEBUG_PRINT("\nwipe %s, number of widgets:%i",id.c_str(),widgetHandles.size());
      int16_t xMin=TFT_WIDTH, xMax=0, yMin=TFT_HEIGHT, yMax=0;

      while (widgetHandles.size()>0){          
          
          Widget* widget = widgetHandles.shift();
          
          if (widget->getX()<xMin) xMin = widget->getX();
          if (widget->getX()+widget->width > xMax) xMax = widget->getX()+widget->width;
          if (widget->getY()<yMin) yMin = widget->getY();
          if (widget->getY()+widget->height > yMax) yMax = widget->getY()+widget->height;      

          //DEBUG_PRINT("\tcls %s  (%i,%i,h:%i,w:%i)  minMax=>(%i,%i,w:%i,h:%i)",widget->id.c_str(),widget->getX(),widget->getY(),widget->width,widget->height,xMin,xMax-xMin,yMin,yMax-yMin);

          GUI::tft->fillRect(xMin,yMin,xMax-xMin,yMax-yMin,GUI::defaultBcolor);

          //DEBUG_PRINT("\nremove gui->remove(%s) before:%i",widget->id.c_str(),gui->screenGUIs.size());
          gui->remove(widget);          
          delete(widget);       
          //DEBUG_PRINT("\tafter:%i",gui->screenGUIs.size());        

      }
    }*/

    virtual bool progressiveDelay(unsigned long time){
      uint16_t TIME_MAX_PROGRESSIVITY = 3000;
      if (valueMax-valueMin<=20) TIME_MAX_PROGRESSIVITY = 5000;
      else if (valueMax-valueMin>500) TIME_MAX_PROGRESSIVITY = 1000;

      //we start counting the time between two calls when we have called the first time, means during debounce duration
      if (time<DEBOUCE_TIME){
        lastCall = 0;      
        // first call we start timer

      }
      if (time>=TIME_MAX_PROGRESSIVITY) time = TIME_MAX_PROGRESSIVITY;

      unsigned long waitBetween2update = (TIME_MAX_PROGRESSIVITY-time)/5;
      unsigned long delaySoFar = millis() - lastCall;

      //DEBUG_PRINT("\nprogressiveDelay(%d) - %u/%u -",time, delaySoFar, waitBetween2update);          

      if (delaySoFar < waitBetween2update) return false;  
      lastCall = millis();
 
      return true;    
    }

    /*virtual bool increaseCallBack(unsigned long time) = 0;
    virtual bool decreaseCallback(unsigned long time) = 0;
    virtual float getIncrement(unsigned long time)=0;*/

    virtual float getIncrement(unsigned long time){
      float increment;
      //value = roundHalf(value);
      if (time<2000){
        increment = 0.1;
      }else{
        float diff = valueMax - value;
        float percentageToTarget = map(diff,0,valueMax-valueMin,100,1)/2000.0;  // 3000 seems to be a good compromise between delay and precision, 2000 react quicker but skip some decimal
        increment = diff*percentageToTarget;          
        //DEBUG_PRINT("\t => diff: %.3f, percentageToTarget: %.3f",diff, percentageToTarget);        
      }
      //DEBUG_PRINT("\t value: %.3f, increment: %.4f, ",value,increment);
      return increment;
    }    

    virtual bool increaseCallBack(unsigned long time){            
      if (!Strip::progressiveDelay(time)) return true;
      value += getIncrement(time);

      if (value > valueMax) value = valueMax;
      //value = truncateToOneDecimal(value);
      
      DEBUG_PRINT("\nincreaseCallBack: %s, time:%s",String(value).c_str(),String(time).c_str());

      return true;      
    }

    virtual bool decreaseCallback(unsigned long time){
      if (!Strip::progressiveDelay(time)) return true;      
      value -= getIncrement(time);
      

      if (value < valueMin) value = valueMin;

      //value = truncateToOneDecimal(value);

      DEBUG_PRINT("\ndecreaseCallback: %.2f",value);

      return true;      
    }

    virtual uint8_t getNumberOfProperties()=0;
    virtual bool actionCallback()=0;
    virtual void serializeProperties()=0;
    virtual void deserializeProperty(String s)=0;    
    virtual void buildWidgets(uint8_t layout)=0;
    

    JsonArray properties;
    StripSkeleton* skeleton;
    //LinkedList<Widget*> widgetHandles = LinkedList<Widget*>();
    float value = 0.0, valueMin = 0, valueMax = 1;
  protected:
    uint8_t colorID=0; 
    uint16_t frontColor, backColor;    
    unsigned long lastCall;        
};

typedef Strip* (*StripBuilderCallback)(/*String values*/);

#define MAXNUMBER_OF_SKELETON 20

class StripSkeleton{
  #define STRIP_DEFAULT_GROUP "utils"
  #define MAXNUMBER_OF_SKELPROPERTY 10
  #define STRIP_SKELETON_PROPERTIES "properties"

  #define JSON_SKELETON_SIZE 30*MAXNUMBER_OF_SKELPROPERTY
  public:
    String stripID;
    unsigned char icon;
    String group;
    StripBuilderCallback constructor;
    //JsonObject variable;
    LinkedList<String> dataSetAddresses = LinkedList<String>();
    static DataRepository* dataRepo;

    uint8_t numberOfProperties = 0;  

    StripSkeleton(String id, String g, StripBuilderCallback b, unsigned char i='!'){
      stripID = id;
      group = g;
      icon = i;
      constructor = b;
    }

    String getValue(String address, uint8_t index){
      DataSet* ds = dataRepo->getDataSet(address);
      if (ds != nullptr) return ds->values[index];
      else return "null";
    }

    bool registerDataSetAddress(String address){
      dataSetAddresses.add(address); 
      numberOfProperties++;
      if (numberOfProperties>MAXNUMBER_OF_SKELPROPERTY) return false;  
      return true;
    }

    String serialize(){
      //DynamicJsonDocument jsonDocStripSkeleton = DynamicJsonDocument(JSON_SKELETON_SIZE);
      JsonDocument jsonDocStripSkeleton;
      JsonArray properties;
      jsonDocStripSkeleton[stripID] = group;
      jsonDocStripSkeleton[C_ICON] = icon;
      //properties = jsonDocStripSkeleton.createNestedArray(STRIP_SKELETON_PROPERTIES); 
      properties = jsonDocStripSkeleton[STRIP_SKELETON_PROPERTIES].to<JsonArray>();     
      for (uint8_t i = 0; i < numberOfProperties; i++){
        DataSet* ds = dataRepo->getDataSet(dataSetAddresses.get(i));
        if (ds != nullptr){
          JsonObject kv = properties.add<JsonObject>();
          kv[ds->address] = ds->object;
        }         
      }
      String data;
      serializeJson(jsonDocStripSkeleton, data);
      //DEBUG_PRINT("\nskeleton->serialize: %s",data.c_str());
      return data;
    }

};

// default skeleton
StripSkeleton* stripTextSkel;
Strip* textStripConstructorCallback();

class TextStrip : public Strip{
  
  #define STRIP_TEXT "text"
  //#define STRIP_TEXT_PROPERTY_VALUE "value"
  
  public:  
        
    TextStrip(StripSkeleton* s,GUIManager* g,bool debug=false):Strip(s,g,debug){
      //icon = ICON_TEXT_STRIP;
    }

    ~TextStrip(){
    }

    virtual bool actionCallback(){return true;}

    virtual void buildWidgets(uint8_t layout){
      switch(layout){
        case LAYOUT_QUATUOR:
        break;
        case LAYOUT_ICON:
        break;
        case LAYOUT_DETAILS: 
        default:
          if (debug) DEBUG_PRINT("\n%s:buildWidgets Label(%s)",id.c_str(),value.c_str());
          Label* label = new Label(&value, Align::Center,&x,&y,100,&frontColor,&backColor,false);
          //widgetHandles.add(label);          
          gui->add(label);
        break;
      }
    }

    virtual void deserializeProperty(String property)  {      
      value = property;
      //if (debug){DEBUG_PRINT("\tvalue=%s",value.c_str());}
      /*
      if (sscanf(property.c_str(), select2PropertyAddress.c_str(), &select2ID)){
        //DEBUG_PRINT("\t%s=%i",select2PropertyAddress.c_str(), select2ID);      
      } */ 

    }

    void serializeProperties(){
      properties.add(value);    
    }

    virtual bool refresh(bool force=false){
      refreshed = force;
      Strip::refresh(force);
      return refreshed;
    };

    virtual uint8_t getNumberOfProperties(){
      return skeleton->numberOfProperties;      
    }

    virtual bool increaseCallBack(unsigned long time){return true;}
    virtual bool decreaseCallback(unsigned long time){return true;}
    virtual float getIncrement(unsigned long time){return 0.0;}

    private:
      String value="";
      int16_t x=GUI::width()/2, y=GUI::height()/2;       
};

class TwoSelectStrip : public Strip{

  public: 
    TwoSelectStrip(StripSkeleton* s,GUIManager* g,String *select2String, bool debug=false):Strip(s,g,debug){
      select2Content = select2String;
    }

    void serializeProperties(){
      char* buf = (char*)malloc(select2PropertyAddress.length()*sizeof(char*));
      sprintf(buf,select2PropertyAddress.c_str(),select2ID);
      properties.add(String(buf));
      delete buf;

    }

    void deserializeProperty(String property){
      if (sscanf(property.c_str(), select2PropertyAddress.c_str(), &select2ID)){
        //DEBUG_PRINT("\t%s=%i",select2PropertyAddress.c_str(), select2ID);      
      }    
    }  

    virtual uint8_t getNumberOfProperties(){
      return skeleton->numberOfProperties;      
    }
 
  protected:
    uint8_t select2ID=1; 
    String *select2Content;
    String select2PropertyAddress;
};


class ThreeSelectStrip: public TwoSelectStrip{
  public:
    ThreeSelectStrip(StripSkeleton* s,GUIManager* g, String *select2String, String *select3String, bool debug=false):TwoSelectStrip(s,g,select2String,debug){
      select3Content = select3String;
    }
  
    void serializeProperties(){
      TwoSelectStrip::serializeProperties();

      char* buf = (char*)malloc(select3PropertyAddress.length()*sizeof(char*));
      sprintf(buf,select3PropertyAddress.c_str(),select3ID);
      properties.add(String(buf));
      delete buf;

    }

    void deserializeProperty(String property){
      TwoSelectStrip::deserializeProperty(property);
      if (sscanf(property.c_str(), select3PropertyAddress.c_str(), &select3ID)){
        //DEBUG_PRINT("\t%s=%i",select3PropertyAddress.c_str(), select3ID);      
      }  

    }  

    virtual uint8_t getNumberOfProperties(){
      return skeleton->numberOfProperties;      
    }

  protected:
    uint8_t select3ID=1; 
    String *select3Content;
    String select3PropertyAddress;

};



class StripFactory{
  public:
    LinkedList <StripSkeleton*> stripSkeletonRepo = LinkedList<StripSkeleton*>();
    //std::vector<StripSkeleton*> stripSkeletonRepo;
    //StaticJsonDocument<10000> stripsDefinitions;

    bool add(StripSkeleton* ss){
      if (stripSkeletonRepo.size()>=MAXNUMBER_OF_SKELETON) return false;
      stripSkeletonRepo.add(ss);
      return true;
    }

    Strip* build(String stripID/*, String values*/){
      Strip* strip = nullptr;
      StripSkeleton* skel = getStripSkeleton(stripID);
      if (skel != nullptr) strip = skel->constructor(/*values*/);
      DEBUG_PRINT("\nbuild(%s)",stripID.c_str());     
      return strip;
    }

    String getDefinition(String stripID){
      String stringDef = "{\"null\":0}";
      StripSkeleton* skel = getStripSkeleton(stripID);
      if(skel != nullptr) stringDef = skel->serialize();
      return stringDef;
    }

    void serialize(JsonArray* jsonSkeletons){
      for (uint8_t i=0;i<stripSkeletonRepo.size();i++){
        StripSkeleton* skeleton = stripSkeletonRepo.get(i);
        String stripName = skeleton->stripID;
        jsonSkeletons->add(skeleton->serialize());
      }
    }

  private:
    StripSkeleton* getStripSkeleton(String stripID){
      //DEBUG_PRINT("\ngetStripSkeleton(%s)",stripID.c_str());
      for (uint8_t i=0;i<stripSkeletonRepo.size();i++){
        StripSkeleton* s = stripSkeletonRepo.get(i);        
        //DEBUG_PRINT("==%s?",s->stripID.c_str());
        if (stripID == s->stripID){
          //DEBUG_PRINT(": MATCH!");
          return s;
        } 
      }
      return nullptr;
    }
};

///////////////////// BANKS MANAGEMENT ////////////////////////

class Bank{  
  #define BANK_MAXWINDOW 3
  #define STRIP_PER_WINDOW 4
  #define BANK_MAX_STRIPS BANK_MAXWINDOW*STRIP_PER_WINDOW
  #define JSON_BANK_SIZE 3500 //JSON_STRIP_TEMPLATE_SIZE*BANK_MAX_STRIPS

  public:
    uint8_t window = 0;
    uint8_t selector = 0;   // which strips under focus in the 4x window
    uint8_t stripIndex = 0; // which strips currently under focus (liearIndex)
    uint8_t numberOfStrips = 0;
    //uint8_t maxWindow = 0;

    String name;
    unsigned char icon=' ';

    uint8_t possibleLayout;
    uint8_t currentLayout;
    
    Bank(String n, String value, StripFactory* sf){      
      name = n;
      for (size_t i = 0; i < BANK_MAX_STRIPS; ++i) strips.push_back(nullptr);
      stripFactory = sf;
      deserialize(value);
    }

    ~Bank(){
      DEBUG_PRINT("\n~Bank: %s",name.c_str());
      for (uint8_t i=0; i<BANK_MAX_STRIPS; i++){
        if (strips[i] != nullptr ) delete strips[i];
      }      
    }

    void init(){
      //set stripIndex to the first busy strip
      for (stripIndex=0; stripIndex<BANK_MAX_STRIPS; stripIndex++){
        if (strips[stripIndex] != nullptr ) break;
      }
      //DEBUG_PRINT("\n%s stripIndex:%i",name.c_str(),stripIndex);
      selector = stripIndex % STRIP_PER_WINDOW;
    }

    uint8_t getMaxWindow(){
      //determine how many strips are in use ... means if there are free strip,in between (value nullptr) we skip but as soon as we found one not 0 we set it to the current index
      uint8_t numberOfBusyStrip = 0;
      //DEBUG_PRINT("\n%s numberOfBusySlot=",name.c_str());
      for (uint8_t i = 0; i < BANK_MAX_STRIPS; i++) {
        if (strips[i] != nullptr) {
          numberOfBusyStrip = i;
          //DEBUG_PRINT(" %i",numberOfBusyStrip);
        }
      }
      uint8_t newMaxWindow = numberOfBusyStrip / STRIP_PER_WINDOW + 1;
      return newMaxWindow;
    }

    bool deserialize(String value){
      bool success = false;
      //DynamicJsonDocument bank(JSON_BANK_SIZE);
      JsonDocument bank;
      DeserializationError error = deserializeJson(bank, value);
      if (error){
        DEBUG_PRINT("\nBank <%s> deserialization error:%s",name.c_str(), error.f_str());
      }else{
        //DEBUG_PRINT("\n\nbank <%s>:<%s>",name.c_str(),value.c_str());

        possibleLayout = bank[C_POSSIBLELAYOUT];
        currentLayout = bank[C_CURRENTLAYOUT];
        icon = bank[C_ICON].as<unsigned char>();
        
        DEBUG_PRINT("\npossible layout:%i, currentLayout:%i, icon:%c",possibleLayout,currentLayout,icon);
        JsonArray stripArray = bank[C_STRIPS];
        for (int i=0; i<stripArray.size() && i<BANK_MAX_STRIPS; i++){        
          JsonObject jsonStrip = stripArray[i];        
          if (!setStrip(jsonStrip)) return false;
        }
        init();
        success = true;
      }
      return success;
    }

    bool insertStrip(JsonObject jsonStrip){

    }

    Strip* buildStrip(JsonObject jsonStrip){      
      String stripID = jsonStrip[C_STRIPTYPE];
      uint8_t index = jsonStrip[C_INDEX];
      Strip* strip = stripFactory->build(stripID);  // build the strip by passing values to deserialize
      return strip;
    }

    bool setStrip(JsonObject jsonStrip){
      Strip* strip = buildStrip(jsonStrip);
      String jsonStripString;
      serializeJson(jsonStrip, jsonStripString); 
      DEBUG_PRINT("\n\t\t=============>%s",jsonStripString.c_str());
      if (strip != nullptr){            
        if (strip->deserialize(jsonStripString)){
          trash(strip->index); // existing strip is deleted
          add(strip,strip->index);
          return true;
        }  
      }

      return false;
    }

    void add(Strip* strip, uint8_t index){
      if (index<BANK_MAX_STRIPS){
        numberOfStrips++;
        strips[index] = strip;
      }
    }

    Strip* get(uint8_t index){
      if (index<BANK_MAX_STRIPS) return strips[index];
      else return nullptr;
    }

    void trash(uint8_t index){
      if (strips[index] != nullptr){
        DEBUG_PRINT("\ntrashStrip: %s,index:%d",name.c_str(),index);        
        numberOfStrips--;
        delete strips[index];
        strips[index] = nullptr;
      }
    }

    String serialize(){
      //DynamicJsonDocument doc(JSON_STRIP_TEMPLATE_SIZE*BANK_MAX_STRIPS);   
      JsonDocument doc;
      //DEBUG_PRINT("\nserialize %s=>",name.c_str());

      doc[C_POSSIBLELAYOUT] = possibleLayout;
      doc[C_CURRENTLAYOUT] = currentLayout;
      doc[C_ICON] = icon;

      //JsonArray jsonStrips = doc.createNestedArray(C_STRIPS);            
      JsonArray jsonStrips = doc[C_STRIPS].to<JsonArray>();            
      for (uint8_t i = 0; i<BANK_MAX_STRIPS; i++){
        if (strips[i] != nullptr){
          jsonStrips.add(strips[i]->serialize());
        }
      }
      String data;
      serializeJson(doc, data);
      removeJsonQuote(&data);
      //DEBUG_PRINT("\n\tbank->serialze: <%s>\n",data.c_str());
      return data;
    }

  private:
    StripFactory* stripFactory;
    std::vector<Strip*> strips;

};

class BankNavigationBar: public Widget{
  //#define BANK_NAME_SIZE TFT_WIDTH/15
  public:

    BankNavigationBar(Bank* bank/*, LinkedList<Widget*>* w*/, bool debug):Widget(&xPos, &yPos, &fC, &bC, debug){      
      bank = bank;
      //widgetList = w;
      oldIndex = bank->stripIndex - 1; //this is to force first refresh
      width = TFT_WIDTH/2; height = OVERLAY_ICON_SIZE;
    }

    virtual bool refresh(bool force=false){
      refreshed = force;
      Widget::refresh(force);

      if (bank->stripIndex != oldIndex || bank->numberOfStrips != oldNumberOfStrips || id != bank->name){
        oldNumberOfStrips = bank->numberOfStrips;

        if (debug) DEBUG_PRINT("\n\t bank <%s> changed index: <%i>",id.c_str(),bank->stripIndex);        
        refreshed = true;
        oldIndex = bank->stripIndex;

        String navigator="";
        //refresh the navigator bar
        for (uint8_t i = 0; i<BANK_MAX_STRIPS; i++){
          if (bank->get(i) !=nullptr){
            if (i == bank->stripIndex) navigator += ICON_CHECKED; //"K";
            else{
              //navigator += String(bank->get(i)->skeleton->icon); // bank->get(i)->icon;
              navigator += ICON_EMPTY;
              if (debug) DEBUG_PRINT("\nstrip icon: <%c>", bank->get(i)->skeleton->icon);
            }
          }
        }
        navigator += " "; // separator
        id = bank->name;

        // strip navigator
        Icon* icons = new Icon(&navigator,Align::Center,&GUI::zero,&GUI::zero,OVERLAY_ICON_SIZE/1.2,&GUI::gold,&bC,debug);
        icons->refresh(true);
        width = icons->width;        

        //bank name
        Label* label = new Label(&bank->name,Align::Center,&GUI::zero,&GUI::zero,OVERLAY_ICON_SIZE*2,&fC,&bC,debug);
        label->refresh(true);

        width += label->width;
        height = max(label->height,icons->height);
        width = max(width,oldWidth);
        oldWidth = width;

        createSprite();  

        icons->sprite->pushToSprite(sprite,0,2);
        delete icons;
        label->sprite->pushToSprite(sprite,icons->width,-OVERLAY_ICON_SIZE/3);    
        delete label;           

      }

      return refreshed;
    }
    
    virtual void setText(const String* text){

    }  

    virtual int16_t getX(){
      return xPos-(width/2);
    }

  protected:
    Bank* bank;
    //LinkedList<Widget*>* widgetList;
    uint8_t oldIndex, oldNumberOfStrips = 0;    
    uint16_t oldWidth=0;

    int16_t xPos = TFT_WIDTH/2, yPos = TFT_HEIGHT-OVERLAY_ICON_SIZE;
    uint16_t fC = GUI::defaultFcolor, bC = GUI::defaultBcolor;

};

///////////////////// JSON AND SERIALIZATION  ////////////////////////

class JsonListFile : public JsonList{
  public:
      String filename;

      JsonListFile():JsonList(){};

      bool load(String f,String defaultValues=""){
        //DEBUG_PRINT("\nload(%s,<%s>) ",f.c_str(),defaultValues.c_str());
        // We first clean up existing values
        /*while (keyValues.size()>0){
          //DEBUG_PRINT("\nremaining to unstack: %i",gui->screenGUIs.size());
          KeyValue* kv = keyValues.shift();
          //DEBUG_PRINT("\nobject: %s ",widget->id.c_str());
          delete(kv);
        }*/
        bool success = false;

        if (defaultValues != "") deserialize(defaultValues);

        filename = f;
        // we try to allocate maximum memory and keep 20K free for security
        //DynamicJsonDocument doc(getMaxAlloc());
        JsonDocument doc;

        if (!LittleFS.exists(filename)){
          DEBUG_PRINT("\nfile: %s invalid, skipping by using default parameters",filename.c_str());          
        }else{
          File file = LittleFS.open(filename);
          DeserializationError error = deserializeJson(doc, file);      
          if (!error){
            jsonToKeyValues(&doc);
            success = true;
          }else{
            DEBUG_PRINT("\nJson error %s:%s",error.c_str(),filename.c_str());
          }
          doc.shrinkToFit();   
          DEBUG_PRINT("\nloaded %s", filename.c_str());     
        }
        return success;      
      }

      bool save(String f=""){
        bool success = true;
        if (f !="") filename = f;
        String s;
        serialize(&s);

        File file = LittleFS.open(filename, FILE_WRITE);
        if(!file){
            DEBUG_PRINT("\nfailed to open %s for writing",filename.c_str());
            success = false;
        }
        if(!file.print(s)){
            DEBUG_PRINT("\n %s write fail",filename.c_str());
            success = false;
        }else{
          //DEBUG_PRINT("\n saved: %s",s.c_str());
        }
        file.close();  
        return success;
      }
};

class Config : public JsonListFile{
  public:
    Config():JsonListFile(){}  

    const int getInt(String name) {
      return getString(name)->toInt();
    };
    const float getFloat(String name) {
      return getString(name)->toFloat();
    };
    const boolean getBool(String name) {
      return (*getString(name) != "0");
    };

};

class I18n : public JsonListFile{
  public:
    I18n():JsonListFile(){}

    virtual const String* getString(const String name, const String defaultValue="") {
      int8_t index;
      index = getIndex(String(name));
      if (index < 0) {
        //DEBUG_PRINT("\ntoken: %s do not exist, creating it.",name.c_str());
        addValue(name,name);  // if it doesnt exist we create it in the list
        return getString(name);
      } else {
        
        KeyValue* kv = keyValues.get(index);  
        //DEBUG_PRINT("\ntoken: %s = %s",name.c_str(),kv->value.c_str());      
        return &kv->value;
      }
    };
};

///////////////////// MAIN APPLICATION CLASS ////////////////////////

enum{
  MENU_ICON_MIDDLE,
  MENU_LABEL_TITLE,
  CONFIG_TEXTAREA_MESSAGE,
  BANK_SINGLEWIDGET,
  CONFIG_CONNECTWEBAPP,
  NUMBER_OF_WIDGETS
};

class ApplicationManager : public GenericComponent,MenuComponentRenderer{
  public:    
    ///////////////////// USER CALLBACKS ////////////////////////////////////////////////////
    ParseJsonInputCallback userParseJsonInputCallback = defaultParseJsonInputCallback;
    NetworkChangeStateCallback userNetworkChangeStateCallback = defaultNetworkChangeStateCallback;
    WizardScreenBuilderCallback userWizardScreenBuilder = defaultWizardScreenBuilder;
    WizardSstepFlowCallback userWizardstepFlow = defaultWizardStepFlow;
    ///////////////////// STRIPS & BANKS CONTAINERS AND DEFINITION ////////////////////////
    LinkedList<Bank*> banks = LinkedList<Bank*>(); 
    StripFactory stripFactory;
    DataRepository dataRepository;
    
    #define ADDRESS_SIMPLETEXT "/text/%s"
    DataSet simpleText={.address = ADDRESS_SIMPLETEXT,.object=INPUTTEXT,.values = {""}};
    
    ///////////////////// OVERLAY ICONS ////////////////////////
    String networkIcon, apIcon;
    uint16_t networkIconColor = TFT_RED, apIconColor = TFT_RED, batIconColor = TFT_GREEN, utils1Icon1Color = GUI::menuActiveIconColor;   

    String batteryIcons[BAT_MAX_LEVEL]={ICON_BAT_LEVEL_0,ICON_BAT_LEVEL_1,ICON_BAT_LEVEL_2,ICON_BAT_LEVEL_3};
    String batIcon = ICON_WAIT; // by default we display a timeelapser while battery level is undetermined
    String* byeIcon; const uint16_t* byeIconColor = &GUI::defaultFcolor; 
    String iconReset = ICON_RESET;
    String iconForbid = ICON_FORBID;
    String powerIcon = ICON_POWER; 

    AlteredColor networkIconGlowingRedColor = AlteredColor{.baseColor = GUI::red, .value =  &GUI::unUsedColor};
    AlteredColor apIconGlowingRedColor = AlteredColor{.baseColor = GUI::red, .value =  &GUI::unUsedColor};
    AlteredColor configIconGlowingRedColor = AlteredColor{.baseColor = GUI::red, .value =  &GUI::unUsedColor};

    
    int16_t overlayIconY = TFT_HEIGHT-OVERLAY_ICON_SIZE, apIconPosX = TFT_WIDTH-OVERLAY_ICON_SIZE*2;
    int16_t batIconPosX = TFT_WIDTH-OVERLAY_ICON_SIZE;

    ///////////////////// WIDGETS & ATTRIBUTES ////////////////////////
    #define WIDGET_SMALL_WIDTH TFT_WIDTH/8-5
    #define WIDGET_BIG_WIDTH TFT_WIDTH/5
    #define ICON_MAX_SIZE TFT_WIDTH/2

    int16_t belowTop = 10, midScreenHoriz = TFT_WIDTH/2, rightScreen = TFT_WIDTH, midScreenVertical = TFT_HEIGHT/2, bigWidgetMidY = midScreenVertical-WIDGET_BIG_WIDTH/2, iconMidY = midScreenVertical-ICON_MAX_SIZE/2 ;

    uint16_t rainbowC;
    AlteredColor rainbowColor = AlteredColor{.baseColor = TFT_WHITE, .value = &rainbowC};
    Widget* widgets[NUMBER_OF_WIDGETS]; 

    #define TFT_QUARTER TFT_WIDTH/4
    int16_t quarter1xPos = TFT_QUARTER-TFT_QUARTER/2;
    int16_t quarter2xPos = TFT_QUARTER*2-TFT_QUARTER/2;
    int16_t quarter3xPos = TFT_QUARTER*3-TFT_QUARTER/2;
    int16_t quarter4xPos = TFT_QUARTER*4-TFT_QUARTER/2;

    #define TFT_THIRD TFT_WIDTH/3
    int16_t third3xPos = TFT_THIRD*2+TFT_QUARTER/2;

    String utils1Icon1,utils1Icon2;

    ///////////////////// MENU SYSTEM ATTRIBUTES AND MESSAGE ////////////////////////
    #define MENU_ICON_SIZE TFT_WIDTH/3
    #define MENU_TITLE_SIZE MENU_ICON_SIZE/2
    #define CONFIG_TEXTAREA_MESSAGE_SIZE MENU_TITLE_SIZE/1.8

    MenuSystem ms = MenuSystem(*this);
    MenuSystem* bankMenu = nullptr;
    MenuSystem* wizardMenu = nullptr;

    Menu* langMenu = nullptr;
    Menu* confMenu = nullptr;  
    String topLabelItem=" ", vBatLabel; //menuTitle
    String menuItemIcon[3]={"","",""}; // left, mid, right
    String bottomLabelTitle=" ";

    uint16_t menuActiveIconColor;

    int16_t menuIconYpos = TFT_HEIGHT/2-MENU_ICON_SIZE/2.2, leftMenuIconXpos = midScreenHoriz-MENU_ICON_SIZE*1.4,rightMenuIconXpos = midScreenHoriz+MENU_ICON_SIZE*1.4;
    int16_t menuTitleY = TFT_HEIGHT-MENU_TITLE_SIZE*1.2, belowMenuIcon = menuIconYpos+MENU_ICON_SIZE;

    #define ICON_DOT_MAX 4
    String iconDot[ICON_DOT_MAX]={
      ICON_LEFTDOT+String(ICON_NODOT),
      ICON_RIGHTDOT+String(ICON_NODOT),
      ICON_NODOT+String(ICON_LEFTDOT),
      ICON_NODOT+String(ICON_RIGHTDOT),
    };
    String iconPending[2];

    const char* quitMenuString ={ICON_QUIT":QUIT"};
    const char* infoMenuString ={ICON_INFO":INFO"};
    const char* configMenuString ={ICON_CONFIG":CONFIGURATION"};
    const char* profileMenuString ={ICON_PROFILES":PROFILE"};
    const char* saveMenuString ={ICON_SAVE":SAVE"};
    const char* langMenuString ={ICON_LANG":LANGUAGE"};
    const char* tftRotationMenuScreen{ICON_TFT_ROTATE":ROTATE"};
    const char* resetMenuScreen{ICON_RESET":RESET"};
    const char* shutdownMenuString{ICON_POWER":OFF"};
    

    ///////////////////// UTILITIES ATTRIBUTES ////////////////////////
    I18n lang = I18n();
    Config config = Config();
    Config system = Config();
    Preferences persistants;

    unsigned long goSleepCountdownStart;

    bool webAppConnected;

    String configClientIP; // ip of the client connect to the AP during configuration    

    ApplicationManager(HardwareManager* h, GUIManager* g, bool debug=true):GenericComponent(debug){
      hwm = h;
      gui = g;
      id = "ApplicationManager";

      stripTextSkel = new StripSkeleton(STRIP_TEXT,STRIP_DEFAULT_GROUP,textStripConstructorCallback,'*');
      dataRepository.addDataSet(&simpleText);
      stripTextSkel->registerDataSetAddress(ADDRESS_SIMPLETEXT);
    }

    bool getButtonState(uint8_t B){
      return hwm->buttons[B]->refreshed;
    }

    void setBatIcon(){
      batIconColor = TFT_GREEN;
      switch(hwm->battery.batteryState){
        case BAT_CHARGING:
          batIcon = ICON_PLUG; //ICON_BAT_CHARGING
        break;
        case BAT_DISCHARGING:
        {
          uint8_t vBatIconIndex = hwm->battery.indicator;
          batIcon = batteryIcons[vBatIconIndex];      
          //if (debug) DEBUG_PRINT("\nIcon index: %i icon:%s",vBatIconIndex,batIcon.c_str());
          if (vBatIconIndex == 0 && hwm->battery.vBat < VBAT_WARNING) batIconColor = TFT_RED; 
        }break;
        case BAT_CHECKING:
        default:
          batIcon = ICON_WAIT;
        break;  
      }
      vBatLabel = *lang.getString("Battery")+": "+String(hwm->battery.vBat)+"v";
    }

    void setAPandNetIcons(){
      setAPIcon();
      setNetworkIcon();
    }

    void setAPIcon(){
      if (hwm->ap == nullptr){
        apIcon = emptyString;
      }else{
        apIcon = ICON_AP;
        if (hwm->ap->state == CONNECTED){
          apIconGlowingRedColor.value = &GUI::unUsedColor;
          apIconColor = GUI::green;
        }else{
          apIconGlowingRedColor.value = &apIconColor;
        }
      }
    }

    void setNetworkIcon(){

      #ifdef USE_NETWORK
              
        if (hwm->network->state == CONNECTED){
          if (hwm->network->media == WIFI_MEDIA) refreshWiFiSignalIcon();
          else networkIcon = ICON_ETH;
          networkIconGlowingRedColor.value = &GUI::unUsedColor;
          networkIconColor = GUI::green;
        }else{
          networkIconGlowingRedColor.value = &networkIconColor;
          //DEBUG_PRINT("\n setNetworkIcon ********************************");
          if (hwm->network->ethEnabled && hwm->network->WiFiEnabled && hwm->network->getLink() == LinkOFF) networkIcon = ICON_MIXETHWIFI; // both WiFi and ETh are up but there is no cable on, we don't know who will connect first
          else if ((hwm->network->ethEnabled && !hwm->network->WiFiEnabled) || (hwm->network->getLink() == LinkON)) networkIcon = ICON_ETH;  //case when we wait for a DHCP lease or have no WiFi enabled
          else if (!hwm->network->ethEnabled && hwm->network->WiFiEnabled) networkIcon = ICON_WIFI_STRENGTH_3; 
          else networkIcon = emptyString;  // when it is only wifi and ap is launched.
        }

      #else
        networkIcon = emptyString;
      #endif

    }

    void gotoWizardEnd(){
      screen.id = SCREEN_WIZARD; screen.state = STATE_WIZARD_END_STEP4;
      persistants.putUChar(PERSISTANT_SCREEN_ID,SCREEN_BANK);
    }

    void goToResetScreenAndSleep(String message){
      clearConfig();
      topLabelItem = *lang.getString(message);
      bottomLabelTitle = emptyString;
      byeIcon = &iconReset; byeIconColor = &GUI::red;
      goSleepCountdownStart = millis();          
      screen.id = SCREEN_BYE; screen.state = STATE_BYE_GOSLEEP_MESSAGE;         //we could create a screen dedicated for reset         
    }

    void goToBigBatteryIconScreenAndSleep(){
      byeIcon = &batIcon; byeIconColor = &batIconColor;
      screen.id = SCREEN_BYE;
      screen.state = STATE_BYE_GOSLEEP_MESSAGE;       
    }

    Bank* deserializeBanks(const String* bankJsonString){
      Bank* bank = nullptr;
      uint8_t numberOfBanks = countWord(*bankJsonString,C_STRIPS);
      if (numberOfBanks>0){
        
        int memAlloc = JSON_BANK_SIZE * numberOfBanks;
        DEBUG_PRINT("\nCreating banks from: <%s>\n[%d]\nbanks memalloc: %i",bankJsonString->c_str(),numberOfBanks,memAlloc);
        //DynamicJsonDocument jsonBanks(memAlloc);          
        JsonDocument jsonBanks;
        
        DeserializationError error = deserializeJson(jsonBanks, *bankJsonString);
        if (error){
          DEBUG_PRINT("\nBank deserialization error:%s",error.f_str());
        }else{              
          JsonObject root = jsonBanks.as<JsonObject>();      
          for (JsonPair kv : root) {
            DEBUG_PRINT("\n%s = %s",kv.key().c_str(),kv.value().as<String>().c_str());          
            bank = new Bank(kv.key().c_str(),kv.value().as<String>(),&stripFactory);
            if (bank->numberOfStrips>0) banks.add(bank);
            else delete bank; // bank has no strips and is threfore invalid
          }
          hookBankToMenu();
        }
      }
      if (banks.size()>0) return banks.get(banks.size() - 1); // return the last bank
      else return nullptr;
    }


    void applySystemSettings(){
      // this function applies all settings from the system conf file
      wiFiList.deserialize(*system.getString(S_SSID));
      hwm->setWiFi(&wiFiList,*system.getString(S_LAST_USED_SSID));
      DEBUG_PRINT("\n*system.getString(S_LAST_USED_SSID): %s",system.getString(S_LAST_USED_SSID)->c_str());
      hwm->setButtonReactivity(system.getInt(S_PUSHDELAY),system.getInt(S_DCLICREACTIVITY));     
      DEBUG_PRINT("\nS_PUSHDELAY: %s",String(system.getInt(S_PUSHDELAY)).c_str());
      String langFile = "/"+*system.getString(S_LANG,"ENGLISH")+".lang";
      lang.load(langFile); 
    }

    #define DEFAULT_CONFIG_FILE_NAME "default.conf"

    void applyConfigSettings(String param=VOID_JSON_ITEM){
      // this function applies all settings from the user conf file
      String profileFile = "/"+*system.getString(S_CONFIG_FILE,DEFAULT_CONFIG_FILE_NAME);
      param="{"+defaultUserConf+","+param+"}";
      config.load(profileFile,param);  
    }  

    #define SYSTEM_FILE_NAME "/settings.sys"
    void clearConfig(){
      // delete all config files here, add the code to iterate FS on *.conf
      LittleFS.remove(DEFAULT_CONFIG_FILE_NAME);
      // delete system settings
      LittleFS.remove(SYSTEM_FILE_NAME);
      persistants.clear();      
    }

    void init(String param=VOID_JSON_ITEM){
      GenericComponent::init();

      persistants.begin("interval", false);
      DEBUG_PRINT("\npersistants.begin()");

      if (!LittleFS.begin()){
        DEBUG_PRINT("\nFS BEGIN ISSUE");
      }

      system.load(SYSTEM_FILE_NAME,defaultSysConf);  

      applySystemSettings();
      applyConfigSettings(param);

      hwm->init();
      gui->init();         
      GUI::tft->setRotation(persistants.getUChar(PERSISTANT_TFT_ROTATION,1)); 

      if (debug){
        String s;
        system.serialize(&s);
        DEBUG_PRINT("\n\n serialization of system:\n%s",s.c_str());
        s="";
        config.serialize(&s);
        DEBUG_PRINT("\n\n serialization of config:\n%s",s.c_str());
        s="";
        lang.serialize(&s);
        DEBUG_PRINT("\n\n serialization of langfile:\n%s",s.c_str());        
        //DEBUG_PRINT("\nexample of langfile token: Connect:%s",lang.getString("Connect")->c_str());        
      }

      for (uint8_t i=0;i<SCREEN_MAX;i++) screenBuilders.add(&screens[i]);
            
      for (uint8_t i=0;i<MAXB;i++){
        hwm->buttons[i]->setCallBack(SIMPLE_CLIC,simpleClicCallBack);
        hwm->buttons[i]->setCallBack(DOUBLE_CLIC,doubleClicCallBack);
        hwm->buttons[i]->setCallBack(LONG_CLIC,longClicCallBack);
        hwm->buttons[i]->setCallBack(HOLD,holdCallback);
        hwm->buttons[i]->setCallBack(RELEASE_HOLD,releaseHoldCallback);
      }

      hwm->onOff.setCallBack(LONG_CLIC,menuSwitchCallback);
      hwm->onOff.setCallBack(SIMPLE_CLIC,simpleClicCallBack);

      back_menu_item = new MenuItem(quitMenuString, &back_menu_item_selected);
      info_menu_item = new MenuItem(infoMenuString, &info_item_selected);
      config_menu_item = new MenuItem(configMenuString,&config_menu_item_selected);
      profile_menu_item = new Menu(profileMenuString,&menu_selected);
      save_profile_menu_item = new MenuItem(saveMenuString,&save_profile_item_selected);
      tft_rotation_menu_item = new MenuItem(tftRotationMenuScreen,&tft_rotation_item_selected);
      reset_menu_item = new MenuItem(resetMenuScreen,&reset_item_selected);                // to be removed
      shutdown_menu_item = new MenuItem(shutdownMenuString, &shutdown_menu_item_selected);

      ms.get_root_menu().add_item(shutdown_menu_item);
      ms.get_root_menu().add_item(back_menu_item);
      ms.get_root_menu().add_item(info_menu_item);
      ms.get_root_menu().add_item(config_menu_item);       
      ms.get_root_menu().add_item(tft_rotation_menu_item);       
      ms.get_root_menu().add_item(reset_menu_item);       
      ms.get_root_menu().add_menu(profile_menu_item);
      profile_menu_item->add_item(back_menu_item);
      profile_menu_item->add_item(save_profile_menu_item);
      

      hookLangToMenu();
      
      //quarter1xPos = 

      // glowing colors declarations
      //gui->glowingColors.add(&glowingGoldColor);
      GUI::glowingGoldColor.value = &menuActiveIconColor;
      gui->alphaColors.add(&GUI::glowingGoldColor);      
            
      gui->alphaColors.add(&networkIconGlowingRedColor);
      gui->alphaColors.add(&apIconGlowingRedColor);
      gui->alphaColors.add(&configIconGlowingRedColor);

      gui->rainbowColors.add(&rainbowColor);
      gui->alphaColors.add(&rainbowColor);

      minHeapSize = maxHeapSize = ESP.getFreeHeap();

      setAPandNetIcons();
      setBatIcon();     

      // BY DEFAULT, WE DO NOT STARTUP, ONLY DISPLAY BATTERY LEVEL AND SWITCH OFF                 

      switch(hwm->startupState){
        case RESET_STARTUP:
          // put reset code here
          goToResetScreenAndSleep("RESET");
          enableWizard();
        break;
        case BATTERY_STARTUP:
          topLabelItem = *lang.getString("Press >1s to startup"); bottomLabelTitle = emptyString;
          goSleepCountdownStart = hwm->bootTime;
          goToBigBatteryIconScreenAndSleep();         
        break;
        case WIZARD_STARTUP:
          enableWizard();
          // no break, we continue normal startup
        case NORMAL_STARTUP:
          // perform all application initialization
          DEBUG_PRINT("\n\n\n********");
          if (deserializeBanks(config.getString(C_BANKS)) == nullptr){
            topLabelItem = *lang.getString("Bank creation");
            bottomLabelTitle = emptyString;
            byeIconColor = &GUI::red; byeIcon = &iconForbid;
            screen.id = SCREEN_BYE; screen.state = STATE_BYE_MODAL_MESSAGE;
            DEBUG_PRINT("\n\n\n*********************** COULD NOT CREATE BANK");
          }else{
            resetToBankScreen();
          }
        break;
      }
    }

    void resetToBankScreen(){
      screen.id = persistants.getUChar(PERSISTANT_SCREEN_ID,SCREEN_BANK);; //screen.id = SCREEN_BANK;        
      screen.state = persistants.getUChar(PERSISTANT_SCREEN_STATE,0);
      //screen.state is bank ID;
      if (screen.id == SCREEN_BANK && screen.state > banks.size()-1){
        screen.state = 0; // prevents branching a bank which is not existing anymore
        screen.state = persistants.putUChar(PERSISTANT_SCREEN_STATE,screen.state);              
      }
      oldScreen.value = screen.value - 1;      
    }

    void refreshWiFiSignalIcon(){
      int8_t signalStrength = abs(WiFi.RSSI());
      if (signalStrength >=90) networkIcon = ICON_WIFI_STRENGTH_0;
      else if (signalStrength >=75) networkIcon = ICON_WIFI_STRENGTH_1;
      else if (signalStrength >=45) networkIcon = ICON_WIFI_STRENGTH_2;
      else networkIcon = ICON_WIFI_STRENGTH_3;      
      //DEBUG_PRINT("\nrssi: %d",signalStrength);
    }

    void serialize(String* returnedJsonStringData){
      //DynamicJsonDocument doc(getMaxAlloc()); // the whole config file is about 11k according to json assistant
      JsonDocument doc;
      
      String tempJsonString;

      system.serialize(&tempJsonString);  
      doc["system"]=tempJsonString;
      DEBUG_PRINT("\n>>>>>>>>>>>>>-----IS OK-------> %s",tempJsonString.c_str() );

      doc["volatile"]["langs"][0] = "francais"; doc["volatile"]["langs"][1] = "english"; 
     
      JsonArray skel = doc["skeletons"].to<JsonArray>();
      stripFactory.serialize(&skel);

      JsonArray ds = doc["datasets"].to<JsonArray>();  
      dataRepository.serialize(&ds);         

      JsonDocument bankDoc;
      //DynamicJsonDocument bankDoc(10000); 
      for (uint8_t i=0; i<banks.size(); i++){
        //DynamicJsonDocument jsonBank(JSON_BANK_SIZE); 
        JsonDocument jsonBank;
        Bank* bank = banks.get(i);
        String stringBank = bank->serialize();
        DeserializationError error = deserializeJson(jsonBank, stringBank);
        if (error){
          DEBUG_PRINT("\nBank <%s> deserialization error:%s",bank->name.c_str(),error.f_str());
        }else{
          bankDoc[bank->name] = jsonBank;
        }       
      }
      //DEBUG_PRINT("\n\nmodDoc: %s\n\n",bankDoc.as<String>().c_str());
      config.setValue(C_BANKS,bankDoc.as<String>());

      tempJsonString = "";
      config.serialize(&tempJsonString);
      doc["config"]=tempJsonString;
    
      serializeJson(doc, *returnedJsonStringData);  
      removeJsonQuote(returnedJsonStringData);
    }

    void restoreScreen(){
      screen.id = persistants.getUChar(PERSISTANT_SCREEN_ID,SCREEN_BANK);
      screen.state = persistants.getUChar(PERSISTANT_SCREEN_STATE,0);    
    }

    void restoreMenu(){
      screen.id = SCREEN_MENU;
    }

    String getIconFromString(const char* item){
      return String((char)item[0]);
    }

    String getNameFromString(const char* item){
      return String(item).substring(2);
    } 

    void buildLangMenu(){
      if (langMenu != nullptr) delete langMenu;
      langMenu = new Menu(langMenuString,menu_selected); 

      populateFileList("lang","/",&countryList,String(ICON_LANG)+"-",false);     // this populate the list of countries with the icon (prefix = k-) and without extension

      // populate the menu with all language found      
      for(int i = 0; i < countryList.size(); i++){
        const char* countryIconAndName = countryList.get(i)->c_str();
        langMenu->add_item(new MenuItem(countryIconAndName, loadLangFromMenu_item_selected));                
        if (debug){
          //DEBUG_PRINT("\nadded menu entry: %s",countryList.get(i)->c_str());           
        }
      }      
    }

    void hookLangToMenu(){
      buildLangMenu();
      langMenu->add_item(back_menu_item);
      ms.get_root_menu().add_menu(langMenu);              
    }
    

    bool refresh(bool force=false){
      yield();
      
      refreshed = force;

      //------------------
      //
      // MANAGE NETWORK
      //
      //------------------     
      hwm->refresh();      

      if (hwm->network->refreshed){ // network changed its status
        
        setNetworkIcon();

        // inform all that network has changed (it could be the network cable pluged/unplug while in AP)
        broadCast(parseJsonInput("{\"command\":\"retrieve\",\"param\":\"connectivityConfig\"}"));  // inform webclient               could be done via ws.send as well
        // ============>>> CALLBACK APPLICATION
        userNetworkChangeStateCallback(hwm->network->state);

        if (hwm->network->state == CONNECTED){         
          // network has refreshed so we shift to appropriate configMedia
          if (hwm->network->media == WIFI_MEDIA){
            //we set last used Wifi SSID (id) and save config, hence keep WIFI_MEDIA credential
            DEBUG_PRINT("\n------> SAVING SSID");
            system.setValue(S_LAST_USED_SSID,hwm->network->SSID);
            system.save(); 
            /* add this to the possible SSID "ssid": {
            "intervalmix": "intervalpop74",
            "infrafast": "Mf9k8iie2",
            "ssid3": "pass3"
            */
          }
          
          if (!webAppConnected){
            // there is no connection to any application, therefore, we prefer to use the network as the one to configure the application
            if (debug) DEBUG_PRINT("\n\tsetting the configMedia to WiFiEth");
            hwm->configMedia = hwm->network;    // since the normal network gets reconnected,

          }else{

          }
        }else{
          // we disconnected , so we give back the priority on the WiFI connection list to  the last connected WiFi 
          //hwm->setWiFi(&wiFiList,*system.getString(S_LAST_USED_SSID)); 
        }
      }  

      if (hwm->ap != nullptr){
        if (hwm->ap->refreshed) setAPandNetIcons();
      }

      // real time signal strength display
      if (hwm->network->state == CONNECTED && hwm->network->media == WIFI_MEDIA) refreshWiFiSignalIcon();

      //------------------
      //
      // MANAGE WEB APPLICATION
      //
      //------------------  

      if (hwm->configMedia->state == CONNECTED){    
        if(webAppOn){          

          if (hwm->configMedia->refreshed) setWSServer();   // the network has refreshed (could be media, IP...) hence we rebuild the WSS
          
          wss->listen();  //sockets      
          
          if (hwm->configMedia->media == CABLE_MEDIA){
            EthernetClient newEthClient = ((EthernetServer*)hwm->configMedia->server)->available();            
            if (newEthClient.connected()) {
              if (debug) DEBUG_PRINT("\nWebapp connected eth");
              webServer->process(&newEthClient);
              newEthClient.stop();
            }            
          }else{
            WiFiClient newWiFiClient = ((WiFiServer *)hwm->configMedia->server)->available();
            if (newWiFiClient.connected()) {
              if (debug) DEBUG_PRINT("\nWebapp connected wifi");
              webServer->process(&newWiFiClient);
              newWiFiClient.stop();
            }   
          }
        }
      }else{
        //if (hwm->configMedia->refreshed) 
        webAppConnected = false;
      }
      
      // BATTERY LEVEL CHECK
      if (hwm->battery.refreshed){        
        setBatIcon();
        if (hwm->battery.vBat<VBAT_CRIT && hwm->battery.batteryState != BAT_CHARGING){
          topLabelItem = *lang.getString("Low Battery");
          bottomLabelTitle = emptyString;
          goSleepCountdownStart = millis();
          goToBigBatteryIconScreenAndSleep();
        }          
      }
   

      //------------------
      //
      // MANAGE GUI OBJECT
      //
      //------------------
      if (screen.value != oldScreen.value){
        refreshed = true;
        // we changed the screen, therefore we rebuild the screen
        // first we acknowledge the update so it is not done te next round
        if (debug) DEBUG_PRINT("\n%s changed from screen.id:%i.state:%i.focus:%i to screen.id:%i.state:%i.focus:%i",id.c_str(),oldScreen.id,oldScreen.state,oldScreen.focus, screen.id,screen.state,screen.focus);        
        // first clean up all component of the screen
        //for(int i = 0; i < gui->screenGUIs.size()-1; i++) delete(gui->screenGUIs.shift());
        while (gui->screenGUIs.size()>0){
          //DEBUG_PRINT("\nremaining to unstack: %i",gui->screenGUIs.size());
          Widget* widget = gui->screenGUIs.shift();
          //DEBUG_PRINT("\nobject: %s ",widget->id.c_str());
          delete(widget);
          widget = nullptr;
        }
        //gui->screenGUIs.clear();

        // then retrive the screen builder and its overlay by ID           
        for(int i = 0; i < screenBuilders.size(); i++){
          screenBuilder* builder = screenBuilders.get(i);
          if (builder->id == screen.id){
            builder->screenCallback(screen.state);
            builder->overlayCallback(screen.state);
            break;
          }
        }
        //#ifdef DEBUG
          // DEBUG INDICATORS OVERLAY
          gui->add(new Label(&gui->framePerSec,Align::Right, &rightScreen, &GUI::zero,TFT_WIDTH/16,&GUI::defaultFcolor,&GUI::defaultBcolor,false));    
          gui->add(new Label(&heapSize,Align::Left,&GUI::zero,&GUI::zero,TFT_WIDTH/16,&GUI::defaultFcolor,&GUI::defaultBcolor,false));              
        //#endif

        //DEBUG_PRINT("\nnew screen widget size: %i",gui->screenGUIs.size());
        if (gui->transparency) gui->clearScreenBuffer();
        oldScreen.value = screen.value;      
        // these are the only screens that can be recall after startup
      }
      gui->refresh(force);

      //------------------
      //
      // MANAGE APPLICATION FLOW
      //
      //------------------

      switch(screen.id){
        case SCREEN_WIZARD:
          switch (screen.state){
            case STATE_WIZARD_LANG_STEP1:{
              // we branch to the lang menu
              ms.reset();             
              for (int i = 0; i < ms.get_root_menu().get_num_components(); ++i) {
                const MenuComponent* m = ms.get_current_menu()->get_current_component();
                if (strcmp(langMenuString,m->get_name())!=0) ms.next();
                else{ms.select();break;}
              }                       
              restoreMenu();
              screen.state = STATE_WIZARD_CONNECT_CONFIG_STEP2;
              persistants.putUChar(PERSISTANT_SCREEN_ID, SCREEN_WIZARD);    
              persistants.putUChar(PERSISTANT_SCREEN_STATE,STATE_WIZARD_CONNECT_CONFIG_STEP2);    
            }break;
            case STATE_WIZARD_CONNECT_CONFIG_STEP2:
              handleConfigConnection();
              persistants.putUChar(PERSISTANT_SCREEN_ID, SCREEN_WIZARD);    
              persistants.putUChar(PERSISTANT_SCREEN_STATE,STATE_WIZARD_USER_STEP3); 
            break;
            case STATE_WIZARD_USER_STEP3:
              if (!webAppConnected) screen.state = STATE_WIZARD_CONNECT_CONFIG_STEP2;
              userWizardstepFlow();
            break;
            case STATE_WIZARD_END_STEP4:
              resetToBankScreen();
            break;  
          }
        break;
        case SCREEN_UTILS:
          switch(screen.state){
            case STATE_UTILS_CONNECTCONFIGMEDIA:                            
              if (hwm->configMedia->refreshed){
                handleConfigConnection();                 
              } 
            break;
            case STATE_UTILS_CONNECTWEBAPP:              
              if (hwm->configMedia->refreshed){
                handleConfigConnection();
              }
              if (webAppConnected == true){ // when web app connect we go back to normal screen
                restoreScreen();    // go back to caller. can be from bank/menu or wizard
              }
            break;
            case STATE_UTILS_WEBAPPCONNECTED:
              if (hwm->configMedia->refreshed){
                handleConfigConnection();
              }              
            break;
          }
        break;
        case SCREEN_MENU:          
          if (refreshed) menuSystemFullRefresh(); 
        break;
        case SCREEN_BANK_SWITCH:          
          if (refreshed) menuSwitchBankFullRefresh(); 
        break;
        case SCREEN_BYE:
          switch(screen.state){ 
            case STATE_BYE_GOSLEEP_MESSAGE:
              if (millis()-goSleepCountdownStart>BAT_REFRESH_RATE*BAT_NUM_READINGS*2) goDeepSleep(); // we wait two full cycle of battery voltage acquisition before shuting down
            break;
            case STATE_BYE_MODAL_MESSAGE: 
              // we do not shutdown, we leave it on so we can go to the men for instance to perform some action like update or ftp ...            
            break;
          }
        break;
      }
      //------------------
      //
      // MANAGE DEBUGGING 
      //
      //------------------
      uint32_t mem = ESP.getFreeHeap();
      if (mem>maxHeapSize) maxHeapSize = mem;
      if (mem<minHeapSize) minHeapSize = mem;
      heapSize = String(minHeapSize)+"/"+String(mem)+"/"+String(maxHeapSize);

      return refreshed;
    }

    void broadCast(String msg){
        if (webAppConnected && hwm->configMedia->state == CONNECTED){
          wss->broadcast(WebSocketDataType::TEXT, msg.c_str(), msg.length());  
          DEBUG_PRINT("\n\n\t\t\t * * * * broadCast(%s) * * * ",msg.c_str());
        }
    }

    void reset(){      
      nvs_flash_erase(); // erase the NVS partition and...
      nvs_flash_init(); // initialize the NVS partition.        
      // next: delete conf file   
    }

    void setWSServer(){
      if (wss != nullptr){
        //wss->shutdown();  // need the patch here: https://github.com/skaarj1989/mWebSockets/discussions/67#
        delete wss; 
      }
   
      if (hwm->configMedia->media == CABLE_MEDIA) wss = new EthernetWebSocketServer{};
      else wss = new WiFiWebSocketServer{};

      wss->onConnection(socketConnectionCallback);    
      wss->begin();

    }

    bool startWebApp(){
      webAppOn = false;
      if (hwm->configMedia != nullptr){
        if (!webAppOn && hwm->configMedia->state == CONNECTED){          
          //start webserver
          if (webServer != nullptr) delete webServer;
          webServer = new Application();
          // inventory zipped file
          populateFileList("gz","/webapp",&webGZFiles,"/",false);    
          for (uint8_t i=0;i<webGZFiles.size();i++){          
            webServer->get(webGZFiles.get(i)->c_str(), &gzFileServer);
            DEBUG_PRINT("\n ...... REGISTERING WEB GZ FILE: %s",webGZFiles.get(i)->c_str());
          }
          // any other file
          webServer->use(commonFileServerWrapper);
          setWSServer();
          webAppOn = true;
          hwm->configIP = hwm->configMedia->IP.toString();
          /* Initialize mDNS => doesnt work for ethernet so we give up and keep IP address
          if (debug) DEBUG_PRINT("\nstarting mdns: %s",config.getString(S_AP_NAME)->c_str());
          if (!MDNS.begin(*config.getString(S_AP_NAME))) {   // Set the hostname to "esp32.local"
            if (debug) DEBUG_PRINT("Error setting up MDNS responder!");
          } */           
        }
      }
      return webAppOn;
    }
    
    #define MIME_TYPES_MAX 15
    /*void commonFileServer2(Request &req, Response &res){
      
      const char * path = req.path();
    
      String mimeTypes[MIME_TYPES_MAX][2] ={
        {"html",  "text/html"},
        {"js",    "application/javascript"},
        {"json",  "application/json"},
        {"jpeg",  "image/jpeg"},
        {"jpg",   "image/jpeg"},
        {"gif",   "image/gif"},
        {"png",   "image/png"},  
        {"txt",   "text/plain"},  
        {"htm",   "text/html"},
        {"xml",   "application/xml"},  
        {"css",   "text/css"},  
        {"gz",    "application/gzip"},  
        {"zip",   "application/zip"},
        {"ttf",   "font/ttf"},
        {"svg",   "image/svg+xml"}
      };
      String mimeType = mimeTypes[0][1];  //default to text/html
      for (uint8_t i=0;i<MIME_TYPES_MAX;i++){
        if (String(path).endsWith(mimeTypes[i][0])) mimeType = mimeTypes[i][1];
      }
      res.set("Content-Type", mimeType.c_str());

      Serial.printf("\n\tserving: %s <%s>",path, mimeType.c_str());
 
      File file;

      if (strcmp(path, "/") == 0) file = LittleFS.open("/webapp/indexnozip.html");
      else file = LittleFS.open("/webapp"+String(path));
      
      while (file.available()) res.write(file.read());      

      res.end();           
      file.close();
    }*/

    void commonFileServer(Request &req, Response &res){
      
      //if (req.method() != Request::GET) return;
      const char * path = req.path();

      if(strcmp(path, "/post/") == 0){ 
        httpPost(req,res);
      }else{
        if(strcmp(path, "/") == 0){
          path = "/index.html.gz"; //path = "/index.html";
          #ifdef USE_NETWORK
            if (persistants.getUChar(PERSISTANT_SCREEN_ID,SCREEN_BANK) == SCREEN_WIZARD) path = "/wizard.html.gz"; //path = "/wizard.html";
          #endif
        } 
        String filenameRealExtension = path;
        
        if (filenameRealExtension.endsWith(".gz")){
          filenameRealExtension.replace(".gz","");
          res.set("Content-Encoding", "gzip");
        }

        String fullPath = "/webapp"+String(path);   
        if (!LittleFS.exists(fullPath)){
          res.sendStatus(404);   //send(404, "text/plain", "Not found");    
          res.set("Content-Type", "text/html");
          res.print(fullPath.c_str());
          res.end();          
          return;
        }
        File file = LittleFS.open(fullPath);
        if (file.isDirectory()) return;
        
        String mimeTypes[MIME_TYPES_MAX][2] ={
          {"html",  "text/html"},
          {"js",    "application/javascript"},
          {"json",  "application/json"},
          {"jpeg",  "image/jpeg"},
          {"jpg",   "image/jpeg"},
          {"gif",   "image/gif"},
          {"png",   "image/png"},  
          {"txt",   "text/plain"},  
          {"htm",   "text/html"},
          {"xml",   "application/xml"},  
          {"css",   "text/css"},  
          {"gz",    "application/gzip"},  
          {"zip",   "application/zip"},
          {"ttf",   "font/ttf"},
          {"svg",   "image/svg+xml"}
        };
        String mimeType = mimeTypes[0][1];
        for (uint8_t i=0;i<MIME_TYPES_MAX;i++){
          if (filenameRealExtension.endsWith(mimeTypes[i][0])) mimeType = mimeTypes[i][1];
        }

        //if (debug) DEBUG_PRINT("\t\t\t\t REAL EXTENSION: \t\t\tt%s \t\t\tMIME:%s",filenameRealExtension.c_str(),mimeType.c_str());
        DEBUG_PRINT(" serving <%s> --------------------->%s",mimeType.c_str(), fullPath.c_str() );        
        res.set("Content-Type", mimeType.c_str());
        iconPending[0] = ICON_ROLLING1;
        iconPending[1] = ICON_ROLLING2;
        while (file.available()) res.write(file.read());
        res.end();
        file.close();        
      }
    }

    void render(Menu const& menu) const {}
    void render_menu_item(MenuItem const& menu_item) const {}
    void render_back_menu_item(BackMenuItem const& menu_item) const {}
    void render_numeric_menu_item(NumericMenuItem const& menu_item) const {}
    void render_menu(Menu const& menu) const {}  

    void menuSystemFullRefresh(){  
      //DEBUG_PRINT("\nmenuSystemFullRefresh");
      setRootMenuItems(&ms);
      //widgets[MENU_ICON_MIDDLE].widget->setFcolor(glowingGoldColor.value); // restore color
      GUI::glowingGoldColor.value = &menuActiveIconColor;
      widgets[CONFIG_TEXTAREA_MESSAGE]->setText(lang.getString(" ")); // empty message
    }

    void setRootMenuItems(MenuSystem* m){
      //ms.get_current_menu()->get_current_component(
      Menu const* menu = m->get_current_menu();
      uint8_t numItem = menu->get_num_components();  

      MenuComponent const* cp_m_comp;
      uint8_t selection = 0;

      cp_m_comp = menu->get_current_component();
      const char* menuString = cp_m_comp->get_name();
      menuItemIcon[1] = getIconFromString(menuString);
      selection = menu->get_current_component_num();    

      //DEBUG_PRINT("\nsetRootMenuItems name:%s numItem:%i currentComponentName: %s, menuIcon:[%s]",menu->get_name(),numItem,menuString, menuItemIcon[1]);

      bottomLabelTitle = *lang.getString(getNameFromString(menuString));
      if (numItem == 1){
          menuItemIcon[0] = " ";
          menuItemIcon[2] = " ";
      }else if (numItem == 2){
        if (selection == numItem-1){ 
          // left = right = first item
          menuItemIcon[0] = getIconFromString(menu->get_menu_component(0)->get_name());
          menuItemIcon[2] = getIconFromString(menu->get_menu_component(0)->get_name());
        }else{
          // left = right = second ite,
          menuItemIcon[0] = getIconFromString(menu->get_menu_component(1)->get_name());
          menuItemIcon[2] = getIconFromString(menu->get_menu_component(1)->get_name());
          
        }
      }else if (numItem > 2){
        if (selection == numItem-1){ // last item
          // left icon = -1, right icon = first item
          menuItemIcon[0] = getIconFromString(menu->get_menu_component(selection-1)->get_name());
          menuItemIcon[2] = getIconFromString(menu->get_menu_component(0)->get_name());
        }else if (selection == 0){ // first item
          // left icon = last item, right icon = +1
          menuItemIcon[0] = getIconFromString(menu->get_menu_component(numItem-1)->get_name());
          menuItemIcon[2] = getIconFromString(menu->get_menu_component(selection+1)->get_name());
        }else{ // any item in between
          // normal case, we take the -1 and +1 item
          menuItemIcon[0] = getIconFromString(menu->get_menu_component(selection-1)->get_name());
          menuItemIcon[2] = getIconFromString(menu->get_menu_component(selection+1)->get_name());
        }  
      }
    }

    void setBankMenuItems(){
      Menu const* menu = bankMenu->get_current_menu();
      uint8_t numItem = menu->get_num_components();  

      MenuComponent const* cp_m_comp;
      cp_m_comp = menu->get_current_component();
      const char* menuString = cp_m_comp->get_name();
    
      uint8_t selection = menu->get_current_component_num();    
      Bank* bank = banks.get(selection);      
      //widgets[MENU_LABEL_TITLE]->setText(&bank->name); // restore title  
      bottomLabelTitle = bank->name;
      menuItemIcon[1] = bank->icon;

      if (selection == numItem-1){ // last item
        // left icon = -1, right icon = first item
        menuItemIcon[0] = banks.get(selection-1)->icon;
        menuItemIcon[2] = banks.get(0)->icon;
      }else if (selection == 0){ // first item
        // left icon = last item, right icon = +1
        menuItemIcon[0] = banks.get(numItem-1)->icon;
        menuItemIcon[2] = banks.get(selection+1)->icon;
      }else{ // any item in between
        // normal case, we take the -1 and +1 item
        menuItemIcon[0] = banks.get(selection-1)->icon;
        menuItemIcon[2] = banks.get(selection+1)->icon;
      }  

    }

    void menuSwitchBankFullRefresh(){  
      //DEBUG_PRINT("\nmenuSystemFullRefresh");
      setBankMenuItems();
      //widgets[MENU_ICON_MIDDLE].widget->setFcolor(glowingGoldColor.value); // restore color
      GUI::glowingGoldColor.value = &menuActiveIconColor;
      widgets[CONFIG_TEXTAREA_MESSAGE]->setText(lang.getString(" ")); // empty message
    }

    void switchBank(){
      // if we have one bank or two we shift directly
      if (banks.size()<=2) screen.state = (screen.state + 1) % banks.size(); // <=2
      // otherwise we call the menu
      else screen.id = SCREEN_BANK_SWITCH;      
    }

    void testHttpRequest(){

      String srv = "82.65.4.93"; String path="/footswitch.php?check=1.2";
      DEBUG_PRINT("\nhttp.get(%s,%s)",srv.c_str(),path.c_str());
      int err = hwm->network->http->get(srv.c_str(), path.c_str());
      if (err == 0){
        DEBUG_PRINT("\nstartedRequest ok");
        err = hwm->network->http->responseStatusCode();
        if (err >= 0) {
          DEBUG_PRINT("\nGot status code: %i",err);
          // Usually you'd check that the response code is 200 or a similar "success" code (200-299) before carrying on, but we'll print out whatever response we get
          err = hwm->network->http->skipResponseHeaders();
          if (err >= 0){
            int bodyLen = hwm->network->http->contentLength();
            DEBUG_PRINT("\nLength: %i", bodyLen);
            DEBUG_PRINT("\nBody:\n");
            // Now we've got to the body, so we can print it out
            unsigned long timeoutStart = millis();
            char c;
            // Whilst we haven't timed out & haven't reached the end of the body
            while ( (hwm->network->http->connected() || hwm->network->http->available()) && ((millis() - timeoutStart) < 30*1000) ){
                if (hwm->network->http->available()){
                    c = hwm->network->http->read();
                    DEBUG_PRINT("%c",c);
                    bodyLen--;
                    // We read something, reset the timeout counter
                    timeoutStart = millis();
                }else{
                    // We haven't got any data, so let's pause to allow some to arrive
                    delay(1000);
                }
            }
          }else{
            DEBUG_PRINT("\nFailed to skip response headers: %i",err);
          }
        }else{    
          DEBUG_PRINT("\nGetting response failed: %i",err);
        }
      }else{
        DEBUG_PRINT("Connect failed: %i",err);
      }
      hwm->network->http->stop();  
    }

    void testOSC(){
      if (hwm->network->state == CONNECTED){
        SendCmd2OSC(hwm->network->udp, "/xinfo");
        delay(20);
        OSCReadIn(hwm->network->udp);      
      }else{
        DEBUG_PRINT("\nNO OSC Connection");
      }
    }

    void SendCmd2OSC(UDP* udp, const char* address)       // Send OSC command (buffer), no value (status request)
    {
      DEBUG_PRINT("\n>>(10023):%s",address);
      OSCMessage msg(address);
      udp->beginPacket("192.168.0.1", 10023);
      msg.send(*udp);
      udp->endPacket();
      msg.empty();
    }


    boolean OSCReadIn(UDP* udp) {
      DEBUG_PRINT("\n<<:");
      char PacketBuffer[24];
      int size = udp->parsePacket();
      if (size < 1) return false;
      OSCMessage msg;
      while (size--) msg.fill(udp->read());
      if (msg.hasError()) {
        return false;
      }
      msg.getAddress(PacketBuffer, 0);                // get message path
      String CommandStr = String(PacketBuffer);              // assign to CommandStr
      char TypeStr = msg.getType(0);                       // get data type
      char sValue[50];
      if (msg.isString(0)) {
        msg.getString(0, sValue);  // string
      }
      msg.empty();
      DEBUG_PRINT("%s",sValue);
      return true;
    }

    ///////////////////////////////////////////////////////////////////////

    //  APPLICATION & WORKFLOW MANAGEMENT METHODS

    ///////////////////////////////////////////////////////////////////////
    bool stripScroll(uint8_t direction, Bank* bank) {
      
      bool changedWindow = false; bool forceChangedWindow = false;

      // check that there is at least one slot available min this bank otherwise, we will have an infinite recursive call
      uint8_t nEmpty = 0;
      for (; nEmpty < BANK_MAX_STRIPS; nEmpty++) if (bank->get(nEmpty) != nullptr) break;
      if (nEmpty < BANK_MAX_STRIPS) {

        if (direction == hwm->buttons[RIGHTB]->getID()) {
          bank->selector++;
          if (bank->selector == STRIP_PER_WINDOW) {
            bank->selector = 0;
            bank->window++;
            if (bank->window == bank->getMaxWindow()) bank->window = 0;
            changedWindow = true;
          }
        } else if (direction == hwm->buttons[LEFTB]->getID()){
          if (bank->selector == 0) {
            if (bank->window == 0) bank->window = bank->getMaxWindow() - 1; 
            else bank->window--;
            bank->selector = STRIP_PER_WINDOW-1;
            changedWindow = true;
          } else bank->selector--;
        }else return false;

        forceChangedWindow = changedWindow;
        //we now check if slot is empty so we skip it
        bank->stripIndex = (bank->window * STRIP_PER_WINDOW) + bank->selector;
        screen.focus = bank->stripIndex ;
        if (bank->get(bank->stripIndex) == nullptr) {
          int8_t before = bank->window;
          //manage the case when an empty slot is the first or last of a window... it means we have to force the refresh as it will change the winodow
          changedWindow = stripScroll(direction, bank);
          int8_t after = bank->window;
          if (before != after) changedWindow = true;
        }
      }
      if (forceChangedWindow) changedWindow=true;

      // final check: if we only have one windows, any flag set above to change windows becomes invalid...
      if (bank->getMaxWindow() == 1) changedWindow = false;

      //DEBUG_PRINT("\nbank->stripIndex:%i changedwindow:%i",bank->stripIndex, changedWindow);
      return changedWindow;
    }

    bool stripAction() {    
      Bank* bank = banks.get(screen.state);    
      return bank->get(bank->stripIndex)->actionCallback();
    }

    bool stripChangeValue(uint8_t direction, unsigned long time){
      bool success = false;
      
      Bank* bank = banks.get(screen.state);    

      if (direction == hwm->buttons[RIGHTB]->getID()){ success = bank->get(bank->stripIndex)->increaseCallBack(time);}      
      else if (direction == hwm->buttons[LEFTB]->getID()){ success = bank->get(bank->stripIndex)->decreaseCallback(time);}      

      return success;
    }

    void jumpToStrip(uint8_t stripIndex, String bankName){
      screen.focus = stripIndex;
      Bank* bank = jumpToBank(bankName);
      bank->stripIndex = stripIndex;
      bank->get(stripIndex)->refresh();      
    }

    Bank* jumpToBank(String bankName){
      uint8_t bankIndex;
      Bank* bank = getBank(bankName,&bankIndex);
      screen.id = SCREEN_BANK;
      screen.state = bankIndex;   
      DEBUG_PRINT("\njumpToBank =>%s,%d",bank->name.c_str(),bankIndex);
      return bank;        
    }

    /////////////////////////////////////////////////////////////////////////////////////
    #define RET_SETSAVEBUTTON       "\"setSaveButton\":"
    #define RET_PONG                "\"pong\":\"\""
    #define RET_WIFISCANSTART       "\"wifiScanStart\":\"\""
    #define RET_WIFICONNECTTIMEOUT  "\"wifiConnectTimeout\":"
    #define RET_UNDEFINEDCALLBACK   "\"undefinedCallBack\":"
    #define RET_trashBank         "\"trashBank\":\""
    #define RET_TRASHSTRIP           "\"trashStrip\":"
    #define RET_COMMANDERROR         "\"commandError\":\""

    String undefinedJsonCallBack(JsonDocument jsonDoc){
      String answer;
      String jsonInputString;
      serializeJson(jsonDoc, jsonInputString);
      answer = "{"+String(RET_UNDEFINEDCALLBACK)+jsonInputString;          
      return answer;
    }


    String getConnectivityState(){
      return hwm->network->serialize();
    }

    String parseJsonInput(String input){
      DEBUG_PRINT("\nparseJsonInput(%s)",input.c_str());
      //DynamicJsonDocument jsonInput = DynamicJsonDocument(input.length()*50);
      JsonDocument jsonInput;
      deserializeJson(jsonInput, input);
      String command = jsonInput["command"];

      String answer = "{";

      if (command == "ping"){                    
        answer += RET_PONG;       
      }else if (command == "retrieve"){
        answer += "\""+jsonInput["param"].as<String>()+"\":";        
        if(jsonInput["param"] == "fullConfig"){
          String fullConfig;
          serialize(&fullConfig);
          answer += fullConfig;        
        }else if (jsonInput["param"] == "wizardConfig"){
          answer += "{\"volatile\":{\"langs\":[\"english\",\"francais\"]},\"system\":{\"configNames\":[\"anto\",\"thomas\",\"laurent\"],\"pushDelay\":\"550\",\"dClicReactivity\":\"0\",\"faderSpeed\":\"150\",\"profile\":\"default.conf\",\"apName\":\"footswitch\",\"lastSSID\":\"intervalmix\",\"lang\":\"francais\",\"ssid\":{\"intervalmix\":\"intervalpop74\",\"infrafast\":\"Mf9k8iie2\",\"ssid3\":\"pass3\"}}}";
        }else if (jsonInput["param"] == "connectivityConfig"){
          answer += getConnectivityState();
        }else{
          if (!userParseJsonInputCallback(jsonInput,&answer)) answer = undefinedJsonCallBack(jsonInput);
        }
      }else if (command == "set"){
        //{"command":"set","param":{"section":"system","id":"pushDelay","value":"3"}}
        answer+=RET_SETSAVEBUTTON;          // when we receive a "set" command, we process it and reply with a "save" token as callback function, with a  parameter to indicate true if user should save or 0 if not
        String section = jsonInput["param"]["section"];
        String id = jsonInput["param"]["id"];
        String value = jsonInput["param"]["value"];
        DEBUG_PRINT("\t => section:%s id:%s value:%s",section.c_str(),id.c_str(),value.c_str());
        bool success;
        if (section == "system"){
          success = system.setValue(id,value);
          if (success){
            applySystemSettings();            
            system.save();
          }
        }else if (section == "config"){
          success = config.setValue(id,value);
          if (success) applyConfigSettings();
        }else{

        }
        answer+=String(success);
      }else if (command == "scanWifi"){        // Create the parrallel scan task
        xTaskCreate(
          scanNetworksTaskWrapper,  // Function to implement the task
          "ScanNetworks",     // Name of the task
          4096,              // Stack size in words
          NULL,               // Task input parameter
          1,                  // Priority of the task
          NULL                // Task handle
        );
        answer += RET_WIFISCANSTART;       
      }else if (command == "stopWifi"){
        hwm->network->stopWiFi();
        answer+=RET_SETSAVEBUTTON+String(true); 
      }else if (command == "setWifi"){
        String ssid = jsonInput["param"]["ssid"].as<String>();
        String pwd = jsonInput["param"]["password"].as<String>();
        // indicate which WiFi to connect next
        // the appmanager refresh will take care of adding it to the valid json wifi ssid list  if it connects        
        hwm->network->setSSID(ssid,pwd);        
        if (hwm->network->media != CABLE_MEDIA) answer+=RET_WIFICONNECTTIMEOUT+String(hwm->network->getConnectTimeout());
        // if media is ethernet, we just feedback save button
        else answer+=RET_SETSAVEBUTTON+String(true);
      }else if (command == "insertStripRequest"){          
        //{"command":"insertStripRequest","param":{"bank":"BANK j3","strip":{"type":"text","index":"7","x":"3","y":"0","size":"1x4","color":3,"icon":"Z","properties":["/text/"]}}}
        //get the bank that need to be modified
        DEBUG_PRINT("\ninsertStripRequest bankName:%s, strip:%s",jsonInput["param"]["bank"].as<String>().c_str(),jsonInput["param"]["strip"].as<String>().c_str());        
        uint8_t bankIndex;
        Bank* bank = getBank(jsonInput["param"]["bank"],&bankIndex);  // get the bank and its index
        answer+=RET_SETSAVEBUTTON;          
        bool ret = false;
        if (bank != nullptr){
          if (bank->setStrip(jsonInput["param"]["strip"])){
            uint8_t stripIndex = jsonInput["param"]["strip"]["index"];            
            // put the focus on the strip
            jumpToStrip(stripIndex,bank->name);
            ret = true;
          }
        }
        answer+=String(ret); //answer should be : {"restoreStrip":{"bank":"BANK j3","strip":{"type":"text","index":"7","x":"3","y":"0","size":"1x4","color":3,"icon":"Z","properties":["/text/"]}}}
      }else if (command == "trashStripRequest"){        
        //{"command":"trashStripRequest","param":{"bank":"BANK j3","index":"6"}}
        uint8_t bankIndex;
        Bank* bank = getBank(jsonInput["param"]["bank"],&bankIndex);
        if (bank != nullptr){          
          uint8_t i = jsonInput["param"]["strip"]["index"];
          Strip* s = bank->get(i);
          if (s != nullptr){
            answer+=RET_TRASHSTRIP;   //{"trashStrip":{"bank":"BANK j3","index":6}}
            answer+="{\"bank\":\""+bank->name+"\",\"stripIndex\":"+String(i)+"}";
            bank->trash(i);           
            // we check if we delete the strip which is currently focused
            if (i == bank->stripIndex){
              // if that's the case, we first scroll to the next available one.          
              stripScroll(hwm->buttons[RIGHTB]->getID(),bank); 
              DEBUG_PRINT("\nDELETING FOCUSED STRIP, SCROLING...");
            }
          }else{
            answer+=RET_COMMANDERROR;
            answer+=*lang.getString("Bad strip ID");
            answer+="\"";              
          }
        }else{
          answer+=RET_COMMANDERROR;
          answer+=*lang.getString("Bad bank name");
          answer+="\"";
        }  
      }else if (command == "updateStrip"){
        //{"command":"updateStrip","param":{"bank":"BANK j1","strip":{"id":"ch2bus","index":2,"color":99,"icon":"Z","properties":["/bus/config/06/name"]}}}
        DEBUG_PRINT("\nupdateStrip bankName:%s, strip:%s",jsonInput["param"]["bank"].as<String>().c_str(),jsonInput["param"]["strip"].as<String>().c_str());        
        uint8_t bankIndex;
        Bank* bank = getBank(jsonInput["param"]["bank"],&bankIndex);  // get the bank and its index
        answer+=RET_SETSAVEBUTTON;          
        bool ret = false;
        if (bank != nullptr){
          uint8_t stripIndex = jsonInput["param"]["strip"]["index"];
          Strip* strip = bank->get(stripIndex);
          if (strip->deserialize(jsonInput["param"]["strip"])){
            jumpToStrip(stripIndex,bank->name);
            ret = true;
          }
        }
        answer+=String(ret);
      }else if (command =="trashBankRequest"){
        //{"command":"trashBank","param":{"name":"BANK j2"}}
        String bankName = jsonInput["param"]["name"];
        DEBUG_PRINT("\ntrashBank %s",bankName);
        uint8_t bankIndex;
        Bank* bank = getBank(bankName,&bankIndex);  // get the bank and its index
        if (bank != nullptr){

          banks.remove(bankIndex);
          delete bank;

          if (bankIndex == screen.state || screen.id == SCREEN_BANK_SWITCH) jumpToBank(banks.get(0)->name);  // go to first bank in case we delete the current displayed or we are showing menu switch

          hookBankToMenu();   // rebuild the bank switch menu
          answer+=RET_trashBank;
          answer+=bankName+"\"";          
        }else{
          answer+=RET_COMMANDERROR;
          answer+=*lang.getString("Bad bank name");
          answer+="\"";
        }        
      }else if (command == "createBank"){
        //{"command":"createBank","param":{"Bank 2":{"possibleLayout":3,"currentLayout":0,"icon":"b","strips":[{"id":"ch2bus","index":0,"color":99,"icon":"Z","properties":["/ch/01/name","/bus/01/name"]}]}}}
        answer+=RET_SETSAVEBUTTON;
        bool ret = false;
        String jsonBankstring = jsonInput["param"];
        Bank* bank = deserializeBanks(&jsonBankstring);
        if (bank != nullptr){
          ret = true;
          jumpToBank(bank->name);
        }
        answer+=String(ret);
      }else if (command == "renameBank"){
        //{"command":"renameBank","param":{"oldname":"BANK 1","newname":"BANK 2"}}
        answer+=RET_SETSAVEBUTTON;
        bool ret = false;
        String oldName = jsonInput["param"]["oldname"];
        String newName = jsonInput["param"]["newname"];
        uint8_t bankIndex;
        Bank* bank = getBank(oldName,&bankIndex);  // get the bank and its index
        if (bank != nullptr){
          bank->name = newName;
          ret = true;
        }        
        answer+=String(ret);
      }else if (command == "save"){     
        String fullConfig;
        serialize(&fullConfig);

        bool ret = config.save();
        ret &=  system.save();       
        answer+=RET_SETSAVEBUTTON+String(!ret); //if both save are ok, we send 0 as a semantic value to disable the save button
      }else{
        if (!userParseJsonInputCallback(jsonInput,&answer)) answer = undefinedJsonCallBack(jsonInput);
      }
      answer += "}";
      //DEBUG_PRINT("\n\nanswer:<%s>\n\n",answer.c_str());
      return answer;
    }    

    
    void scanNetworksTask(void * parameter) {
      #define MAX_NUMBER_OF_NETWORK_TO_REPORT 10     
      //DynamicJsonDocument doc(60+50*MAX_NUMBER_OF_NETWORK_TO_REPORT);
      JsonDocument doc;
      //JsonArray scannedWifi = doc.createNestedArray();
      JsonArray scannedWifi = doc["scannedWifi"].to<JsonArray>();           
      //DEBUG_PRINT("\nScanning for WiFi networks...");
      int numberOfNetworks = WiFi.scanNetworks();
      //DEBUG_PRINT("Scan complete");
      for (int i = 0; i < numberOfNetworks && i<MAX_NUMBER_OF_NETWORK_TO_REPORT; i++) {
        //DEBUG_PRINT("\nNetwork name: %s",WiFi.SSID(i).c_str());
        scannedWifi.add(WiFi.SSID(i));
      }     
      String data;
      serializeJson(doc,data);
      broadCast(data);
      // Delete the task itself
      vTaskDelete(NULL);
    }


    Bank* getBank(String name, uint8_t* index){
      for ( *index = 0;*index<banks.size();(*index)++){          
        //DEBUG_PRINT("\nindex:%d=>name:%s",*index,banks.get(*index)->name.c_str());
        if (banks.get(*index)->name == name){
          //DEBUG_PRINT("\nfound bank: %s",name.c_str());
          return banks.get(*index);
        }
      }
      return nullptr;      
    }

  private:
    HardwareManager* hwm;
    GUIManager* gui;
    LinkedList<screenBuilder*> screenBuilders = LinkedList<screenBuilder*>();      

    JsonList wiFiList;    
         
    String defaultSysConf = "{"
    //"\""+String(S_CONFIGNAMES)+"\":[\"anto\",\"thomas\",\"laurent\"]\","
      "\""+String(S_PUSHDELAY)+"\":\"852\","
      "\""+String(S_DCLICREACTIVITY)+"\":\"251\","
      "\""+String(S_CONFIG_FILE)+"\":\"default.conf\"," 
      "\""+String(S_AP_NAME)+"\":\"footswitch\","
      "\""+String(S_LAST_USED_SSID)+"\":\"intervalmix1\","
      "\""+String(S_LANG)+"\":\"francais\","
      "\""+String(S_FADERSPEED)+"\":\"157\","
      "\""+String(S_SSID)+"\":{\"intervalmix1\":\"intervalpop74\",\"VACANCES\":\"FREJUSPLAGE\",\"IphoneTch\":\"jt2p9ug1\"}"
    "}";



    String defaultUserConf = 
      "\""+String(C_BANKS)+"\":{"
        "\"BANK j1\":{\"possibleLayout\":3,\"currentLayout\":0,\"icon\":\"b\",\"strips\":[{\"type\":\"text\",\"size\":\"1x4\",\"x\":0,\"y\":0,\"index\":1,\"color\":3,\"icon\":\"i\",\"properties\":[\"/text/change\"]},{\"type\":\"text\",\"size\":\"4x1\",\"x\":0,\"y\":3,\"index\":4,\"color\":1,\"icon\":\"j\",\"properties\":[\"/text/me\"]}]},\"BANK j2\":{\"possibleLayout\":2,\"currentLayout\":2,\"icon\":\"h\",\"strips\":[{\"type\":\"text\",\"size\":\"1x4\",\"x\":0,\"y\":0,\"index\":0,\"color\":2,\"icon\":\"n\",\"properties\":[\"/text/another\"]},{\"type\":\"text\",\"size\":\"1x4\",\"x\":1,\"y\":0,\"index\":1,\"color\":2,\"icon\":\"o\",\"properties\":[\"/text/one\"]}]},\"BANK j3\":{\"possibleLayout\":4,\"currentLayout\":1,\"icon\":\"g\",\"strips\":[{\"type\":\"ch2bus\",\"size\":\"1x4\",\"x\":0,\"y\":0,\"index\":4,\"color\":99,\"icon\":\"k\",\"properties\":[\"/ch/02/config/name\",\"/bus/02/config/name\"]},{\"type\":\"chGain\",\"index\":5,\"size\":\"1x4\",\"x\":1,\"y\":0,\"color\":2,\"icon\":\"l\",\"properties\":[\"/ch/02/config/name\"]},{\"type\":\"ch2bus\",\"index\":6,\"size\":\"1x4\",\"x\":2,\"y\":0,\"color\":99,\"icon\":\"k\",\"properties\":[\"/ch/02/config/name\",\"/bus/02/config/name\"]},{\"type\":\"ch2bus\",\"index\":8,\"size\":\"2x2\",\"x\":1,\"y\":1,\"color\":4,\"icon\":\"k\",\"properties\":[\"/ch/02/config/name\",\"/bus/06/config/name\"]}]}"
      "}";

    Application* webServer = nullptr;
    ScreenUnion oldScreen;    

    LinkedList<String*> countryList = LinkedList<String*>();   
    LinkedList<String*> webGZFiles = LinkedList<String*>();   

    bool webAppOn = false;
    IWebSocketServer *wss{ nullptr };        

    uint32_t minHeapSize,maxHeapSize;
    String heapSize;

    ///////////////////////////////////////////////////////////////////////

    void httpPost(Request &req, Response &res){
      #define COMMAND_SIZE 500
      #define OPTION_SIZE 64
      char name[COMMAND_SIZE];
      char options[OPTION_SIZE];    //options is not used (the fetch from client puts everything in the name as a json)
      res.set("Content-Type", "application/json");
      while (req.left()) {        
        req.form(name, COMMAND_SIZE, options, OPTION_SIZE);                
        if (debug){
          //DEBUG_PRINT("\n\n\t httpPost <%s>:<%s>\n\n",name,options);
        } 
        String answer = parseJsonInput(name);
        if (debug){
          //DEBUG_PRINT("\n\t httpres:<%s>",answer.c_str());
        }
        res.print(answer);
        res.end();
      }  
    }  

    void populateFileList(String extension, String folder, LinkedList<String*> *list, String prefix="", bool withExtension=true) {
      //we first clean all items from the list

      while (list->size()>0){
        String* s = list->shift();
        delete(s);
      }

      File root = LittleFS.open(folder);
      //DEBUG_PRINT("\nListing: .%s",extension.c_str());
      File file = root.openNextFile();
      while (file){
        if (!file.isDirectory()){
          String fullFileName = file.name();
          if (fullFileName.endsWith(extension)) {
            String* filename=new String(prefix);
            // if we don't want the extension, we remmove it          
            if (!withExtension) *filename += fullFileName.substring(0, fullFileName.lastIndexOf('.'));
            else *filename += fullFileName; // k is the icon ID
            list->add(filename);
            //if (debug) DEBUG_PRINT("\n\t %s",filename->c_str());          
          }
        }
        file = root.openNextFile();
      }
    }

    void enableWizard(){
      persistants.putUChar(PERSISTANT_SCREEN_ID,SCREEN_WIZARD);
      persistants.putUChar(PERSISTANT_SCREEN_STATE,STATE_WIZARD_LANG_STEP1);      
    }

    MenuItem* back_menu_item;
    MenuItem* info_menu_item;
    MenuItem* config_menu_item;
    Menu* profile_menu_item;
    MenuItem* save_profile_menu_item;
    MenuItem* tft_rotation_menu_item;
    MenuItem* reset_menu_item;   
    MenuItem* shutdown_menu_item; 

    void hookBankToMenu(){
      if (bankMenu != nullptr) delete bankMenu;
      bankMenu = new MenuSystem(*this); 

      if (banks.size()>1){                      
        // populate the menu with all banks
        for(int i = 0; i < banks.size(); i++){
          const char* bankName = banks.get(i)->name.c_str();
          bankMenu->get_root_menu().add_item(new MenuItem(bankName, &switchToBank_item_selected));                
          if (debug){
            //DEBUG_PRINT("\nadded bank switch item entry: %s",bankName);           
          }
        }
      }else{
        //DEBUG_PRINT("\nBank menu list: %s",banks.get(0)->name.c_str());  
        bankMenu->get_root_menu().add_item(new MenuItem(banks.get(0)->name.c_str(), &switchToBank_item_selected));        
      }
    }    

};

#endif

